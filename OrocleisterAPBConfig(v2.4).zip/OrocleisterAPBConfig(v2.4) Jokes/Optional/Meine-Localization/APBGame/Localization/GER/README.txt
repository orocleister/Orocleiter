Safe GER merge.
Existing GER lines were kept as-is. Only missing INT keys were inserted.
Insertion rule: place a missing key under the closest matching key prefix inside the same section; if no similar key exists, append at the end of that section.

AmmoCategories.GER: inserted 4 missing entries
APBUserInterface.GER: inserted 168 missing entries
CapacityItemTypes.GER: inserted 3 missing entries
ClothingItemTypes.GER: inserted 436 missing entries
ContactLevels.GER: inserted 118 missing entries
Contacts.GER: inserted 6 missing entries
DailyActivityContacts.GER: inserted 60 missing entries
HUDDistrictMapMarker.GER: inserted 16 missing entries
HUDMarkerVisual.GER: inserted 4 missing entries
HUDMarkerVisualText.GER: inserted 192 missing entries
HUDMessages.GER: inserted 136 missing entries
HUDPopUpMenuItems.GER: inserted 3 missing entries
InventoryItemCategories.GER: inserted 0 missing entries
InventoryItemTypes.GER: inserted 5642 missing entries
Minigames.GER: inserted 40 missing entries
ModifierEffects.GER: inserted 84 missing entries
ModifierItemTypes.GER: inserted 122 missing entries
OptionCategories.GER: inserted 1 missing entries
Options.GER: inserted 28 missing entries
PlayerRoles.GER: inserted 198 missing entries
RedeemableRewards.GER: inserted 684 missing entries
RewardPackages.GER: inserted 3925 missing entries
RoleMilestones.GER: inserted 897 missing entries
ShopUIFilters.GER: inserted 16 missing entries
TutorialCategories.GER: inserted 2 missing entries
UIInteractionPoints.GER: inserted 1 missing entries
UnlockItemTypes.GER: inserted 1867 missing entries
VehicleItemTypes.GER: inserted 15 missing entries
WeaponItemTypes.GER: inserted 14 missing entries
WeightedRewards.GER: inserted 2672 missing entries