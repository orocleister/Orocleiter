﻿# OrocleisterAPBConfig(v2.4) Jokes

APB-Einstellungen, Direktstart und wiederherstellbare Änderungen. Die Oberfläche startet auf Englisch; Deutsch und Russisch stehen im Sprachmenü bereit.

## Erste Schritte

1. Den vollständigen Ordner entpacken. EXE, Skripte und Assets zusammenlassen.
2. APB und Launcher schließen, dann **APB-Config.exe** öffnen.
3. Unter Grundeinstellungen eine APB-Verknüpfung oder `Binaries/APB.exe` auswählen.
4. Einstellungen wählen und **Anwenden** anklicken.
5. **Play APB** startet das Spiel direkt.

Rote gekreuzte Klingen bedeuten eingeschaltet, graue ausgeschaltet. Vorhandene Einstellung behalten lässt die jeweilige Option unverändert. Änderungen benötigen Anwenden und einen Spielneustart.

## Starttasten

Anwenden schreibt Einstellungen, erstellt ein Backup und aktualisiert die Verknüpfung. Anwenden & Launcher öffnet zusätzlich den offiziellen Launcher; dieser kann geänderte Dateien ersetzen. Play APB startet die Verknüpfung ohne ausstehende Grafik- oder Audioänderungen anzuwenden. Ohne importierte Verknüpfung entsteht APB-Direct.lnk neben der App. Nach dem Start schließt die App; während des Spiels wird sie nicht benötigt. Direktstart umgeht keine Kontoanmeldung und beeinflusst keine Handelssperren.

## 01  GRUNDLAGEN

**Spielauflösung** — Standard: behält die Spielauflösung. Renderauflösung bleibt bei 100 %.

**FPS-Limit** — Standard: 144. Leer oder 0 hebt das FPS-Limit auf. MSAA kann Leistung kosten.

**NORMAL · klare Spieler** — Wenige Umgebungsdetails; höhere Qualität für Spieler, Kleidung, Symbole und Fahrzeuge. Normale Zauntexturen und 100 % Renderauflösung.

**NIEDRIG · alle Texturen** — Senkt auch Texturen von Spielern, Kleidung, Fahrzeugen und Symbolen. Zäune können undurchsichtig wirken. Kein garantierter FPS-Gewinn. Normal + Anwenden stellt das normale Profil wieder her.

**Kleidungs- und Fahrzeugeditoren aktivieren** — An: Social-Editoren funktionieren. Aus: kann regelmäßige Ruckler mindern, aber Editoren blockieren und Respawn-Pausen verlängern.

## 02  EFFEKTE

**Fahrzeugfeuer / gemeinsame Trefferpartikel** — Blut ist mit Fahrzeugfeuer / gemeinsame Trefferpartikel oben gekoppelt. Ausschalten reduziert diese gemeinsamen Effekte. Kein separater Blutfilter; vollständige Entfernung aller Bluteffekte ist nicht bestätigt.

**Flugspuren von Granaten besser sichtbar machen** — Passt Effekttexturen für Granatenspuren an. Keine Garantie für jede Flugspur; schaltet nicht sämtlichen Rauch ab.

**Partikeleffekte der Umgebung ausschalten** — Deaktiviert Umgebungspartikel. Granaten- und Fahrzeugeffekte haben eigene Einstellungen.

**Mündungsfeuer anzeigen** — Zeigt oder versteckt Mündungsfeuer. Schaden und Genauigkeit bleiben gleich.

**Ausgeworfene Hülsen anzeigen** — Zeigt oder versteckt ausgeworfene Patronenhülsen.

## 03  AUDIO

**Vivox-Sprachchat** — Deaktiviert Sprachsystem, automatischen Beitritt und Sprachkanäle in lokalen Kontoeinstellungen. Neustart nötig. Entladen der Voice-Bibliothek und FPS-Gewinn nicht bestätigt. Nach erneutem Einschalten Kanäle in APB aktivieren.

**Spielton bei Sprachchat absenken** — Aus: Sprachchat senkt die übrigen Spielgeräusche nicht mehr ab.

**Spieler-Todesthemen** — Kurze Melodien nach einem Kill. Hörbar aktiviert Themes von Freunden, ignorierten und anderen Spielern.

**Von Spielern erstellte Songs** — Nutzt APBs Option für selbst erstellte Songs. Schaltet die lizenzierte Musikbibliothek nicht stumm. Kill-Themes werden separat gesteuert.

**Lautstärke der eigenen Playlist** — 0 % schaltet eigene Player stumm, Autostart und Übertragung aus dem Auto ab. Fremdes Autoradio kann hörbar bleiben. Playlists bleiben erhalten.

## 04  STEUERUNG

**Mauseingabe** — Standard: Glättung aus, Achsentempo 1. Ohne Fix: Glättung an, Tempo 1. Legacy: Glättung aus, Tempo 2 (doppelte Bewegung). Gespeicherte Empfindlichkeit bleibt erhalten.

**Spielinterner Sprint-Punkt** — Steuert APBs eingebauten Sprint-Punkt für vorhandene lokale Konten. Kein dauerhaftes Fadenkreuz.

**Automatisch bereit für Missionen** — Aktiviert APBs automatische Missionsbereitschaft.

**HUD-Skalierung auf Spielstandard** — Setzt beim Anwenden die HUD-Skalierung auf den Spielstandard. Keine garantierte Korrektur eines Zielversatzes. Backup stellt den vorherigen Wert wieder her.

## 05  START

**Ladevideos überspringen** — Fügt -nomovies zum Direktstart hinzu. Überspringt Intro-Videos; Karten müssen weiterhin laden.

**Startbild überspringen** — Fügt -nosplash zum Direktstart hinzu. Das Anti-Cheat-Fenster bleibt sichtbar.

**Steam-Integration ausschalten** — Fügt -nosteam hinzu. Deaktiviert Steam-Autologin; separate Spielanmeldung erforderlich.

**Einfacher Login-Hintergrund** — Nutzt beim Login den Hintergrund der Distriktauswahl. Zur Charaktererstellung ausschalten.

**Eigene englische Spieltexte** — Installiert die mitgelieferten englischen HUD-Texte und ergänzt den Sprachparameter für den Direktstart.

**Zusätzliche Community-Witze** — Ergänzt Cheater Located und Sosality loading… mit den eigenen Spieltexten. Nur humorvolle Texte, keine Cheat-Erkennung.

## 06  WERKZEUGE

**Texturstreaming** — Lädt Texturen nach Bedarf. An/Aus kann je nach System unterschiedlich auf Ruckler wirken. Neustart nötig.

**Festplatten-Cache** — Nutzt einen Laufwerkscache für wiederverwendbare Daten. Standardmäßig aus; Nutzen hängt von RAM und Laufwerk ab.

**Gamma** — Ändert die Helligkeit des gesamten Bildes. Keine getrennte Himmelshelligkeit oder feste Tageszeit.

## Fadenkreuz · Risiko

**Experimentelles Shader-Fadenkreuz** — Zeichnet einen kontrastreichen Punkt in die Mitte der Spielszene. Ergänzt nur den Code des Fadenkreuzes im kompatiblen installierten Shader. Anwenden erstellt vorher ein Backup. Standardmäßig deaktiviert.

**Risiko der Shader-Änderung akzeptieren** — Nutzung auf eigenes Risiko. Für diese Shader-Änderung ist keine offizielle Freigabe bestätigt. Änderungen an Spieldateien können Kontosanktionen auslösen.

**Punkt dieser App entfernen** — Experimentell: Sichtbarkeit hängt von Nachbearbeitung und Shader-Cache ab. Keine Funktionsgarantie für die aktuelle Spielversion. Verschiebt nicht das Waffenvisier und behebt keinen Zielversatz. Punktgröße hängt von der Auflösung ab. Entfernen löscht nur den markierten Zusatz; das Backup stellt die vorherige Datei wieder her.

## Umfang der Musikoptionen

Die Preset-Taste aktiviert Kill-Themes, deaktiviert erstellte Songs und setzt die eigene Playlist auf null. Null deaktiviert außerdem automatische Fortsetzung, Wiedergabe zu Fuß und Übertragung aus dem Auto. Eine spätere Lautstärkeerhöhung stellt diese Wiedergabeoptionen nicht automatisch wieder her; dafür APB-Einstellungen oder Backup nutzen. Lizenzierte Musik fremder Autoradios kann hörbar bleiben. Kein bestätigter Schalter gefunden, der sämtliche fremden Songs abschaltet und Kill-Themes erhält. Audiobanken und Instrumentenordner bleiben erhalten. Die Option benötigt eine vorhandene lokale Musikbibliothek; nötigenfalls den Musikplayer einmal in APB öffnen.

## Backups

Backup wiederherstellen macht die letzte Anwendung von Spieldateien für den gewählten Spielordner rückgängig. Frühere Änderungen benötigen frühere Backups. Verknüpfungen werden separat in shortcut-before.lnk und shortcut.json gesichert. Den Backups-Ordner aufbewahren. Nach Updates zuerst den Launcher abschließen lassen und danach Einstellungen anwenden.

## Spielerzahlen und Links

Spielerzahlen werden alle 60 Sekunden von der offiziellen GamersFirst-Distriktseite geladen, solange die App geöffnet ist. Gesamtzahl, EU, NA und Fraktionen sind Website-Momentaufnahmen, keine direkte Serververbindung. Fehlende Daten erscheinen als nicht verfügbar statt null. Links zu Nachrichten, Forum und Discord öffnen erst beim Anklicken.

## Ausrichtung des Fadenkreuzes

Der Shader-Punkt markiert die Mitte der Spielszene und korrigiert nicht die Zielrichtung der Waffe. Sichtbarkeit hängt von Nachbearbeitung und kompiliertem Shader-Cache ab. Shader-Caches werden nicht gelöscht. Ein Monitor-Punkt erscheint normalerweise nicht auf Screenshots; zum Vergleich mit dem Spielvisier ist ein Handyfoto nötig. Ein Zielversatz wurde nicht vermessen oder korrigiert.

## Prüfungen und Quellen

Schreibvorgänge, Wiederherstellung und Bedienelemente sind an Kopien getestet. Shader-Kompilierung, Musikwiedergabe, FPS-Gewinne und Entladen von Vivox benötigen einen Spieltest. Dies ist ein Community-Tool, keine offizielle Veröffentlichung. Freigabe-Motive im Hintergrund sind Dekoration und kein Genehmigungsnachweis.

[Flaws](https://github.com/flawsv/apb) · [Lazer](https://github.com/lvzxr/apb-cfg-loader) · [SARD FAQ](https://www.gamersfirst.com/apb/news/2024/8/14/sard-faq) · [Crosshair source](https://zhyk.org/forum/showthread.php?t=466225)
