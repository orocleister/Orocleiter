﻿# OrocleisterAPBConfig(v2.4) Jokes

APB configuration, direct launch and reversible settings. The interface starts in English; German and Russian are available from the language menu.

## Getting started

1. Extract the complete folder and keep the EXE, scripts and Assets together.
2. Close APB and its launcher, then open **APB-Config.exe**.
3. Select an APB shortcut or `Binaries/APB.exe` in Basic.
4. Set the options and click **Apply**.
5. Use **Play APB** for direct launch.

Red crossed blades mean enabled; grey blades mean disabled. Keep current leaves the selected option unchanged. Changes require Apply and a game restart.

## Launch buttons

Apply writes settings, creates a backup and updates the shortcut. Apply & Launcher also opens the official launcher, which can replace modified files. Play APB starts the shortcut without applying pending graphics or audio changes. Without an imported shortcut, APB-Direct.lnk is created beside the app. The app closes after launch and is not required while playing. Direct launch does not bypass account authentication or control trade restrictions.

## 01  BASIC

**Game resolution** — Default: keeps installed resolution. Render scale stays at 100%.

**FPS limit** — Default: 144. Empty or 0 removes the FPS cap. MSAA can lower performance.

**NORMAL · clear players** — Low environment detail; higher-quality players, outfits, symbols and vehicles. Normal fence textures and 100% render scale.

**LOW · all textures** — Lowers textures for players, clothing, vehicles and symbols as well. Fences may become opaque. FPS gains are not guaranteed. Normal + Apply restores the regular preset.

**Enable clothing and vehicle editors** — Enabled: Social designers work. Disabled: may reduce periodic stutters, but can break designers and increase respawn pauses.

## 02  ADVANCED

**Vehicle fire / shared hit particles** — Blood is linked to Vehicle fire / shared hit particles above. Disable that switch to reduce the shared effects. It is not an independent blood filter; complete removal of every blood effect is unverified.

**Improve visibility of grenade flight trails** — Adjusts effect textures for grenade trails. Does not guarantee trails for every projectile or disable all smoke.

**Disable ambient particle effects** — Disables level ambient particles. Grenade and vehicle effects use separate controls.

**Show muzzle flashes** — Shows or hides weapon muzzle flashes. No change to damage or accuracy.

**Show ejected shell casings** — Shows or hides visual shell casings ejected by weapons.

## 03  AUDIO

**Vivox voice chat** — Disables the voice system, auto-join and voice channels in local account settings. Restart required. Voice-library unloading and FPS gains are unverified. Re-enable channels in APB after turning voice back on.

**Game audio ducking** — Disabled: voice chat no longer lowers other game sounds.

**Player death themes** — Short tunes after a kill. Audible enables themes from friends, ignored players and other players.

**Player-created songs** — Uses APB’s Disable Created Songs option. Does not mute the licensed song library. Kill themes are controlled separately.

**Local playlist volume** — 0% mutes saved local players and disables auto-resume and car broadcast. Other players’ radio may remain audible. Playlists are kept.

## 04  CONTROLS

**Mouse input** — Standard: smoothing off, axis speed 1. No fix: smoothing on, speed 1. Legacy: smoothing off, speed 2 (twice the movement). Saved sensitivity values are preserved.

**In-game sprint dot** — Controls APB’s built-in sprint dot for existing local accounts. It does not provide a permanent crosshair.

**Auto-ready for missions** — Enables APB’s automatic mission-ready setting.

**Reset HUD scale to game default** — Resets HUD scale to the game default on Apply. Does not guarantee a fix for aim offset. Restore backup undoes the reset.

## 05  LAUNCH

**Skip loading movies** — Adds -nomovies to direct launch. Skips intro videos; map loading remains.

**Skip startup splash** — Adds -nosplash to direct launch. The anti-cheat window remains visible.

**Disable Steam integration** — Adds -nosteam. Disables Steam auto-login; a separate game login is required.

**Simple login background** — Uses the district-selection background at login. Disable for character creation.

**Use the custom English game text** — Installs the bundled English HUD text and adds its language argument to direct launch.

**Extra community jokes** — Adds Cheater Located and Sosality loading… with custom game text. Humorous labels only; no cheat detection.

## 06  TOOLS

**Texture streaming** — Loads textures as needed. On/off can affect stutters differently across systems. Restart required.

**Disk cache** — Uses a disk cache for reusable data. Disabled by default; usefulness depends on available RAM and storage.

**Gamma** — Changes brightness across the whole image. Does not darken only the sky or set a fixed time of day.

## Crosshair · Risk

**Experimental shader crosshair** — Draws a contrasting point in the centre of the rendered scene. Adds only the supplied crosshair fragment to a compatible installed shader. Apply creates a backup before the change. Disabled by default.

**Accept the shader modification risk** — Use at own risk. No official approval is confirmed for this shader edit. Game-file modifications may lead to account sanctions.

**Remove this app’s dot** — Experimental: visibility depends on the active post-processing and shader cache. No guarantee for the current game version. Does not move the weapon reticle or fix an aim offset. The point scales with resolution. Removal deletes only this app’s marked fragment; Restore backup returns the previous file.

## Music scope

The preset button enables kill themes, disables created songs and sets local playlist volume to zero. Zero also disables local auto-resume, playback on foot and vehicle broadcasting. Raising volume later does not automatically restore those playback choices; configure them in APB or restore the backup. Other players’ licensed radio music may remain audible. No verified setting was found that silences every remote song while preserving kill themes. Audio banks and instrument folders are left intact. Existing local libraries are required; open the music player in APB once if none has been saved.

## Backups

Restore backup reverses the most recent game-file application for the selected game folder. Earlier changes require earlier backups. Shortcut backups are separate: shortcut-before.lnk and shortcut.json record the original shortcut. Keep the Backups folder. After an update, let the launcher finish before applying settings again.

## Population and links

Population is read from the official GamersFirst district page every 60 seconds while the app is open. Total, EU and NA counts and faction splits reflect website snapshots, not a direct game-server connection. Unavailable data is shown as unavailable rather than zero. News, forum and Discord links open when clicked.

## Crosshair alignment

A shader dot marks the centre of the rendered scene; it does not correct the weapon’s aim. Visibility depends on post-processing and compiled shader caches. Shader caches are not deleted. A monitor overlay normally does not appear in screenshots; a phone photo is needed to compare it with the in-game reticle. No aim offset has been measured or fixed.

## Validation and credits

Configuration writes, restoration and interface controls are tested on copies. Shader compilation, music playback, FPS gains and Vivox library unloading require in-game verification. This is a community tool, not an official release. Background approval artwork is decorative, not evidence of permission.

[Flaws](https://github.com/flawsv/apb) · [Lazer](https://github.com/lvzxr/apb-cfg-loader) · [SARD FAQ](https://www.gamersfirst.com/apb/news/2024/8/14/sard-faq) · [Crosshair source](https://zhyk.org/forum/showthread.php?t=466225)
