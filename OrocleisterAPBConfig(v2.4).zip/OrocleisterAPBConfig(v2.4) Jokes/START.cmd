@echo off
start "" "%~dp0APB-Config.exe"
