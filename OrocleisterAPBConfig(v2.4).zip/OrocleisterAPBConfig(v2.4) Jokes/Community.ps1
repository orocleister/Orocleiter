﻿function Read-OnlineSnapshot([string]$html) {
 $count=[regex]::Match($html,'(?is)class="total-ccu-stats"[^>]*>\s*<strong>\s*([0-9][0-9, ]*)\s*</strong>\s*online now')
 $stamp=[regex]::Match($html,'(?is)class="status-updated"[^>]*>\s*UPDATED\s+([0-9]{2}:[0-9]{2})\s*</span>')
 if(-not $count.Success -or -not $stamp.Success){throw 'Population data unavailable'}
 $result=@{Count=[int]($count.Groups[1].Value -replace '[, ]','');SourceTime=$stamp.Groups[1].Value}
 foreach($region in @('EU','NA')){
  $panel=[regex]::Match($html,('(?is)id="panel-'+$region+'".*?<div class="status-summary">(.*?)</div>'))
  $total=[regex]::Match($panel.Groups[1].Value,'(?is)class="sum-total">\s*<strong>([0-9, ]+)</strong>')
  $enf=[regex]::Match($panel.Groups[1].Value,'(?is)class="enf">ENF\s+([0-9, ]+)</span>')
  $crim=[regex]::Match($panel.Groups[1].Value,'(?is)class="crim">CRIM\s+([0-9, ]+)</span>')
  if(-not $total.Success -or -not $enf.Success -or -not $crim.Success){throw ('Missing region '+$region)}
  $result[$region]=@{Total=[int]($total.Groups[1].Value -replace '[, ]','');Enforcers=[int]($enf.Groups[1].Value -replace '[, ]','');Criminals=[int]($crim.Groups[1].Value -replace '[, ]','')}
 }
 return $result
}
function Open-CommunityLink([string]$url) {try{$info=New-Object Diagnostics.ProcessStartInfo;$info.FileName=$url;$info.UseShellExecute=$true;[void][Diagnostics.Process]::Start($info)}catch{Show-Error $_}}
function Clear-Population {
 $onlineTotal.Text=T 'OnlineTotalEmpty';$onlineEU.Text=T 'OnlineEUEmpty';$onlineNA.Text=T 'OnlineNAEmpty'
}
function Add-CommunityPanel {
 Add-Type -AssemblyName System.Net.Http
 $script:communityPanel=New-Object ApbSurface;$communityPanel.SetBounds(976,225,244,538);$communityPanel.BackColor=$dark;$form.Controls.Add($communityPanel)
 $null=Label $communityPanel 'PopulationTitle' 12 12 220 25
 $script:onlineTotal=Label $communityPanel 'OnlineTotalEmpty' 12 44 220 38;$onlineTotal.Font=New-Object Drawing.Font('Segoe UI',15,[Drawing.FontStyle]::Bold);$onlineTotal.ForeColor=$ink
 $script:onlineEU=Label $communityPanel 'OnlineEUEmpty' 12 95 220 58;$onlineEU.ForeColor=[Drawing.Color]::FromArgb(77,195,251)
 $script:onlineNA=Label $communityPanel 'OnlineNAEmpty' 12 166 220 58;$onlineNA.ForeColor=[Drawing.Color]::FromArgb(235,166,108)
 $script:onlineLabel=Label $communityPanel 'OnlineInitial' 12 238 220 72;$onlineLabel.Font=New-Object Drawing.Font('Segoe UI',8)
 $script:refreshOnline=Button $communityPanel 'OnlineRefresh' 12 315 220 {Start-OnlineRefresh}
 $null=Button $communityPanel 'CommunityNews' 12 361 105 {Open-CommunityLink 'https://www.gamersfirst.com/apb/news/'}
 $null=Button $communityPanel 'ShortForum' 127 361 105 {Open-CommunityLink 'https://forums.gamersfirst.com/forum/3-apb-reloaded/'}
 $null=Button $communityPanel 'CommunityDiscord' 12 409 220 {Open-CommunityLink 'https://discord.gg/littleorbit'}
 $null=Button $communityPanel 'CommunityDistricts' 12 457 220 {Open-CommunityLink 'https://www.gamersfirst.com/apb/status'}
 $script:onlineTimer=New-Object Windows.Forms.Timer;$onlineTimer.Interval=200
 $script:populationRefreshTimer=New-Object Windows.Forms.Timer;$populationRefreshTimer.Interval=60000
 $populationRefreshTimer.Add_Tick({Start-OnlineRefresh})
 $onlineTimer.Add_Tick({
  if($script:onlineTask -and $script:onlineTask.IsCompleted){
   $onlineTimer.Stop()
   try{
    $snapshot=Read-OnlineSnapshot ($script:onlineTask.GetAwaiter().GetResult())
    $onlineTotal.Text=(T 'PopulationTotal') -f $snapshot.Count
    $onlineEU.Text=(T 'PopulationEU') -f $snapshot.EU.Total,$snapshot.EU.Enforcers,$snapshot.EU.Criminals
    $onlineNA.Text=(T 'PopulationNA') -f $snapshot.NA.Total,$snapshot.NA.Enforcers,$snapshot.NA.Criminals
    $onlineLabel.Text=(T 'PopulationStamp') -f $snapshot.SourceTime,(Get-Date -Format 'HH:mm:ss')
   }catch{Clear-Population;$onlineLabel.Text=T 'OnlineUnavailable'}
   finally{$refreshOnline.Enabled=$true;$script:onlineTask=$null;$script:onlineClient.Dispose();$script:onlineClient=$null}
  }
 })
 $form.Add_Shown({if(-not $Selbsttest -and -not $Abschlusstest){Start-OnlineRefresh;$populationRefreshTimer.Start()}})
 $form.Add_FormClosed({$onlineTimer.Stop();$onlineTimer.Dispose();$populationRefreshTimer.Stop();$populationRefreshTimer.Dispose();if($script:onlineClient){$script:onlineClient.Dispose();$script:onlineClient=$null}})
}
function Start-OnlineRefresh {
 if($script:onlineTask){return}
 $refreshOnline.Enabled=$false;$onlineLabel.Text=T 'OnlineLoading'
 try{
  [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12
  $script:onlineClient=New-Object Net.Http.HttpClient;$onlineClient.Timeout=[TimeSpan]::FromSeconds(12)
  $onlineClient.DefaultRequestHeaders.UserAgent.ParseAdd('orocleister-APB-Config/11.0')
  $onlineClient.DefaultRequestHeaders.CacheControl=New-Object Net.Http.Headers.CacheControlHeaderValue;$onlineClient.DefaultRequestHeaders.CacheControl.NoCache=$true
  $script:onlineTask=$onlineClient.GetStringAsync('https://www.gamersfirst.com/apb/status');$onlineTimer.Start()
 }catch{Clear-Population;$onlineLabel.Text=T 'OnlineUnavailable';$refreshOnline.Enabled=$true;if($script:onlineClient){$script:onlineClient.Dispose();$script:onlineClient=$null};$script:onlineTask=$null}
}
