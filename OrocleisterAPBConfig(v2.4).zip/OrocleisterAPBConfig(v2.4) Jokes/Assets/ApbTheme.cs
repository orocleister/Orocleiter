﻿using System; using System.Drawing; using System.Drawing.Drawing2D; using System.Windows.Forms; using System.Runtime.InteropServices;
public class ApbCheckBox:CheckBox {
 bool hover;
 public ApbCheckBox(){SetStyle(ControlStyles.UserPaint|ControlStyles.AllPaintingInWmPaint|ControlStyles.OptimizedDoubleBuffer,true);Cursor=Cursors.Hand;}
 protected override void OnMouseEnter(EventArgs e){hover=true;Invalidate();base.OnMouseEnter(e);}
 protected override void OnMouseLeave(EventArgs e){hover=false;Invalidate();base.OnMouseLeave(e);}
 protected override void OnCheckedChanged(EventArgs e){base.OnCheckedChanged(e);Invalidate();}
 protected override void OnPaint(PaintEventArgs e){
  var g=e.Graphics;g.Clear(BackColor);g.SmoothingMode=SmoothingMode.AntiAlias;
  // Crossed blades: red when enabled, grey outline when disabled.
  var state=g.Save();g.TranslateTransform(14,Height/2f);
  Color blade=Checked?Color.FromArgb(244,45,57):Color.FromArgb(91,105,119);
  using(var pen=new Pen(hover?Color.FromArgb(255,113,113):blade,1.3f)){
   g.DrawEllipse(pen,-11,-11,22,22);
   for(int i=0;i<2;i++){
    var sword=g.Save();g.RotateTransform(i==0?45:-45);
    PointF[] shape={new PointF(0,-13),new PointF(3,-8),new PointF(2,5),new PointF(6,5),new PointF(6,7),new PointF(1.5f,7),new PointF(1.5f,12),new PointF(-1.5f,12),new PointF(-1.5f,7),new PointF(-6,7),new PointF(-6,5),new PointF(-2,5),new PointF(-3,-8)};
    using(var fill=new SolidBrush(Checked?blade:BackColor))g.FillPolygon(fill,shape);
    g.DrawPolygon(pen,shape);g.Restore(sword);
   }
  }
  g.Restore(state);
  TextRenderer.DrawText(g,Text,Font,new Rectangle(34,0,Width-34,Height),Enabled?ForeColor:Color.Gray,TextFormatFlags.Left|TextFormatFlags.VerticalCenter|TextFormatFlags.EndEllipsis);
  if(Focused&&ShowFocusCues)ControlPaint.DrawFocusRectangle(g,new Rectangle(30,1,Width-32,Height-2));
 }
 public void ToggleForTest(){OnClick(EventArgs.Empty);}
}
public class ApbButton:Button {
 bool hover,down;
 public ApbButton(){SetStyle(ControlStyles.UserPaint|ControlStyles.AllPaintingInWmPaint|ControlStyles.OptimizedDoubleBuffer,true);Cursor=Cursors.Hand;}
 protected override void OnMouseEnter(EventArgs e){hover=true;Invalidate();base.OnMouseEnter(e);}
 protected override void OnMouseLeave(EventArgs e){hover=false;down=false;Invalidate();base.OnMouseLeave(e);}
 protected override void OnMouseDown(MouseEventArgs e){down=true;Invalidate();base.OnMouseDown(e);}
 protected override void OnMouseUp(MouseEventArgs e){down=false;Invalidate();base.OnMouseUp(e);}
 protected override void OnPaint(PaintEventArgs e){
  var g=e.Graphics;g.SmoothingMode=SmoothingMode.AntiAlias;
  bool active=BackColor.B>70;Color top=active?Color.FromArgb(0,139,213):Color.FromArgb(17,38,53);Color bottom=active?Color.FromArgb(0,53,93):Color.FromArgb(4,15,24);
  if(hover)top=Color.FromArgb(0,126,184);if(down)top=bottom;
  using(var b=new LinearGradientBrush(ClientRectangle,top,bottom,90))g.FillRectangle(b,ClientRectangle);
  Color edge=active||hover?Color.FromArgb(0,184,250):Color.FromArgb(39,79,101);
  if(Text=="FreeDemoTriggerBot")edge=Color.FromArgb(146,56,70);
  using(var pen=new Pen(edge))g.DrawRectangle(pen,0,0,Width-1,Height-1);
  using(var pen=new Pen(Color.FromArgb(60,170,218))){if(active||hover)g.DrawLine(pen,3,2,Width-4,2);}
  TextRenderer.DrawText(g,Text,Font,ClientRectangle,ForeColor,TextFormatFlags.HorizontalCenter|TextFormatFlags.VerticalCenter|TextFormatFlags.EndEllipsis);
  if(Focused&&ShowFocusCues)ControlPaint.DrawFocusRectangle(g,new Rectangle(4,4,Width-8,Height-8));
 }
}
public class ApbComboBox:ComboBox {
 public ApbComboBox(){DrawMode=DrawMode.OwnerDrawFixed;ItemHeight=22;FlatStyle=FlatStyle.Flat;BackColor=Color.FromArgb(10,27,40);ForeColor=Color.FromArgb(235,244,249);}
 protected override void OnDrawItem(DrawItemEventArgs e){
  var selected=(e.State&DrawItemState.Selected)!=0 && (e.State&DrawItemState.ComboBoxEdit)==0;
  using(var brush=new SolidBrush(selected?Color.FromArgb(0,81,124):Color.FromArgb(10,27,40)))e.Graphics.FillRectangle(brush,e.Bounds);
  string text=e.Index>=0?GetItemText(Items[e.Index]):Text;
  TextRenderer.DrawText(e.Graphics,text,Font,new Rectangle(e.Bounds.X+7,e.Bounds.Y,e.Bounds.Width-10,e.Bounds.Height),ForeColor,TextFormatFlags.Left|TextFormatFlags.VerticalCenter|TextFormatFlags.EndEllipsis);
 }
 protected override void WndProc(ref Message m){base.WndProc(ref m);if(m.Msg==0xF){using(var g=CreateGraphics())using(var b=new SolidBrush(Color.FromArgb(10,27,40)))using(var pen=new Pen(Color.FromArgb(60,106,132))){g.FillRectangle(b,Width-21,1,20,Height-2);g.DrawRectangle(pen,0,0,Width-1,Height-1);g.DrawLines(pen,new Point[]{new Point(Width-15,Height/2-2),new Point(Width-10,Height/2+3),new Point(Width-5,Height/2-2)});}}}
}
public class ApbSurface:Panel {
 public ApbSurface(){DoubleBuffered=true;Padding=new Padding(1);}
 protected override void OnPaint(PaintEventArgs e){base.OnPaint(e);using(var pen=new Pen(Color.FromArgb(37,75,96)))e.Graphics.DrawRectangle(pen,0,0,Width-1,Height-1);using(var pen=new Pen(Color.FromArgb(0,166,227),2)){e.Graphics.DrawLine(pen,0,0,34,0);e.Graphics.DrawLine(pen,0,0,0,20);e.Graphics.DrawLine(pen,Width-35,Height-1,Width-1,Height-1);}}
}
public static class ApbWindowTheme {
 [DllImport("dwmapi.dll")] static extern int DwmSetWindowAttribute(IntPtr hwnd,int attr,ref int value,int size);
 public static void DarkTitle(Form f){try{int yes=1;DwmSetWindowAttribute(f.Handle,20,ref yes,4);}catch{}}
}
