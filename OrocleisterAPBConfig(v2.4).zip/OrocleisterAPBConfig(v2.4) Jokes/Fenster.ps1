﻿param([switch]$Selbsttest,[switch]$Abschlusstest)
$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -Path (Join-Path $PSScriptRoot 'Assets\ApbTheme.cs') -ReferencedAssemblies System.Windows.Forms,System.Drawing
[Windows.Forms.Application]::EnableVisualStyles()
. (Join-Path $PSScriptRoot 'Config-Menue.ps1') -NurLaden
$translations=Get-Content (Join-Path $PSScriptRoot 'Languages.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$script:UiLanguage='en';$script:localized=New-Object 'System.Collections.Generic.List[object]'
$script:choices=New-Object 'System.Collections.Generic.List[object]';$script:checks=New-Object 'System.Collections.Generic.List[object]'
$script:pageIndex=0
function T([string]$key){$prop=$translations.($script:UiLanguage).PSObject.Properties[$key];if(-not $prop){$prop=$translations.en.PSObject.Properties[$key]};if($prop){return [string]$prop.Value};return $key}
$form=New-Object Windows.Forms.Form;$form.Text='OrocleisterAPBConfig(v2.4) Jokes';$form.ClientSize=New-Object Drawing.Size(1240,850)
$form.StartPosition='CenterScreen';$form.FormBorderStyle='FixedDialog';$form.MaximizeBox=$false;$form.AutoScaleMode='None';$form.Font=New-Object Drawing.Font('Segoe UI',10)
$form.Icon=New-Object Drawing.Icon((Join-Path $PSScriptRoot 'Assets\app.ico'))
$bg=[Drawing.Image]::FromFile((Join-Path $PSScriptRoot 'Assets\background.png'));$form.BackgroundImage=$bg;$form.BackgroundImageLayout='Stretch'
$dark=[Drawing.Color]::FromArgb(7,18,28);$ink=[Drawing.Color]::FromArgb(235,244,249);$muted=[Drawing.Color]::FromArgb(162,182,198);$blue=[Drawing.Color]::FromArgb(0,160,218)
function Register($c,$key){$c.Tag=$key;$c.Text=T $key;$script:localized.Add($c)}
function Label($parent,$key,$x,$y,$w,$h=24){$c=New-Object Windows.Forms.Label;$c.SetBounds($x,$y,$w,$h);$c.ForeColor=$muted;$c.BackColor=[Drawing.Color]::Transparent;Register $c $key;$parent.Controls.Add($c);return $c}
function Button($parent,$key,$x,$y,$w,$action){$c=New-Object ApbButton;$c.SetBounds($x,$y,$w,38);$c.ForeColor=$ink;$c.BackColor=$dark;Register $c $key;$c.Add_Click($action);$parent.Controls.Add($c);return $c}
function Field($parent,$x,$y,$w,$value){$c=New-Object Windows.Forms.TextBox;$c.SetBounds($x,$y,$w,30);$c.BackColor=[Drawing.Color]::FromArgb(12,31,43);$c.ForeColor=$ink;$c.BorderStyle='FixedSingle';$c.Text=$value;$parent.Controls.Add($c);return $c}
function Choice($parent,$property,$key,$help,$y,$values,$labels,$helpHeight=67){
 $null=Label $parent $key 18 $y 350 28
 $c=New-Object ApbComboBox;$c.SetBounds(383,$y,322,30);$c.DropDownStyle='DropDownList'
 foreach($item in $labels){[void]$c.Items.Add((T $item))}
 $c.SelectedIndex=[Math]::Max(0,[array]::IndexOf($values,[string]$s.$property));$parent.Controls.Add($c)
 $script:choices.Add(@{Control=$c;Property=$property;Values=$values;Labels=$labels})
 if($help){$null=Label $parent $help 18 ($y+40) 687 $helpHeight}
 return $c
}
function CheckOpt($parent,$property,$key,$help,$y){
 $c=New-Object ApbCheckBox;$c.SetBounds(18,$y,687,28);$c.Checked=[bool]$s.$property;$c.ForeColor=$ink;$c.BackColor=$dark;Register $c $key;$parent.Controls.Add($c)
 $script:checks.Add(@{Control=$c;Property=$property})
 if($help){$null=Label $parent $help 52 ($y+31) 653 46}
 return $c
}
$surface=New-Object ApbSurface;$surface.SetBounds(20,225,936,538);$surface.BackColor=$dark;$form.Controls.Add($surface)
$pages=@();foreach($i in 0..6){$p=New-Object Windows.Forms.Panel;$p.SetBounds(192,13,727,511);$p.BackColor=$dark;$surface.Controls.Add($p);$pages+=,$p}
$nav=@()
function Show-Page($index){$script:pageIndex=$index;for($i=0;$i -lt $pages.Count;$i++){$pages[$i].Visible=($i -eq $index);$nav[$i].BackColor=$dark;if($i -eq $index){$nav[$i].BackColor=$blue}}}
$navKeys=@('NavBasic','NavAdvanced','NavAudio','NavControls','NavLaunch','NavTools','NavExperimental')
for($i=0;$i -lt 7;$i++){$b=Button $surface $navKeys[$i] 14 (15+$i*51) 162 {};$b.Tag=$navKeys[$i];$b.AccessibleDescription=[string]$i;$b.Add_Click({Show-Page ([int]$this.AccessibleDescription)});$nav+=,$b}
$null=Label $surface 'SidebarNote' 18 397 154 108
# BASIC
$null=Label $pages[0] 'GameLocation' 18 4 687
$path=Field $pages[0] 18 32 540 $s.Spielordner
$null=Button $pages[0] 'Auswaehlen' 568 27 137 {
 $d=New-Object Windows.Forms.OpenFileDialog;$d.Title=T 'ChooseShortcut';$d.Filter='APB shortcut or executable|*.lnk;APB.exe';$d.DereferenceLinks=$false
 try{if($d.ShowDialog() -eq 'OK'){
  if([IO.Path]::GetExtension($d.FileName) -ieq '.lnk'){Import-APBShortcut $d.FileName;$path.Text=$s.Spielordner;foreach($item in $script:checks){if($item.Property -eq 'NoSteam'){$item.Control.Checked=$s.NoSteam}}}
  else{$path.Text=Split-Path (Split-Path $d.FileName -Parent) -Parent;$s.ShortcutPath='';$s.LaunchArguments='-language=1031'}
 }}catch{Show-Error $_}finally{$d.Dispose()}
}
$null=Label $pages[0] 'ResolutionLabel' 18 86 327
$resolution=New-Object ApbComboBox;$resolution.SetBounds(18,115,328,30);$resolution.DropDownStyle='DropDownList';$resolution.Items.AddRange(@((T 'KeepResolution'),'1280x720','1280x1024','1600x900','1920x1080','2560x1440','3840x2160'));$pages[0].Controls.Add($resolution)
$resolution.SelectedIndex=0;if($s.Resolution -ne 'Keep'){if(-not $resolution.Items.Contains($s.Resolution)){[void]$resolution.Items.Add($s.Resolution)};$resolution.SelectedItem=$s.Resolution}
$null=Label $pages[0] 'AALabel' 375 86 330
$aa=New-Object ApbComboBox;$aa.SetBounds(375,115,330,30);$aa.DropDownStyle='DropDownList';$aa.Items.AddRange(@((T 'KeepSetting'),(T 'AAOff'),'2x MSAA','4x MSAA','8x MSAA'));$aa.SelectedIndex=[Math]::Max(0,[array]::IndexOf(@('Keep','Off','2','4','8'),[string]$s.AAMode));$pages[0].Controls.Add($aa)
$null=Label $pages[0] 'FPS-Limit' 18 174 125
$fps=Field $pages[0] 18 203 120 ([string]$s.FPSLimit)
$null=Label $pages[0] 'BasicFPSHelp' 158 199 547 45
$null=Label $pages[0] 'GraphicsLabel' 18 260 687
$normal=Button $pages[0] 'GraphicsNormal' 18 291 328 {$script:extremeSelected=$false;Update-Graphics}
$low=Button $pages[0] 'GraphicsExtreme' 375 291 330 {$script:extremeSelected=$true;Update-Graphics}
$normal.Height=49;$low.Height=49;$script:extremeSelected=[bool]$s.ExtremeTextures
$script:graphicsHelp=Label $pages[0] 'GraphicsNormalHelp' 18 356 687 58
function Update-Graphics {$normal.BackColor=$blue;$low.BackColor=$dark;$graphicsHelp.Tag='GraphicsNormalHelp';if($script:extremeSelected){$normal.BackColor=$dark;$low.BackColor=[Drawing.Color]::FromArgb(110,38,90);$graphicsHelp.Tag='GraphicsExtremeHelp'};$graphicsHelp.Text=T $graphicsHelp.Tag}
$social=New-Object ApbCheckBox;$social.SetBounds(18,430,687,28);$social.Checked=($s.Modus -eq 'Social');$social.ForeColor=$ink;$social.BackColor=$dark;Register $social 'SocialCheck';$pages[0].Controls.Add($social)
$null=Label $pages[0] 'BasicSocialHelp' 52 462 653 43
# ADVANCED EFFECTS
$s | Add-Member -NotePropertyName VehicleFireUI -NotePropertyValue ($s.Effekte -eq 'Normal') -Force
$fire=CheckOpt $pages[1] 'VehicleFireUI' 'FireCheck' 'FireHelpShort' 7
$trail=CheckOpt $pages[1] 'Granatenspur' 'TrailCheck' 'TrailHelpShort' 91
$ambient=CheckOpt $pages[1] 'UmgebungspartikelAus' 'AmbientCheck' 'AmbientHelpShort' 175
$muzzle=CheckOpt $pages[1] 'MuzzleFlash' 'MuzzleFlashLabel' 'MuzzleFlashHelp' 259
$casings=CheckOpt $pages[1] 'ShellCasings' 'ShellCasingsLabel' 'ShellCasingsHelp' 343
$null=Label $pages[1] 'BloodHelpShort' 18 440 687 65
# AUDIO
$voice=Choice $pages[2] 'VoiceMode' 'VoiceLabel' 'VoiceSystemHelp' 3 @('Keep','Off','On') @('KeepSetting','VoiceDisabled','VoiceEnabled') 67
$duck=Choice $pages[2] 'DuckingMode' 'DuckingLabel' 'DuckingHelpShort' 115 @('Keep','Off','On') @('KeepSetting','SettingOff','SettingOn') 42
$themes=Choice $pages[2] 'DeathThemesMode' 'DeathThemesLabel' 'DeathThemesHelpShort' 205 @('Keep','Off','On') @('KeepSetting','Muted','Audible') 40
$created=Choice $pages[2] 'CreatedSongsMode' 'CreatedSongsLabel' 'CreatedSongsHelp' 290 @('Keep','Off','On') @('KeepSetting','Muted','Audible') 40
$musicVolume=Choice $pages[2] 'MusicPlayerVolume' 'MusicPlayerLabel' 'MusicPlayerHelp' 375 @('Keep','0','25','50','75','100') @('KeepSetting','MusicMute','25%','50%','75%','100%') 40
$null=Button $pages[2] 'OnlyThemes' 18 465 687 {$themes.SelectedIndex=2;$created.SelectedIndex=1;$musicVolume.SelectedIndex=1}
# CONTROLS
$mouse=Choice $pages[3] 'MouseMode' 'MouseLabel' 'MouseModeHelp' 9 @('Keep','Standard','Default','Legacy') @('KeepSetting','MouseStandard','MouseDefault','MouseLegacy')
$dot=Choice $pages[3] 'SprintDotMode' 'SprintDot' 'SprintHelp' 127 @('Keep','Off','On') @('KeepSetting','SettingOff','SettingOn')
$autoReady=Choice $pages[3] 'AutoReadyMode' 'AutoReadyLabel' 'AutoReadyHelp' 241 @('Keep','Off','On') @('KeepSetting','SettingOff','SettingOn')
$hud=CheckOpt $pages[3] 'ResetHUDScale' 'ResetHUDScale' 'HUDHelpShort' 359
$null=Button $pages[3] 'CrosshairRules' 18 462 687 {Open-CommunityLink 'https://www.gamersfirst.com/apb/news/2024/8/14/sard-faq'}
# LAUNCH
$movies=CheckOpt $pages[4] 'SkipMovies' 'SkipMovies' 'MoviesHelp' 3
$splash=CheckOpt $pages[4] 'SkipSplash' 'SkipSplash' 'SplashHelp' 82
$steam=CheckOpt $pages[4] 'NoSteam' 'NoSteamLabel' 'NoSteamHelp' 161
$login=CheckOpt $pages[4] 'SchwarzerLogin' 'BlackLoginShort' 'BlackLoginHelp' 240
$loc=CheckOpt $pages[4] 'EigeneLocalization' 'CustomTextLabel' 'CustomTextHelp' 319
$null=Label $pages[4] 'LaunchFooter' 18 482 687 26
# EXPERIMENTAL
$shader=Choice $pages[6] 'ShaderDotMode' 'ShaderDotTitle' 'ShaderDotHelp' 10 @('Keep','Off','On') @('KeepSetting','ShaderRemove','ShaderInstall') 105
$risk=CheckOpt $pages[6] 'ShaderRiskAccepted' 'ShaderConsent' 'ShaderWarning' 168
$null=Label $pages[6] 'ShaderLimits' 18 257 687 125
$null=Button $pages[6] 'ShaderSource' 18 407 330 {Open-CommunityLink 'https://zhyk.org/forum/showthread.php?t=466225'}
$null=Button $pages[6] 'CrosshairRules' 365 407 340 {Open-CommunityLink 'https://www.gamersfirst.com/apb/news/2024/8/14/sard-faq'}
# TOOLS
$stream=CheckOpt $pages[5] 'TexturStreaming' 'StreamingShort' 'StreamingHelp' 7
$cache=CheckOpt $pages[5] 'DiskCache' 'DiskCacheShort' 'DiskCacheHelp' 91
$null=Label $pages[5] 'Gamma' 18 183 400
$gamma=New-Object Windows.Forms.NumericUpDown;$gamma.SetBounds(490,178,215,30);$gamma.Minimum=1;$gamma.Maximum=5;$gamma.DecimalPlaces=6;$gamma.Increment=[decimal]0.1;$gamma.Value=[decimal]$s.Gamma;$gamma.BackColor=$dark;$gamma.ForeColor=$ink;$pages[5].Controls.Add($gamma)
$null=Label $pages[5] 'GammaHelpShort' 18 222 687 57
$null=Label $pages[5] 'DoubleBufferingInfo' 18 288 687 43
$null=Button $pages[5] 'Restore' 18 347 687 {try{Read-Form;Restore-Last;Set-Status 'RestoreDone'}catch{Show-Error $_}}
$null=Button $pages[5] 'ReadGuide' 18 398 687 {try{Start-Process notepad.exe -ArgumentList ('"'+(Join-Path $PSScriptRoot ('README.'+$script:UiLanguage+'.md'))+'"')}catch{Show-Error $_}}
$null=Label $pages[5] 'ToolsFooter' 18 456 687 45
function Read-Form {
 $n=0;if(-not [string]::IsNullOrWhiteSpace($fps.Text)){if(-not [int]::TryParse($fps.Text,[ref]$n) -or $n -lt 0 -or $n -gt 1000){throw (T 'FPS: eine Zahl von 0 bis 1000 eingeben, oder leer lassen.')}}
 $s.Spielordner=$path.Text.Trim().Trim('"');$s.FPSLimit=$n;$s.Modus='NoSocial';if($social.Checked){$s.Modus='Social'}
 foreach($item in $script:checks){$s.($item.Property)=$item.Control.Checked}
 foreach($item in $script:choices){$s.($item.Property)=$item.Values[$item.Control.SelectedIndex]}
 $s.Effekte='Reduziert';if($fire.Checked){$s.Effekte='Normal'}
 $s.ExtremeTextures=$script:extremeSelected;$s.Gamma=[double]$gamma.Value
 $s.Resolution='Keep';if($resolution.SelectedIndex -gt 0){$s.Resolution=[string]$resolution.SelectedItem}
 $s.AAMode=@('Keep','Off','2','4','8')[$aa.SelectedIndex]
 if($s.MouseMode -eq 'Keep'){$s.MouseSmoothingMode='Keep'}
}
function Set-Status($key){$status.Tag=$key;$status.Text=T $key}
function Show-Error($e){[void][Windows.Forms.MessageBox]::Show((T ([string]$e)),'orocleister','OK','Error')}
function Action($start){try{Read-Form;if($start){$launcher=Get-APBLauncherInfo};Apply-Config;if($start){Start-Process @launcher -ErrorAction Stop;$form.Close()}else{Set-Status 'Saved'}}catch{Show-Error $_}}
function Play-Only {try{Read-Form;Start-APBShortcut;Save-Settings;$form.Close()}catch{Show-Error $_}}
$null=Button $form 'Nur anwenden' 20 775 280 {Action $false}
$null=Button $form 'Anwenden && Spielen' 314 775 312 {Action $true}
$play=Button $form 'PlayOnly' 640 775 316 {Play-Only};$play.BackColor=$blue
$status=Label $form 'FooterReady' 20 822 936 25;$status.BackColor=$dark;$status.Font=New-Object Drawing.Font('Segoe UI',9)
$language=New-Object ApbComboBox;$language.SetBounds(1040,43,175,30);$language.DropDownStyle='DropDownList';$language.Items.AddRange(@('English','Deutsch','Русский'));$form.Controls.Add($language)
$language.Add_SelectedIndexChanged({
 $script:UiLanguage=@('en','de','ru')[$language.SelectedIndex]
 foreach($c in $script:localized){$c.Text=T ([string]$c.Tag)}
 foreach($item in $script:choices){$index=$item.Control.SelectedIndex;for($i=0;$i -lt $item.Labels.Count;$i++){$item.Control.Items[$i]=T $item.Labels[$i]};$item.Control.SelectedIndex=$index}
 $resolution.Items[0]=T 'KeepResolution';$aa.Items[0]=T 'KeepSetting';$aa.Items[1]=T 'AAOff';Update-Graphics
})
. (Join-Path $PSScriptRoot 'Community.ps1');Add-CommunityPanel
$easterEgg=Button $form 'FreeDemoTriggerBot' 976 775 244 {Open-CommunityLink 'https://www.youtube.com/watch?v=f77PLFRP3Ok'}
$language.SelectedIndex=0;Update-Graphics;Show-Page 0;[ApbWindowTheme]::DarkTitle($form)
# EDITION_HOOK
if($Selbsttest){
 $fps.Text='';Read-Form;if($s.FPSLimit -ne 0){throw 'Empty FPS failed'};$fps.Text='144'
 $fps.Text='bad';$caught=$false;try{Read-Form}catch{$caught=$true};if(-not $caught){throw 'FPS validation failed'};$fps.Text='144'
 $script:extremeSelected=$true;$mouse.SelectedIndex=3;$aa.SelectedIndex=3;$voice.SelectedIndex=1;Read-Form
 if(-not $s.ExtremeTextures -or $s.MouseMode -ne 'Legacy' -or $s.AAMode -ne '4' -or $s.VoiceMode -ne 'Off'){throw 'New control mapping failed'}
 $script:extremeSelected=$false;$mouse.SelectedIndex=0;$aa.SelectedIndex=1;$voice.SelectedIndex=0
 $social.ToggleForTest();$social.ToggleForTest();Read-Form
 $form.StartPosition='Manual';$form.Location=New-Object Drawing.Point(-10000,-10000);$form.Show();[Windows.Forms.Application]::DoEvents()
 foreach($li in 0..2){$language.SelectedIndex=$li;foreach($pi in 0..6){Show-Page $pi;[Windows.Forms.Application]::DoEvents();$bitmap=New-Object Drawing.Bitmap($form.Width,$form.Height);$form.DrawToBitmap($bitmap,(New-Object Drawing.Rectangle(0,0,$form.Width,$form.Height)));$bitmap.Save((Join-Path $PSScriptRoot ('Preview-v11-'+$script:UiLanguage+'-'+$pi+'.png')));$bitmap.Dispose()}}
 $language.SelectedIndex=0;if($script:UiLanguage -ne 'en'){throw 'English default failed'}
 $form.Dispose();$bg.Dispose();Write-Output 'PASS: 7 pages / 3 languages, FPS validation, graphics/audio/mouse/MSAA mapping; no game files changed.';return
}
[void]$form.ShowDialog();$form.Dispose();$bg.Dispose()
# EDITION_CLOSE
