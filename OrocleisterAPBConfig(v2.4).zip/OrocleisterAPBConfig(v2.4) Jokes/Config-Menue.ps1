﻿param([switch]$Pruefen,[switch]$NurLaden)
$ErrorActionPreference='Stop'
$script:HomePath=$PSScriptRoot
$settingsPath=Join-Path $PSScriptRoot 'Einstellungen.json'
$s=Get-Content -LiteralPath $settingsPath -Raw | ConvertFrom-Json
foreach($entry in @{ShaderDotMode='Keep';ShaderRiskAccepted=$false;CreatedSongsMode='Keep';MusicPlayerVolume='Keep';MouseMode='Keep';AAMode='Off';NoSteam=$false;MouseSmoothingMode='Keep';AutoReadyMode='Keep';DeathThemesMode='Keep';MuzzleFlash=$false;ShellCasings=$false;ExtremeTextures=$false;SprintDotMode='Keep';ResetHUDScale=$false;SkipMovies=$true;SkipSplash=$true;VoiceMode='Keep';DuckingMode='Keep';ExtraHumor=$true;UmgebungspartikelAus=$true;Granatenspur=$true;Resolution='Keep';ShortcutPath='';LaunchArguments='-language=1031'}.GetEnumerator()){
    if(-not $s.PSObject.Properties[$entry.Key]){$s | Add-Member -NotePropertyName $entry.Key -NotePropertyValue $entry.Value}
}
$s.ExtraHumor=$true
function Save-Settings { $s | ConvertTo-Json | Set-Content -LiteralPath $settingsPath -Encoding UTF8 }
function Set-Value([string]$text,[string]$key,[string]$value) {
    $rx='(?m)^'+[regex]::Escape($key)+'\s*=.*$'
    if(-not [regex]::IsMatch($text,$rx)){throw "Einstellung fehlt: $key"}
    return [regex]::Replace($text,$rx,($key+'='+$value))
}
function Set-IniOption([string]$text,[string]$section,[string]$key,[string]$value) {
 $sectionRx='(?ms)^\['+[regex]::Escape($section)+'\][^\r\n]*\r?\n(?<body>.*?)(?=^\[|\z)'
 $match=[regex]::Match($text,$sectionRx)
 if(-not $match.Success){return $text.TrimEnd()+"`r`n`r`n["+$section+"]`r`n"+$key+'='+$value+"`r`n"}
 $body=$match.Groups['body'].Value
 $keyRx='(?m)^'+[regex]::Escape($key)+'\s*=.*$'
 if([regex]::IsMatch($body,$keyRx)){$body=[regex]::Replace($body,$keyRx,($key+'='+$value))}
 else{$body=$key+'='+$value+"`r`n"+$body}
 $start=$match.Groups['body'].Index
 return $text.Substring(0,$start)+$body+$text.Substring($start+$match.Groups['body'].Length)
}
function Write-Text([string]$path,[string]$text) {
    [IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($path)) | Out-Null
    [IO.File]::WriteAllText($path,$text,(New-Object Text.UTF8Encoding($false)))
}
function Check-Game {
    if(Get-Process APB,APBLauncher -ErrorAction SilentlyContinue){throw 'APB und Launcher zuerst komplett beenden.'}
    if(-not $s.Spielordner -or -not (Test-Path -LiteralPath (Join-Path $s.Spielordner 'Binaries\APB.exe'))){throw 'Zuerst den Spielordner einstellen (enthaelt Binaries\APB.exe).'}
    $s.Spielordner=[IO.Path]::GetFullPath($s.Spielordner).TrimEnd('\')
}
function Import-APBShortcut([string]$shortcutPath) {
    $shortcutPath=[IO.Path]::GetFullPath($shortcutPath)
    if([IO.Path]::GetExtension($shortcutPath) -ne '.lnk' -or -not (Test-Path -LiteralPath $shortcutPath)){throw 'Select an existing APB .lnk shortcut.'}
    $shell=New-Object -ComObject WScript.Shell
    try{
        $link=$shell.CreateShortcut($shortcutPath)
        $target=[Environment]::ExpandEnvironmentVariables($link.TargetPath)
        if([IO.Path]::GetFileName($target) -ine 'APB.exe' -or -not (Test-Path -LiteralPath $target)){throw 'The shortcut must point directly to APB.exe, not the launcher.'}
        if([IO.Path]::GetFileName([IO.Path]::GetDirectoryName($target)) -ine 'Binaries'){throw 'Select APB.exe inside the Binaries folder.'}
        $s.Spielordner=Split-Path (Split-Path $target -Parent) -Parent
        $s.ShortcutPath=$shortcutPath
        $s.LaunchArguments=[string]$link.Arguments
        $s.NoSteam=([string]$link.Arguments -match '(?i)(?<!\S)-nosteam(?!\S)')
    }finally{if($link){[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($link)};[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($shell)}
}
function Get-APBArguments {
    $arguments=[string]$s.LaunchArguments
    if($s.EigeneLocalization -or [string]::IsNullOrWhiteSpace($arguments)){
        $arguments=[regex]::Replace($arguments,'(?i)(?<!\S)-language=(?:"[^"]*"|\S+)','').Trim()
        $arguments=('-language=1031 '+$arguments).Trim()
    }
    $arguments=[regex]::Replace($arguments,'(?i)(?<!\S)-(?:nomoviesstartup|nomovies|nosplash|nosteam)(?!\S)','').Trim()
    if($s.SkipMovies){$arguments+=' -nomovies'}
    if($s.SkipSplash){$arguments+=' -nosplash'}
    if($s.NoSteam){$arguments+=' -nosteam'}
    return $arguments.Trim()
}
function Update-APBShortcut([string]$backupFolder) {
    $destination=[string]$s.ShortcutPath
    if([string]::IsNullOrWhiteSpace($destination)){$destination=Join-Path $script:HomePath 'APB-Direct.lnk'}
    $destination=[IO.Path]::GetFullPath($destination)
    if([IO.Path]::GetExtension($destination) -ine '.lnk'){throw 'Shortcut path must end in .lnk.'}
    $existed=Test-Path -LiteralPath $destination
    if($existed){Copy-Item -LiteralPath $destination -Destination (Join-Path $backupFolder 'shortcut-before.lnk')}
    @{Path=$destination;Existed=$existed} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $backupFolder 'shortcut.json') -Encoding UTF8
    $shell=New-Object -ComObject WScript.Shell
    try{
        $link=$shell.CreateShortcut($destination)
        $link.TargetPath=Join-Path $s.Spielordner 'Binaries\APB.exe'
        $link.Arguments=Get-APBArguments
        $link.WorkingDirectory=Join-Path $s.Spielordner 'Binaries'
        $link.Description='APB Reloaded - direct start with installed configuration'
        $link.Save()
    }finally{if($link){[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($link)};[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($shell)}
}

function Get-APBLaunchInfo {
    Check-Game
    return @{FilePath=(Join-Path $s.Spielordner 'Binaries\APB.exe');WorkingDirectory=(Join-Path $s.Spielordner 'Binaries');ArgumentList=(Get-APBArguments)}
}
function Start-APBDirect {
    $launch=Get-APBLaunchInfo
    Start-Process @launch -PassThru -ErrorAction Stop | Out-Null
}
function Get-APBLauncherInfo {
 Check-Game
 foreach($relative in @('Launcher\APBLauncher.exe','APBLauncher.exe','Binaries\APBLauncher.exe')){
  $exe=Join-Path $s.Spielordner $relative
  if(Test-Path -LiteralPath $exe){return @{FilePath=$exe;WorkingDirectory=(Split-Path $exe -Parent)}}
 }
 throw 'APBLauncher.exe not found in the selected game folder.'
}
function Start-APBShortcut {
 Check-Game
 $backup=Join-Path $script:HomePath ('Backups\shortcut-'+(Get-Date -Format 'yyyyMMdd-HHmmss-fff'))
 [IO.Directory]::CreateDirectory($backup) | Out-Null
 Update-APBShortcut $backup
 $destination=[string]$s.ShortcutPath
 if([string]::IsNullOrWhiteSpace($destination)){$destination=Join-Path $script:HomePath 'APB-Direct.lnk'}
 Start-Process -FilePath $destination -WorkingDirectory (Join-Path $s.Spielordner 'Binaries') -ErrorAction Stop
}
function Set-MouseAxes([string]$text,[string]$speed) {
 $rx='(?ms)^\[Engine.PlayerInput\][^\r\n]*\r?\n.*?(?=^\[|\z)'
 return [regex]::Replace($text,$rx,{
  param($section)
  [regex]::Replace($section.Value,'(?m)^[+.\-]?Bindings=\(Name="Mouse[XY]",Command="[^"\r\n]*"[^\r\n]*\r?$',{
   param($line)
   [regex]::Replace($line.Value,'Axis aMouse([XY])(?: Speed=[+\-0-9.]+)?',('Axis aMouse$1 Speed='+$speed))
  })
 })
}
function Set-CenterDot([byte[]]$bytes,[string]$mode) {
 $encoding=[Text.Encoding]::GetEncoding(28591)
 $text=$encoding.GetString($bytes)
 $begin='// OROCLEISTER_CENTER_DOT_BEGIN';$end='// OROCLEISTER_CENTER_DOT_END'
 $pattern='(?s)\r?\n[ \t]*'+$begin+'.*?'+$end+'\r?\n'
 $clean=[regex]::Replace($text,$pattern,'')
 if($mode -eq 'Off'){return ,$encoding.GetBytes($clean)}
 if($mode -ne 'On'){return ,$bytes}
 $anchor='(?m)^[ \t]*OutColor = float4\(AdjustedColour, (?:FocusedSceneColorAndDepth|sceneColor)\.a\);'
 if([regex]::Matches($clean,$anchor).Count -ne 1 -or $clean -notmatch 'in float2 SceneUV\s*:') {throw 'ShaderUnsupported'}
 $block="`r`n"+$begin+"`r`n"+@'
    if(SceneUV.x >= 0.4995 && SceneUV.x <= 0.5005 && SceneUV.y >= 0.499 && SceneUV.y <= 0.501)
        OutColor.rgb = 1 - OutColor.rgb;
    else if(SceneUV.x >= 0.4990 && SceneUV.x <= 0.5010 && SceneUV.y >= 0.498 && SceneUV.y <= 0.502)
        OutColor.rgb = float3(0, 0, 0);
'@+"`r`n"+$end+"`r`n"
 $match=[regex]::Match($clean,$anchor)
 return ,$encoding.GetBytes($clean.Insert($match.Index+$match.Length,$block))
}

function Apply-Config {
    Check-Game
    if($s.MouseMode -notin @('Keep','Standard','Default','Legacy')){throw 'Invalid mouse mode.'}
    if($s.MouseMode -ne 'Keep'){$s.MouseSmoothingMode='Off';if($s.MouseMode -eq 'Default'){$s.MouseSmoothingMode='On'}}
    if($s.AAMode -notin @('Keep','Off','2','4','8')){throw 'Invalid anti-aliasing choice.'}
    if($s.CreatedSongsMode -notin @('Keep','Off','On')){throw 'Invalid created-song mode.'}
    if($s.MusicPlayerVolume -notin @('Keep','0','25','50','75','100')){throw 'Invalid music player volume.'}
    $aa='1'
    if($s.AAMode -eq 'Keep'){
        $oldMachine=Join-Path $s.Spielordner 'APBGame\Config\APBMachineOptions.ini'
        if(Test-Path -LiteralPath $oldMachine){$oldAA=[regex]::Match([IO.File]::ReadAllText($oldMachine),'(?m)^MSAA_Amount=(\d+)');if($oldAA.Success -and $oldAA.Groups[1].Value -in @('2','4','8','16')){$aa=$oldAA.Groups[1].Value}}
    }elseif($s.AAMode -ne 'Off'){$aa=[string]$s.AAMode}
    if($s.Modus -notin @('Social','NoSocial') -or $s.Effekte -notin @('Normal','Reduziert')){throw 'Ungueltiges Profil.'}
    if([int]$s.FPSLimit -lt 0 -or [int]$s.FPSLimit -gt 1000){throw 'FPS muss 0 bis 1000 sein.'}
    $source=Join-Path $script:HomePath ('Profile\'+$s.Modus+'\'+$s.Effekte)
    $jobs=New-Object 'System.Collections.Generic.List[object]'
    foreach($file in Get-ChildItem -LiteralPath $source -Recurse -File){
        $relative=$file.FullName.Substring($source.Length+1)
        $text=[IO.File]::ReadAllText($file.FullName)
        if($relative -eq 'Engine\Config\BaseEngine.ini'){
            $text=Set-Value $text 'MaxClientFrameRate' ([string]$s.FPSLimit)
            $text=Set-Value $text 'bUseTextureStreaming' ([string][bool]$s.TexturStreaming)
            $text=Set-Value $text 'bUseLightingTextureStreaming' ([string][bool]$s.TexturStreaming)
        }
        if($relative -in @('APBGame\Config\APBMachineOptions.ini','APBGame\Config\APBCompat.ini','APBGame\Config\DefaultMachineOptions.ini')){
            $text=[regex]::Replace($text,'(?im)^(MaxMultiSamples|MSAA_Amount)=.*$',('$1='+$aa))
        }
        if($relative -eq 'APBGame\Config\DefaultGame.ini'){
            $text=Set-Value $text 'm_bEnableMuzzleFlash' ([string][bool]$s.MuzzleFlash)
            $text=Set-Value $text 'm_bEnableMagazineCasings' ([string][bool]$s.ShellCasings)
        }
        if($relative -eq 'APBGame\Config\DefaultInput.ini' -and $s.MouseSmoothingMode -eq 'Keep'){
            $inputExisting=Join-Path $s.Spielordner $relative
            if(Test-Path -LiteralPath $inputExisting){
                $smoothing=[regex]::Match([IO.File]::ReadAllText($inputExisting),'(?m)^bEnableMouseSmoothing=([^\r\n]+)')
                if($smoothing.Success){$text=Set-IniOption $text 'Engine.PlayerInput' 'bEnableMouseSmoothing' $smoothing.Groups[1].Value}
            }
        }
        if($relative -eq 'APBGame\Config\DefaultInput.ini' -and $s.MouseSmoothingMode -ne 'Keep'){
            $text=Set-IniOption $text 'Engine.PlayerInput' 'bEnableMouseSmoothing' ([string]($s.MouseSmoothingMode -eq 'On'))
        }
        if($relative -eq 'APBGame\Config\DefaultEngine.ini'){
            $text=Set-Value $text 'm_bUseDiskCache' ([string][bool]$s.DiskCache)
            $map='APBLoginLevel.apb'; if($s.SchwarzerLogin){$map='UIDistrict_DistrictSelect.apb'}
            $text=Set-Value $text 'Map' $map
            $text=Set-Value $text 'LocalMap' $map
        }
        if($relative -eq 'APBGame\Config\APBMachineOptions.ini'){
            # Preserve actual installed resolution and window mode, not template values.
            $existingPath=Join-Path $s.Spielordner $relative
            $existing='';if(Test-Path -LiteralPath $existingPath){$existing=[IO.File]::ReadAllText($existingPath)}
            foreach($key in @('ResX','ResY','Fullscreen')){
                $match=[regex]::Match($existing,('(?m)^'+$key+'=([^\r\n]+)'))
                if($match.Success){
                    if($text -match ('(?m)^'+$key+'=')){$text=Set-Value $text $key $match.Groups[1].Value}
                    else{$text=$text.Replace('[SystemSettings]',('[SystemSettings]'+"`r`n"+$key+'='+$match.Groups[1].Value))}
                }
                else{$text=[regex]::Replace($text,('(?m)^'+$key+'=.*\r?\n'),'')}
            }
            if($s.CreatedSongsMode -ne 'Keep'){$text=Set-IniOption $text 'Options' 'DisableCreatedSongs' ([string]($s.CreatedSongsMode -eq 'Off'))}
            else{
                $songs=[regex]::Match($existing,'(?m)^DisableCreatedSongs=([^\r\n]+)')
                if($songs.Success){$text=Set-IniOption $text 'Options' 'DisableCreatedSongs' $songs.Groups[1].Value}
                else{$text=[regex]::Replace($text,'(?m)^DisableCreatedSongs=.*\r?\n','')}
            }
            if($s.DeathThemesMode -eq 'On'){foreach($key in @('MuteFriendDeathThemes','MuteIgnoredDeathThemes','MuteNonFriendDeathThemes')){$text=Set-IniOption $text 'Options' $key '0'}}
            if($s.DeathThemesMode -ne 'Keep'){$text=Set-IniOption $text 'Options' 'MuteAllDeathThemes' ([string]($s.DeathThemesMode -eq 'Off'))}
            else{
                $themes=[regex]::Match($existing,'(?m)^MuteAllDeathThemes=([^\r\n]+)')
                if($themes.Success){$text=Set-IniOption $text 'Options' 'MuteAllDeathThemes' $themes.Groups[1].Value}
                else{$text=[regex]::Replace($text,'(?m)^MuteAllDeathThemes=.*\r?\n','')}
            }
            $hud=[regex]::Match($existing,'(?m)^UIMagnification=([^\r\n]+)')
            if($s.ResetHUDScale){$text=Set-Value $text 'UIMagnification' '0.0'}
            elseif($hud.Success){$text=Set-Value $text 'UIMagnification' $hud.Groups[1].Value}
            else{$text=[regex]::Replace($text,'(?m)^UIMagnification=.*\r?\n','')}
            $volume=[regex]::Match($existing,'(?m)^AudioMasterVolume=([^\r\n]+)')
            if($volume.Success){$text=Set-Value $text 'AudioMasterVolume' $volume.Groups[1].Value}
            else{$text=[regex]::Replace($text,'(?m)^AudioMasterVolume=.*\r?\n','')}
            if($s.Resolution -ne 'Keep'){
                if($s.Resolution -notmatch '^(\d{3,5})x(\d{3,5})$'){throw 'Invalid resolution selection.'}
                $rx=$Matches[1];$ry=$Matches[2]
                foreach($pair in @(@('ResX',$rx),@('ResY',$ry))){
                    if($text -match ('(?m)^'+$pair[0]+'=')){$text=Set-Value $text $pair[0] $pair[1]}
                    else{$text=$text.Replace('[SystemSettings]',('[SystemSettings]'+"`r`n"+$pair[0]+'='+$pair[1]))}
                }
            }
            $text=Set-Value $text 'DisplayGamma' ([double]$s.Gamma).ToString([Globalization.CultureInfo]::InvariantCulture)
            $scale='100.000000'
            if($text -match '(?m)^ScreenPercentage='){$text=Set-Value $text 'ScreenPercentage' $scale}
            else{$text=$text.Replace('[SystemSettings]',('[SystemSettings]'+"`r`nScreenPercentage="+$scale))}
        }
        if($relative -eq 'APBGame\Config\APBCompat.ini'){
            $particles='True';if($s.UmgebungspartikelAus){$particles='False'}
            $text=Set-Value $text 'LevelParticles' $particles
            if($s.ExtremeTextures){
                # Texture-only preset: keep UI, render targets and independently selected effects.
                $text=[regex]::Replace($text,'(?m)^TEXCAT_(?!UI=|VFX=|RenderTarget=|LightAndShadowMap=)[^=\r\n]+=.*$',{param($m) ($m.Value -replace 'MaxLODSize=\d+','MaxLODSize=64') -replace 'LODBias=-?\d+','LODBias=4'})
            }
            if($s.Granatenspur){
                $text=[regex]::Replace($text,'(?m)^TEXCAT_VFX=.*$',{param($m) ($m.Value -replace 'MaxLODSize=\d+','MaxLODSize=16') -replace 'LODBias=-?\d+','LODBias=4'})
            }
            $scale='100.000000'
            $text=Set-Value $text 'ScreenPercentage' $scale
        }
        if($relative -eq 'APBGame\Config\APBCompat.ini'){
            $text=[regex]::Replace($text,'(?m)^Fullscreen=.*\r?\n','')
        }
        if($text -match '(?m)^OneFrameThreadLag='){$text=Set-Value $text 'OneFrameThreadLag' 'True'}
        $jobs.Add(@{Relative=$relative;Text=$text})
    }
    # Remove stale render scaling from an existing generated engine cache as well.
    $engineCache=Join-Path $s.Spielordner 'APBGame\Config\APBEngine.ini'
    if(Test-Path -LiteralPath $engineCache){
        $cacheText=[IO.File]::ReadAllText($engineCache)
        $cacheText=[regex]::Replace($cacheText,'(?m)^ScreenPercentage=.*$','ScreenPercentage=100.000000')
        $cacheText=[regex]::Replace($cacheText,'(?m)^OneFrameThreadLag=.*$','OneFrameThreadLag=True')
        $cacheText=[regex]::Replace($cacheText,'(?im)^(MaxMultiSamples|MSAA_Amount)=.*$',('$1='+$aa))
        $jobs.Add(@{Relative='APBGame\Config\APBEngine.ini';Text=$cacheText})
    }
    # Existing generated keybinds and account overrides can otherwise keep F9 occupied.
    $inputPath=Join-Path $s.Spielordner 'APBGame\Config\APBInput.ini'
    if(Test-Path -LiteralPath $inputPath){
        $text=[IO.File]::ReadAllText($inputPath)
        $text=[regex]::Replace($text,'(?m)^Bindings=\(Name="F9",.*\r?\n','')
        $text=$text.Replace('[Engine.PlayerInput]',('[Engine.PlayerInput]'+"`r`n"+'Bindings=(Name="F9",Command="open APBLoginLevel",Group="UI",bAllowInScaleformUI=True)'))
        if($s.MouseSmoothingMode -ne 'Keep'){$text=Set-IniOption $text 'Engine.PlayerInput' 'bEnableMouseSmoothing' ([string]($s.MouseSmoothingMode -eq 'On'))}
        if($s.MouseMode -ne 'Keep'){$speed='1.0';if($s.MouseMode -eq 'Legacy'){$speed='2.0'};$text=Set-MouseAxes $text $speed}
        $jobs.Add(@{Relative='APBGame\Config\APBInput.ini';Text=$text})
    }
    if($s.MouseMode -ne 'Keep'){
        $baseInputRelative='Engine\Config\BaseInput.ini'
        $baseInputPath=Join-Path $s.Spielordner $baseInputRelative
        if(Test-Path -LiteralPath $baseInputPath){
            $text=[IO.File]::ReadAllText($baseInputPath)
            $speed='1.0';if($s.MouseMode -eq 'Legacy'){$speed='2.0'}
            $text=Set-MouseAxes $text $speed
            $text=Set-IniOption $text 'Engine.PlayerInput' 'bEnableMouseSmoothing' ([string]($s.MouseMode -eq 'Default'))
            $jobs.Add(@{Relative=$baseInputRelative;Text=$text})
        }
    }
    $account=Join-Path $s.Spielordner 'APBGame\Config\Account'
    if(Test-Path -LiteralPath $account){
        foreach($file in Get-ChildItem -LiteralPath $account -Filter InputBindings.ini -Recurse -File){
            $text=[IO.File]::ReadAllText($file.FullName)
            $text=[regex]::Replace($text,'(?m)^([^;\r\n=]+)=(.*\bF9\b.*)$',{param($m) $m.Groups[1].Value+'='+($m.Groups[2].Value -replace '\bF9\b','None')})
            if($text -match '(?m)^open_APBLoginLevel='){$text=Set-Value $text 'open_APBLoginLevel' 'F9 | None'}
            else{$text=$text.TrimEnd()+"`r`nopen_APBLoginLevel=F9 | None`r`n"}
            $jobs.Add(@{Relative=$file.FullName.Substring($s.Spielordner.Length+1);Text=$text})
        }
    }
    # Edit only explicitly selected audio options; preserve volume, devices and bindings.
    foreach($mode in @($s.VoiceMode,$s.DuckingMode,$s.SprintDotMode,$s.MouseSmoothingMode,$s.AutoReadyMode,$s.DeathThemesMode)){if($mode -notin @('Keep','Off','On')){throw 'Invalid audio mode.'}}
    if(Test-Path -LiteralPath $account){
        if(Test-Path -LiteralPath $account){
            foreach($file in Get-ChildItem -LiteralPath $account -Filter UserOptions.ini -Recurse -File){
                $text=[IO.File]::ReadAllText($file.FullName)
                # Remove conflicting legacy scalar values without changing resolution or keybinds.
                $text=[regex]::Replace($text,'(?m)^ScreenPercentage=.*$','ScreenPercentage=100.000000')
                $text=[regex]::Replace($text,'(?m)^OneFrameThreadLag=.*$','OneFrameThreadLag=True')
                $text=[regex]::Replace($text,'(?im)^(MaxMultiSamples|MSAA_Amount)=.*$',('$1='+$aa))
                $changes=@{}
                if($s.AutoReadyMode -ne 'Keep'){$changes['AutoReady']=[string]($s.AutoReadyMode -eq 'On')}
                if($s.MouseSmoothingMode -ne 'Keep'){$text=Set-IniOption $text 'Engine.PlayerInput' 'bEnableMouseSmoothing' ([string]($s.MouseSmoothingMode -eq 'On'))}
                if($s.SprintDotMode -ne 'Keep'){$changes['ShowSprintingDot']=[string]($s.SprintDotMode -eq 'On')}
                if($s.VoiceMode -ne 'Keep'){$changes['VoipSystemDisable']=[string]($s.VoiceMode -eq 'Off')}
                if($s.VoiceMode -eq 'Off'){foreach($key in @('VoipChannelAutoAssign','VoipChannelWorld','VoipChannelGroup','VoipChannelSide','VoipChannelClan')){$changes[$key]='False'}}
                if($s.DuckingMode -ne 'Keep'){$changes['VoipDuckingEnabled']=[string]($s.DuckingMode -eq 'On')}
                foreach($key in $changes.Keys){
                    if($text -match ('(?m)^'+$key+'=')){$text=Set-Value $text $key $changes[$key]}
                    elseif($text -match '(?m)^\[Options\]'){$text=$text.Replace('[Options]',('[Options]'+"`r`n"+$key+'='+$changes[$key]))}
                    else{throw ('Missing [Options]: '+$file.FullName)}
                }
                $jobs.Add(@{Relative=$file.FullName.Substring($s.Spielordner.Length+1);Text=$text})
            }
        }
    }
    if($s.MusicPlayerVolume -ne 'Keep' -and (Test-Path -LiteralPath $account)){
        foreach($file in Get-ChildItem -LiteralPath $account -Filter usermusiclibrary.xml -Recurse -File){
            $settings=New-Object Xml.XmlReaderSettings;$settings.DtdProcessing=[Xml.DtdProcessing]::Prohibit;$settings.XmlResolver=$null
            $reader=[Xml.XmlReader]::Create($file.FullName,$settings)
            $doc=New-Object Xml.XmlDocument;$doc.PreserveWhitespace=$true;$doc.XmlResolver=$null
            try{$doc.Load($reader)}finally{$reader.Dispose()}
            $node=$doc.SelectSingleNode('/MusicPlayer/Config/CurrentPlaybackInformation')
            if(-not $node){throw ('Missing music player settings: '+$file.FullName)}
            $node.SetAttribute('Volume',([double]$s.MusicPlayerVolume/100).ToString('0.000000',[Globalization.CultureInfo]::InvariantCulture))
            if($s.MusicPlayerVolume -eq '0'){foreach($attribute in @('AutoResume','PlaybackOnFoot','BroadcastFromVehicle')){$node.SetAttribute($attribute,'false')}}
            $jobs.Add(@{Relative=$file.FullName.Substring($s.Spielordner.Length+1);Text=$doc.OuterXml})
        }
    }
    # New account defaults: edit the installed file, never replace it with an old template.
    $defaultsRelative='APBGame\Config\DefaultUserOptions.ini'
    $defaultsPath=Join-Path $s.Spielordner $defaultsRelative
    if((Test-Path -LiteralPath $defaultsPath) -and ($s.VoiceMode -ne 'Keep' -or $s.MouseSmoothingMode -ne 'Keep' -or $s.AutoReadyMode -ne 'Keep' -or $s.SprintDotMode -ne 'Keep' -or $s.DuckingMode -ne 'Keep')){
        $text=[IO.File]::ReadAllText($defaultsPath)
        if($s.VoiceMode -ne 'Keep'){$text=Set-IniOption $text 'Options' '*VoipSystemDisable' ([string]($s.VoiceMode -eq 'Off'))}
        if($s.VoiceMode -eq 'Off'){foreach($key in @('VoipChannelAutoAssign','VoipChannelWorld','VoipChannelGroup','VoipChannelSide','VoipChannelClan')){$text=Set-IniOption $text 'Options' ('*'+$key) 'False'}}
        if($s.MouseSmoothingMode -ne 'Keep'){$text=Set-IniOption $text 'Engine.PlayerInput' '*bEnableMouseSmoothing' ([string]($s.MouseSmoothingMode -eq 'On'))}
        if($s.AutoReadyMode -ne 'Keep'){$text=Set-IniOption $text 'Options' '*AutoReady' ([string]($s.AutoReadyMode -eq 'On'))}
        if($s.SprintDotMode -ne 'Keep'){$text=Set-IniOption $text 'Options' '*ShowSprintingDot' ([string]($s.SprintDotMode -eq 'On'))}
        if($s.DuckingMode -ne 'Keep'){$text=Set-IniOption $text 'Options' '*VoipDuckingEnabled' ([string]($s.DuckingMode -eq 'On'))}
        $jobs.Add(@{Relative=$defaultsRelative;Text=$text})
    }
    $gameCacheRelative='APBGame\Config\APBGame.ini'
    $gameCachePath=Join-Path $s.Spielordner $gameCacheRelative
    if(Test-Path -LiteralPath $gameCachePath){
        $text=[IO.File]::ReadAllText($gameCachePath)
        $text=Set-IniOption $text 'APBGame.cVisualFX_Weapon' 'm_bEnableMuzzleFlash' ([string][bool]$s.MuzzleFlash)
        $text=Set-IniOption $text 'APBGame.cVisualFX_Weapon' 'm_bEnableMagazineCasings' ([string][bool]$s.ShellCasings)
        $jobs.Add(@{Relative=$gameCacheRelative;Text=$text})
    }
    if($s.EigeneLocalization){
        $loc=Join-Path $script:HomePath 'Optional\Meine-Localization'
        foreach($file in Get-ChildItem -LiteralPath $loc -Recurse -File){
            $relative=$file.FullName.Substring($loc.Length+1)
            if($file.Name -eq 'HudGroupStates.GER'){
                $text=[IO.File]::ReadAllText($file.FullName)
                $matching='MATCHING...';$waiting='WAITING... <Timeout>'
                if($s.ExtraHumor){$matching='Cheater Located';$waiting='Sosality loading... <Timeout>'}
                foreach($pair in @(@('HudGroupStates_MatchMaking_InProgress_HeaderText',$matching),@('HudGroupStates_MatchMaking_Waiting_HeaderText',$waiting))){
                    if($text -match ('(?m)^'+$pair[0]+'=')){$text=Set-Value $text $pair[0] $pair[1]}
                    else{$text=$text.TrimEnd()+"`r`n"+$pair[0]+'='+$pair[1]+"`r`n"}
                }
                $jobs.Add(@{Relative=$relative;Text=$text})
            }else{$jobs.Add(@{Relative=$relative;Bytes=[IO.File]::ReadAllBytes($file.FullName)})}
        }
    }
    if($s.ShaderDotMode -notin @('Keep','Off','On')){throw 'ShaderUnsupported'}
    if($s.ShaderDotMode -eq 'On' -and -not $s.ShaderRiskAccepted){throw 'ShaderConsentRequired'}
    if($s.ShaderDotMode -ne 'Keep'){
        $relative='Engine\Shaders\APBUberPostProcessBlendPixelShader.usf'
        $target=Join-Path $s.Spielordner $relative
        if(-not (Test-Path -LiteralPath $target)){throw 'ShaderMissing'}
        $bytes=[IO.File]::ReadAllBytes($target)
        $patched=Set-CenterDot $bytes $s.ShaderDotMode
        $jobs.Add(@{Relative=$relative;Bytes=$patched})
    }
    $backup=Join-Path $script:HomePath ('Backups\'+(Get-Date -Format 'yyyyMMdd-HHmmss-fff'))
    [IO.Directory]::CreateDirectory($backup) | Out-Null
    $manifest=New-Object 'System.Collections.Generic.List[object]'
    # Finish every backup before writing anything to the game.
    foreach($job in $jobs){
        $target=Join-Path $s.Spielordner $job.Relative
        $exists=Test-Path -LiteralPath $target
        if($exists){
            $bp=Join-Path $backup $job.Relative
            [IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($bp)) | Out-Null
            Copy-Item -LiteralPath $target -Destination $bp
        }
        $manifest.Add(@{Relative=$job.Relative;Existed=$exists})
    }
    @{Spielordner=$s.Spielordner;Files=@($manifest.ToArray())} | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $backup 'manifest.json') -Encoding UTF8
    try {
        foreach($job in $jobs){
            $target=Join-Path $s.Spielordner $job.Relative
            if($job.ContainsKey('Bytes')){
                [IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($target)) | Out-Null
                [IO.File]::WriteAllBytes($target,$job.Bytes)
            }else{Write-Text $target $job.Text}
        }
    } catch { throw "Anwendung fehlgeschlagen. Sicherung: $backup. Mit Menuepunkt R wiederherstellen. Fehler: $_" }
    Update-APBShortcut $backup
    Save-Settings
    Write-Host "Angewendet: $($s.Modus), $($s.Effekte), FPS $($s.FPSLimit). Backup: $backup" -ForegroundColor Green
}
function Restore-Last {
    Check-Game
    $backupRoot=Join-Path $script:HomePath 'Backups'
    $manifests=@(Get-ChildItem -LiteralPath $backupRoot -Filter manifest.json -Recurse -File -ErrorAction SilentlyContinue | Sort-Object FullName -Descending)
    $found=$null
    foreach($file in $manifests){
        $m=Get-Content -LiteralPath $file.FullName -Raw | ConvertFrom-Json
        if($m.Spielordner -eq $s.Spielordner){$found=$file;break}
    }
    if(-not $found){throw 'Keine passende Sicherung gefunden.'}
    foreach($item in $m.Files){
        $target=[IO.Path]::GetFullPath((Join-Path $s.Spielordner $item.Relative))
        if(-not $target.StartsWith($s.Spielordner+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'Ungueltiger Sicherungspfad.'}
        if($item.Existed){Copy-Item -LiteralPath (Join-Path $found.DirectoryName $item.Relative) -Destination $target -Force}
        elseif(Test-Path -LiteralPath $target){Remove-Item -LiteralPath $target}
    }
    Move-Item -LiteralPath $found.FullName -Destination (Join-Path $found.DirectoryName 'restored.json')
    Write-Host 'Vorheriger Zustand wiederhergestellt.' -ForegroundColor Green
}
if($NurLaden){return}
if($Pruefen){
    foreach($mode in 'Social','NoSocial'){foreach($fx in 'Normal','Reduziert'){
        $p=Join-Path $PSScriptRoot "Profile\$mode\$fx\Engine\Config\BaseEngine.ini"
        if(-not (Test-Path -LiteralPath $p)){throw "Profil fehlt: $p"}
    }}
    Write-Host 'Profile vorhanden; Menueskript geladen. Kein Spiel gestartet oder geaendert.'
    return
}
while($true){
    Write-Host "`nAPB Alexander | $($s.Modus) | Effekte: $($s.Effekte) | FPS: $($s.FPSLimit) (0=unbegrenzt)" -ForegroundColor Cyan
    Write-Host "1 Spielordner: $($s.Spielordner)`n2 Social / NoSocial`n3 Effekte Normal / Reduziert (ohne Fahrzeugfeuer)`n4 FPS-Limit (leer oder 0 = unbegrenzt)`n5 Texturstreaming: $($s.TexturStreaming)`n6 Disk-Cache: $($s.DiskCache)`n7 Gamma: $($s.Gamma)`n8 Schwarzer Login: $($s.SchwarzerLogin)`n9 Alte eigene Localization zusaetzlich kopieren: $($s.EigeneLocalization)`nA Anwenden | S Anwenden und starten | R Letzte Anwendung rueckgaengig | E Einstellungen speichern | Q Ende"
    try {
        switch((Read-Host 'Auswahl').ToUpperInvariant()){
            '1' {$s.Spielordner=(Read-Host 'APB-Hauptordner').Trim().Trim('"')}
            '2' {if($s.Modus -eq 'Social'){$s.Modus='NoSocial'}else{$s.Modus='Social'}}
            '3' {if($s.Effekte -eq 'Normal'){$s.Effekte='Reduziert'}else{$s.Effekte='Normal'}}
            '4' {$raw=Read-Host 'FPS, z.B. 144; leer oder 0 fuer unbegrenzt'; if([string]::IsNullOrWhiteSpace($raw)){$s.FPSLimit=0}else{$n=0;if(-not [int]::TryParse($raw,[ref]$n) -or $n -lt 0 -or $n -gt 1000){throw 'Bitte 0 bis 1000 eingeben.'};$s.FPSLimit=$n}}
            '5' {$s.TexturStreaming=-not $s.TexturStreaming}
            '6' {$s.DiskCache=-not $s.DiskCache}
            '7' {$raw=(Read-Host 'Gamma 1.0 bis 5.0; vorher 4.477407').Replace(',','.');$g=[double]::Parse($raw,[Globalization.CultureInfo]::InvariantCulture);if($g -lt 1 -or $g -gt 5){throw 'Gamma muss zwischen 1 und 5 liegen.'};$s.Gamma=$g}
            '8' {$s.SchwarzerLogin=-not $s.SchwarzerLogin}
            '9' {$s.EigeneLocalization=-not $s.EigeneLocalization}
            'A' {Apply-Config}
            'S' {Apply-Config; Start-APBDirect}
            'R' {Restore-Last}
            'E' {Save-Settings;Write-Host 'Gespeichert.'}
            'Q' {return}
        }
    } catch {Write-Host $_ -ForegroundColor Red}
}
