﻿﻿using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Collections.Generic;
using System.Web.Script.Serialization;
using System.Diagnostics;
using System.Globalization;
using System.Runtime.InteropServices;
using System.Xml;

public sealed class Settings {
 public Dictionary<string,object> Data;
 public static JavaScriptSerializer Json=new JavaScriptSerializer(){MaxJsonLength=16000000};
 public Settings(string path){Data=Json.Deserialize<Dictionary<string,object>>(File.ReadAllText(path));foreach(var p in new Dictionary<string,object>{{"HudOpacity","0.98"},{"HudTransparencyMode","Transparent"},{"MissionEquipmentIcons",true},{"MissionColorMode","Colored"},{"KillMessageMode","Names"},{"KillMessageText","sosal"},{"QuickExitKey","F9"},{"FunnyNames",true},{"MouseAccelerationMode","Keep"},{"FrameQueueMode","Keep"},{"GraphicsPreset","Personal"},{"CrouchMode","Keep"},{"LeanMode","Keep"},{"CustomActive",false},{"CustomTextureSize","256"},{"CustomLowPoly",false},{"CustomShadows",false},{"CustomDetail","0"}})if(!Data.ContainsKey(p.Key))Data[p.Key]=p.Value;Graphics31.Defaults(this);if(S("GameTextLanguage")=="EnglishPro")Set("GameTextLanguage","English");}
 public string S(string k){object v;return Data.TryGetValue(k,out v)&&v!=null?Convert.ToString(v,CultureInfo.InvariantCulture):"";}
 public bool B(string k){bool b;return bool.TryParse(S(k),out b)&&b;}
 public int I(string k){return int.Parse(S(k),CultureInfo.InvariantCulture);}
 public void Set(string k,object v){Data[k]=v;}
 public IEnumerable<string> Sizes(){object v;if(!Data.TryGetValue("SavedResolutions",out v)||v==null)return new string[0];return ((System.Collections.IEnumerable)v).Cast<object>().Select(x=>Convert.ToString(x));}
 public void Save(string path){Engine.Atomic(path,Encoding.UTF8.GetBytes(Json.Serialize(Data)));}
}

public sealed partial class Engine {
 public readonly string Root; public Settings S; public string Game {get{return Path.GetFullPath(S.S("Spielordner")).TrimEnd('\\');}}
 readonly string preferencesPath;
 public static string UserPreferencesPath {get{return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"Orocleister","APB ConfigManager","Preferences.json");}}
 public Engine(string root,string userPreferences=null){Root=Path.GetFullPath(root);preferencesPath=userPreferences;S=new Settings(Path.Combine(root,"Einstellungen.json"));if(!string.IsNullOrEmpty(preferencesPath)&&File.Exists(preferencesPath)){try{var saved=Settings.Json.Deserialize<Dictionary<string,object>>(File.ReadAllText(preferencesPath));if(saved==null)throw new Exception("Empty settings");foreach(var entry in saved)S.Set(entry.Key,entry.Value);}catch(Exception ex){throw new Exception("Cannot read saved preferences: "+preferencesPath+". Your settings were not overwritten. Backup: "+preferencesPath+".bak",ex);}}}
 public void SavePreferences(){string target=string.IsNullOrEmpty(preferencesPath)?Path.Combine(Root,"Einstellungen.json"):preferencesPath;if(File.Exists(target))Atomic(target+".bak",File.ReadAllBytes(target));S.Save(target);}

 public static string R(string text,string pattern,string value){return Regex.Replace(text,pattern,value);}
 public static string V(string text,string key,string value){return Regex.Replace(text,"(?m)^"+Regex.Escape(key)+@"\s*=.*$",m=>key+"="+value);}
 public static string Ini(string text,string section,string key,string value){
  var m=Regex.Match(text,@"(?ms)^\["+Regex.Escape(section)+@"\][^\r\n]*\r?\n(?<body>.*?)(?=^\[|\z)");
  if(!m.Success)return text.TrimEnd()+"\r\n\r\n["+section+"]\r\n"+key+"="+value+"\r\n";
  var b=m.Groups["body"];string body=b.Value;
  if(Regex.IsMatch(body,"(?m)^"+Regex.Escape(key)+@"\s*="))body=V(body,key,value);else body=key+"="+value+"\r\n"+body;
  return text.Substring(0,b.Index)+body+text.Substring(b.Index+b.Length);
 }
 static string Flag(bool b){return b?"True":"False";}
 public static void Atomic(string path,byte[] data){Directory.CreateDirectory(Path.GetDirectoryName(path));string temp=path+".tmp-"+Guid.NewGuid().ToString("N");try{File.WriteAllBytes(temp,data);if(File.Exists(path))File.Replace(temp,path,null);else File.Move(temp,path);}finally{if(File.Exists(temp))File.Delete(temp);}}
 public static string Under(string root,string relative){var full=Path.GetFullPath(Path.Combine(root,relative));if(!full.StartsWith(Path.GetFullPath(root).TrimEnd('\\')+"\\",StringComparison.OrdinalIgnoreCase))throw new InvalidDataException("Invalid relative path: "+relative);return full;}
 public void Check(){if(Process.GetProcessesByName("APB").Length>0||Process.GetProcessesByName("APBLauncher").Length>0)throw new Exception("Close APB and its launcher first.");if(string.IsNullOrWhiteSpace(S.S("Spielordner"))||!File.Exists(Path.Combine(Game,@"Binaries\APB.exe")))throw new Exception("Select the APB folder containing Binaries\\APB.exe.");}
 public static void Resolution(string size){if(size=="Keep")return;var m=Regex.Match(size,@"^(\d{3,4})x(\d{3,4})$");if(!m.Success)throw new Exception("ResolutionInvalid");int w=int.Parse(m.Groups[1].Value),h=int.Parse(m.Groups[2].Value);if(w<320||w>7680||h<240||h>4320)throw new Exception("ResolutionInvalid");}
 void OneOf(string key,params string[] values){if(!values.Contains(S.S(key)))throw new Exception("Invalid setting: "+key);}
 public void Validate(){
  OneOf("HudTransparencyMode","Keep","Normal","Transparent","Custom");decimal opacity;if(!decimal.TryParse(S.S("HudOpacity"),NumberStyles.AllowDecimalPoint,CultureInfo.InvariantCulture,out opacity)||opacity<0.95m||opacity>1m)throw new Exception("HUD opacity: 0.95–1.0");OneOf("MissionColorMode","Plain","Colored");OneOf("KillMessageMode","Names","Minimal","Custom");KillText("",S.S("KillMessageMode"),S.S("KillMessageText"));Graphics31.Validate(S);Resolution(S.S("Resolution"));foreach(string r in S.Sizes())Resolution(r);
  if(!QuickExitKeys.Contains(S.S("QuickExitKey")))throw new Exception("Invalid quick exit key");OneOf("Modus","Social","NoSocial");OneOf("Effekte","Normal","Reduziert");OneOf("DisplayMode","Keep","Windowed","Fullscreen","Borderless");OneOf("AAMode","Keep","Off","2","4","8");OneOf("MouseMode","Keep","Standard","Default","Legacy");OneOf("GameTextLanguage","English","Russian");OneOf("TextColorPreset","Standard","BlueRed","GreenRed","BlackPink","BlueOrange","YellowPurple");OneOf("MusicPlayerVolume","Keep","0","25","50","75","100");
  foreach(string k in new[]{"VoiceMode","DuckingMode","SprintDotMode","MouseSmoothingMode","AutoReadyMode","DeathThemesMode","CreatedSongsMode","CrouchMode","LeanMode","FrameQueueMode","MouseAccelerationMode"})OneOf(k,"Keep","Off","On");
  if(S.I("FPSLimit")<0||S.I("FPSLimit")>1000)throw new Exception("FPS: 0–1000");double g=double.Parse(S.S("Gamma"),CultureInfo.InvariantCulture);if(g<1||g>5)throw new Exception("Gamma: 1–5");
  if(S.B("CustomActive")){OneOf("CustomTextureSize","64","128","256","512","1024");OneOf("CustomDetail","0","1","2");}
 }
 public string Arguments(){
  string a=S.S("LaunchArguments");if(S.B("EigeneLocalization")||string.IsNullOrWhiteSpace(a)){OneOf("GameTextLanguage","English","Russian");a=R(a,"(?i)(?<!\\S)-language=(?:\"[^\"]*\"|\\S+)","").Trim();a="-language="+(S.S("GameTextLanguage")=="Russian"?"1049":"1031")+" "+a;}
  a=R(a,@"(?i)(?<!\S)-(?:nomoviesstartup|nomovies|nosplash|nosteam)(?!\S)","").Trim();if(S.B("SkipMovies"))a+=" -nomovies";if(S.B("SkipSplash"))a+=" -nosplash";if(S.B("NoSteam"))a+=" -nosteam";return a.Trim();
 }
 public void ImportShortcut(string path){object sh=null,lnk=null;try{sh=Activator.CreateInstance(Type.GetTypeFromProgID("WScript.Shell"));dynamic shell=sh;lnk=shell.CreateShortcut(Path.GetFullPath(path));dynamic link=lnk;string target=Environment.ExpandEnvironmentVariables((string)link.TargetPath);if(!File.Exists(target)||!Path.GetFileName(target).Equals("APB.exe",StringComparison.OrdinalIgnoreCase)||!Path.GetFileName(Path.GetDirectoryName(target)).Equals("Binaries",StringComparison.OrdinalIgnoreCase))throw new Exception("The shortcut must point directly to APB.exe, not the launcher.");S.Set("Spielordner",Path.GetDirectoryName(Path.GetDirectoryName(target)));S.Set("ShortcutPath",Path.GetFullPath(path));S.Set("LaunchArguments",(string)link.Arguments);S.Set("NoSteam",Regex.IsMatch((string)link.Arguments,@"(?i)(?<!\S)-nosteam(?!\S)"));}finally{if(lnk!=null)Marshal.FinalReleaseComObject(lnk);if(sh!=null)Marshal.FinalReleaseComObject(sh);}}
 public string ShortcutPath(){string p=S.S("ShortcutPath");if(string.IsNullOrWhiteSpace(p))p=Path.Combine(Root,"APB-Direct.lnk");p=Path.GetFullPath(p);if(!Path.GetExtension(p).Equals(".lnk",StringComparison.OrdinalIgnoreCase))throw new Exception("Shortcut path must end in .lnk.");return p;}
 void BackupShortcut(string dir){string p=ShortcutPath();bool exists=File.Exists(p);if(exists)File.Copy(p,Path.Combine(dir,"shortcut-before.lnk"));File.WriteAllText(Path.Combine(dir,"shortcut.json"),Settings.Json.Serialize(new {Path=p,Existed=exists,SHA256=exists?Hash(Path.Combine(dir,"shortcut-before.lnk")):""}));}
 void WriteShortcut(){object sh=null,lnk=null;try{sh=Activator.CreateInstance(Type.GetTypeFromProgID("WScript.Shell"));dynamic shell=sh;lnk=shell.CreateShortcut(ShortcutPath());dynamic link=lnk;link.TargetPath=Path.Combine(Game,@"Binaries\APB.exe");link.Arguments=Arguments();link.WorkingDirectory=Path.Combine(Game,"Binaries");link.Description="APB Reloaded - direct start with installed configuration";link.Save();}finally{if(lnk!=null)Marshal.FinalReleaseComObject(lnk);if(sh!=null)Marshal.FinalReleaseComObject(sh);}}
 public string Launcher(){Check();foreach(string p in new[]{@"Launcher\APBLauncher.exe","APBLauncher.exe",@"Binaries\APBLauncher.exe"})if(File.Exists(Path.Combine(Game,p)))return Path.Combine(Game,p);throw new Exception("APBLauncher.exe not found in the selected game folder.");}
 public void Update(){string p=Launcher();Process.Start(new ProcessStartInfo(p){WorkingDirectory=Path.GetDirectoryName(p),UseShellExecute=true});}
 public void Play(){Check();if(RecoveryPending())throw new Exception("RecoveryPending");Arguments();if(S.B("EigeneLocalization")&&S.S("GameTextLanguage")!="Russian"){string f=Path.Combine(Game,@"APBGame\Localization\GER\MissionTemplates.GER");bool pro=File.Exists(f)&&Regex.IsMatch(File.ReadAllText(f),@"[぀-ヿ一-鿿]");if(pro)throw new Exception("ApplyLanguageFirst");}string b=NewBackup("shortcut-");BackupShortcut(b);WriteShortcut();SavePreferences();Process.Start(new ProcessStartInfo(ShortcutPath()){UseShellExecute=true,WorkingDirectory=Path.Combine(Game,"Binaries")});}
 string NewBackup(string prefix){string b=Path.Combine(Root,"Backups",prefix+DateTime.Now.ToString("yyyyMMdd-HHmmss-fff")+"-"+Guid.NewGuid().ToString("N").Substring(0,6));Directory.CreateDirectory(b);return b;}
 public static string MouseFlags(string t,bool smooth){t=R(t,@"(?im)^(?<prefix>\*?)bEnableMouseSmoothing\s*=.*$","${prefix}bEnableMouseSmoothing="+Flag(smooth));return t;}
 static string Axes(string t,string speed){return Regex.Replace(t,@"(?ms)^\[Engine.PlayerInput\][^\r\n]*\r?\n.*?(?=^\[|\z)",sec=>Regex.Replace(sec.Value,"(?m)^[+.\\-]?Bindings=\\(Name=\"Mouse[XY]\",Command=\"[^\"\\r\\n]*\"[^\\r\\n]*\\r?$",line=>R(line.Value,@"Axis aMouse([XY])(?: Speed=[+\-0-9.]+)?","Axis aMouse$1 Speed="+speed)));}
 byte[] LocalizedNames(string path){
  byte[] data=LocalizationOptions(path,Colors(path,S.S("TextColorPreset")));
  if(S.B("FunnyNames"))return data;
  var all=Settings.Json.Deserialize<Dictionary<string,Dictionary<string,string>>>(File.ReadAllText(Path.Combine(Root,"OriginalNames.json")));
  Dictionary<string,string> names;if(!all.TryGetValue(Path.GetFileNameWithoutExtension(path),out names))return data;
  string text;using(var reader=new StreamReader(new MemoryStream(data),true))text=reader.ReadToEnd();
  text=Regex.Replace(text,@"(?m)^([^=\r\n]+)=([^\r\n]*)",m=>{string name;if(!names.TryGetValue(m.Groups[1].Value,out name))return m.Value;string v=m.Groups[2].Value;var color=Regex.Match(v,@"^(<Color:[^>]+>|<col:[^>]+>)",RegexOptions.IgnoreCase);return m.Groups[1].Value+"="+color.Value+name+(color.Success?(color.Value.StartsWith("<Color:",StringComparison.OrdinalIgnoreCase)?"<Color:/>":"</col>"):"");});
  return Encoding.Unicode.GetPreamble().Concat(Encoding.Unicode.GetBytes(text)).ToArray();
 }
 public static byte[] Colors(string path,string preset){
  if(preset=="Standard"||!new[]{"HUDMessages","HUDCombatMessages","APBUserInterface"}.Contains(Path.GetFileNameWithoutExtension(path)))return File.ReadAllBytes(path);
  var palettes=new Dictionary<string,string[]>{{"BlueRed",new[]{"Blue","Red"}},{"GreenRed",new[]{"Green","Red"}},{"BlackPink",new[]{"Black","Hot_Pink"}},{"BlueOrange",new[]{"Blue","Orange"}},{"YellowPurple",new[]{"Yellow","Purple"}}};
  string team=palettes[preset][0],enemy=palettes[preset][1],name=Path.GetFileNameWithoutExtension(path);
  string text=Regex.Replace(File.ReadAllText(path),@"(?m)^(?<key>[^=\r\n]+)=(?<value>[^\r\n]*)",m=>{
   string key=m.Groups["key"].Value,val=m.Groups["value"].Value;
   val=R(val,@"(?i)<col:(Action_Team(?:_Assist)?|GroupHUD_Friend|Scoreboard_Teammates(?:_Offline|_Premium|_Premium_Offline)?)>","<col:"+team+">");
   val=R(val,@"(?i)<col:(Action_Enemy(?:_Assist)?|GroupHUD_Enemy|Scoreboard_Opponents(?:_Offline|_Premium|_Premium_Offline)?)>","<col:"+enemy+">");
   if(name=="HUDMessages"&&key.StartsWith("HUDMessages_AM_Combat"))val=Regex.Replace(m.Groups["value"].Value,@"(?i)<col:(?<tag>[^>]+)>",tag=>{string v=tag.Groups["tag"].Value;if(Regex.IsMatch(v,"^(Blue|Action_Team|Action_Team_Assist)$",RegexOptions.IgnoreCase))return "<col:"+team+">";if(Regex.IsMatch(v,"^(Orange|Action_Enemy|Action_Enemy_Assist)$",RegexOptions.IgnoreCase))return "<col:"+enemy+">";if(v.Equals("openworld_marker",StringComparison.OrdinalIgnoreCase)&&Regex.IsMatch(key,"CombatKill(Opp|Team)"))return "<col:"+(key.Contains("CombatKillTeam")?team:enemy)+">";return tag.Value;});return key+"="+val;});
  return Encoding.Unicode.GetPreamble().Concat(Encoding.Unicode.GetBytes(text)).ToArray();
 }

 static IEnumerable<string> ExtraSizes(string t){var m=Regex.Match(t,@"(?ms)^\[WinDrv\.WindowsClient\][^\r\n]*\r?\n(?<body>.*?)(?=^\[|\z)");return Regex.Matches(m.Groups["body"].Value,@"(?im)^\s*\+?ExtraResolution\s*=\s*(\d{3,4}x\d{3,4})\s*$").Cast<Match>().Select(x=>x.Groups[1].Value);}
 public static string Menu(string t,IEnumerable<string> sizes,bool defaults){t=Ini(Ini(t,"WinDrv.WindowsClient","MinAllowableResolutionX","320"),"WinDrv.WindowsClient","MinAllowableResolutionY","240");var all=ExtraSizes(t).Concat(sizes).Distinct().ToArray();var m=Regex.Match(t,@"(?ms)^\[WinDrv\.WindowsClient\][^\r\n]*\r?\n(?<body>.*?)(?=^\[|\z)");var b=m.Groups["body"];string body=R(b.Value,@"(?im)^\s*\+?ExtraResolution\s*=[^\r\n]*(?:\r?\n|$)","");foreach(string s in all)body=body.TrimEnd()+"\r\n"+(defaults?"+":"")+"ExtraResolution="+s+"\r\n";return t.Substring(0,b.Index)+body+t.Substring(b.Index+b.Length);}
 public static string HoldBindings(string text,string crouch,string lean){
  return Regex.Replace(text,@"(?m)^[+. ]?Bindings=\(Name=""(?<name>Duck|LeanLeft|LeanRight)"",Command=""(?<cmd>[^""]*)""[^\r\n]*",m=>{
   string name=m.Groups["name"].Value,mode=name=="Duck"?crouch:lean;if(mode=="Keep")return m.Value;
   string command=name=="Duck"?"InputToggleDuck":name+"KeyDown";
   if(mode=="On")command+=name=="Duck"?" | OnRelease InputToggleDuck":" | OnRelease "+(name=="LeanLeft"?"LeanRight":"LeanLeft")+"KeyDown";
   var g=m.Groups["cmd"];int offset=g.Index-m.Index;return m.Value.Substring(0,offset)+command+m.Value.Substring(offset+g.Length);
  });
 }
 static string AddHoldMenu(string t){foreach(var pair in new[]{new[]{"HoldDuck","InputToggleDuck | OnRelease InputToggleDuck","Movement"},new[]{"HoldLeanLeft","LeanLeftKeyDown | OnRelease LeanRightKeyDown","Combat"},new[]{"HoldLeanRight","LeanRightKeyDown | OnRelease LeanLeftKeyDown","Combat"}}){if(t.Contains("Name=\""+pair[0]+"\""))continue;string lines="Bindings=(Name=\""+pair[0]+"\",Command=\""+pair[1]+"\")\r\nBindings=(Name=\"\",Command=\""+pair[0]+"\",Group=\""+pair[2]+"\",OnFootOnly=true)\r\n";t=t.Replace("[Engine.PlayerInput]","[Engine.PlayerInput]\r\n"+lines);}return t;}
 public static readonly string[] QuickExitKeys=new[]{"Keep","None"}.Concat(Enumerable.Range(65,26).Select(x=>((char)x).ToString())).Concat(new[]{"Zero","One","Two","Three","Four","Five","Six","Seven","Eight","Nine"}).Concat(Enumerable.Range(1,12).Select(x=>"F"+x)).Concat(Enumerable.Range(0,10).Select(x=>"NumPad"+x)).Concat(new[]{"Insert","Delete","Home","End","PageUp","PageDown","Up","Down","Left","Right","SpaceBar","Tab","Enter","BackSpace","CapsLock","Pause","LeftShift","RightShift","LeftControl","RightControl","LeftAlt","RightAlt","Add","Subtract","Multiply","Divide","Decimal","LeftBracket","RightBracket","Backslash","Semicolon","Comma","Period","Slash","Equals","Underscore"}).ToArray();
 public static string QuickExit(string t,string original,string key){
  string pattern=@"(?m)^\+?Bindings=\([^\r\n]*Command=""open APBLoginLevel""[^\r\n]*\)\r?\n?";
  t=Regex.Replace(t,pattern,"");
  if(key=="Keep"){foreach(Match m in Regex.Matches(original,pattern))t=t.Replace("[Engine.PlayerInput]","[Engine.PlayerInput]\r\n"+m.Value.TrimEnd()+"\r\n");return t;}
  if(key!="None")t=Regex.Replace(t,@"(?m)^(\+?Bindings=\(Name="")"+Regex.Escape(key)+@"("",[^\r\n]*)",m=>m.Groups[1].Value+m.Groups[2].Value);
  string prefix=t.Contains("+Bindings=")?"+":"";
  return t.Replace("[Engine.PlayerInput]","[Engine.PlayerInput]\r\n"+prefix+"Bindings=(Name=\""+(key=="None"?"":key)+"\",Command=\"open APBLoginLevel\",Group=\"UI\",bAllowInScaleformUI=True)");
 }
 public Dictionary<string,byte[]> Build(){
  Validate();
  string aa="1",machine=Read(@"APBGame\Config\APBMachineOptions.ini");if(S.S("AAMode")=="Keep"){var m=Regex.Match(machine,@"(?m)^MSAA_Amount=(\d+)");if(m.Success&&new[]{"2","4","8","16"}.Contains(m.Groups[1].Value))aa=m.Groups[1].Value;}else if(S.S("AAMode")!="Off")aa=S.S("AAMode");
  var text=new Dictionary<string,string>(StringComparer.OrdinalIgnoreCase);var bytes=new Dictionary<string,byte[]>(StringComparer.OrdinalIgnoreCase);string source=Path.Combine(Root,"Profile",S.S("Modus"),S.S("Effekte"));
  foreach(string f in Directory.GetFiles(source,"*",SearchOption.AllDirectories)){
   string rel=f.Substring(source.Length+1),t=File.ReadAllText(f);
   if(rel==@"APBGame\Config\DefaultInput.ini"){
    if(S.S("MouseAccelerationMode")=="Keep")t=Preserve(t,Read(rel),"Engine.PlayerInput","bViewAccelerationEnabled");
    string old=Read(rel);
    foreach(string name in new[]{"Duck","LeanLeft","LeanRight"})if(S.S(name=="Duck"?"CrouchMode":"LeanMode")=="Keep"){
     string pattern="(?m)^\\+Bindings=\\(Name=\""+name+"\",Command=\"[^\"]*\"[^\\r\\n]*";
     var previous=Regex.Match(old,pattern);if(previous.Success)t=Regex.Replace(t,pattern,m=>previous.Value);
    }
   }
   if(rel==@"Engine\Config\BaseEngine.ini"){t=V(t,"MaxClientFrameRate",S.S("FPSLimit"));t=V(V(t,"bUseTextureStreaming",Flag(S.B("TexturStreaming"))),"bUseLightingTextureStreaming",Flag(S.B("TexturStreaming")));}
   if(new[]{@"APBGame\Config\APBMachineOptions.ini",@"APBGame\Config\APBCompat.ini",@"APBGame\Config\DefaultMachineOptions.ini"}.Contains(rel))t=R(t,@"(?im)^(MaxMultiSamples|MSAA_Amount)=.*$","$1="+aa);
   if(rel==@"APBGame\Config\DefaultGame.ini")t=V(V(t,"m_bEnableMuzzleFlash",Flag(S.B("MuzzleFlash"))),"m_bEnableMagazineCasings",Flag(S.B("ShellCasings")));
   if(Regex.IsMatch(rel,@"^APBGame\\Config\\Default(?:-[A-Z]{3}-)?Input\.ini$")){
    if(S.S("MouseSmoothingMode")!="Keep")t=Ini(t,"Engine.PlayerInput","bEnableMouseSmoothing",Flag(S.S("MouseSmoothingMode")=="On"));else {var m=Regex.Match(Read(rel),@"(?m)^bEnableMouseSmoothing=([^\r\n]+)");if(m.Success)t=Ini(t,"Engine.PlayerInput","bEnableMouseSmoothing",m.Groups[1].Value);}
   }
   if(rel==@"APBGame\Config\DefaultMachineOptions.ini"&&S.S("DeathThemesMode")=="On")foreach(string key in new[]{"MuteAllDeathThemes","MuteFriendDeathThemes","MuteIgnoredDeathThemes","MuteNonFriendDeathThemes"})t=Ini(t,"Options",key,"0");
   if(rel==@"APBGame\Config\DefaultMachineOptions.ini"&&S.S("CreatedSongsMode")!="Keep")t=Ini(t,"Options","DisableCreatedSongs",Flag(S.S("CreatedSongsMode")=="Off"));
   if(rel==@"APBGame\Config\DefaultEngine.ini"){t=V(t,"m_bUseDiskCache",Flag(S.B("DiskCache")));string map=S.B("SchwarzerLogin")?"UIDistrict_DistrictSelect.apb":"APBLoginLevel.apb";t=V(V(t,"Map",map),"LocalMap",map);}
   if(rel==@"APBGame\Config\APBMachineOptions.ini"){
    foreach(string k in new[]{"ResX","ResY","Fullscreen"})t=Preserve(t,machine,"SystemSettings",k);
    t=S.S("CreatedSongsMode")!="Keep"?Ini(t,"Options","DisableCreatedSongs",Flag(S.S("CreatedSongsMode")=="Off")):Preserve(t,machine,"Options","DisableCreatedSongs");
    if(S.S("DeathThemesMode")=="On")foreach(string k in new[]{"MuteFriendDeathThemes","MuteIgnoredDeathThemes","MuteNonFriendDeathThemes"})t=Ini(t,"Options",k,"0");
    t=S.S("DeathThemesMode")!="Keep"?Ini(t,"Options","MuteAllDeathThemes",Flag(S.S("DeathThemesMode")=="Off")):Preserve(t,machine,"Options","MuteAllDeathThemes");
    t=S.B("ResetHUDScale")?V(t,"UIMagnification","0.0"):Preserve(t,machine,"SystemSettings","UIMagnification");t=Preserve(t,machine,"Options","AudioMasterVolume");
    if(S.S("Resolution")!="Keep"){string[] r=S.S("Resolution").Split('x');t=Ini(Ini(t,"SystemSettings","ResX",r[0]),"SystemSettings","ResY",r[1]);}
    if(S.S("DisplayMode")!="Keep")t=Ini(t,"SystemSettings","Fullscreen",S.S("DisplayMode")=="Windowed"?"0":S.S("DisplayMode")=="Fullscreen"?"1":"2");t=V(t,"DisplayGamma",S.S("Gamma"));t=Ini(t,"SystemSettings","ScreenPercentage","100.000000");
   }
   if(rel==@"APBGame\Config\APBCompat.ini")t=Graphics(t);
   // Preserve installed voice device/gain defaults introduced by newer clients.
   if(rel==@"APBGame\Config\DefaultMachineOptions.ini")foreach(string key in new[]{"VoiceMicVolume","VoipAutoGain","VoipCaptureDevice","VoipRenderDevice"})t=Preserve(t,Read(rel),"Options",key);
   if(rel==@"APBGame\Config\DefaultUI.ini"){t=Preserve(t,Read(rel),"Subtitles","ShowVoipTalkers");t=S.S("HudTransparencyMode")=="Keep"?Preserve(t,Read(rel),"Engine.GameUISceneClient","OverlaySceneAlphaModulation"):Ini(t,"Engine.GameUISceneClient","OverlaySceneAlphaModulation",S.S("HudTransparencyMode")=="Custom"?S.S("HudOpacity"):S.S("HudTransparencyMode")=="Transparent"?"0.999":"1.0");}
   text[rel]=t;
  }
  string generatedUi=@"APBGame\Config\APBUI.ini";if(Exists(generatedUi)&&S.S("HudTransparencyMode")!="Keep")text[generatedUi]=Ini(Read(generatedUi),"Engine.GameUISceneClient","OverlaySceneAlphaModulation",S.S("HudTransparencyMode")=="Custom"?S.S("HudOpacity"):S.S("HudTransparencyMode")=="Transparent"?"0.999":"1.0");
  string relEngine=@"APBGame\Config\APBEngine.ini";if(Exists(relEngine)){string t=Read(relEngine);t=V(t,"ScreenPercentage","100.000000");t=R(t,@"(?im)^(MaxMultiSamples|MSAA_Amount)=.*$","$1="+aa);text[relEngine]=t;}
  string inp=@"APBGame\Config\APBInput.ini";if(Exists(inp)){string t=Read(inp);if(S.S("MouseSmoothingMode")!="Keep")t=Ini(t,"Engine.PlayerInput","bEnableMouseSmoothing",Flag(S.S("MouseSmoothingMode")=="On"));if(S.S("MouseMode")=="Default"||S.S("MouseMode")=="Legacy")t=Axes(t,S.S("MouseMode")=="Legacy"?"2.0":"1.0");text[inp]=AddHoldMenu(t);}
  string baseInp=@"Engine\Config\BaseInput.ini";if((S.S("MouseMode")!="Keep"||S.S("MouseSmoothingMode")!="Keep"||S.S("MouseAccelerationMode")!="Keep")&&Exists(baseInp))text[baseInp]=Ini((S.S("MouseMode")=="Standard"||S.S("MouseMode")=="Keep")?Read(baseInp):Axes(Read(baseInp),S.S("MouseMode")=="Legacy"?"2.0":"1.0"),"Engine.PlayerInput","bEnableMouseSmoothing",Flag(S.S("MouseMode")=="Default"));
  foreach(string f in Account("InputBindings.ini")){string t=File.ReadAllText(f);if(S.S("QuickExitKey")!="Keep"){string key=S.S("QuickExitKey");if(key!="None")t=Regex.Replace(t,@"(?m)^([^;\r\n=]+)=(.*)$",m=>m.Groups[1].Value+"="+Regex.Replace(m.Groups[2].Value,@"\b"+Regex.Escape(key)+@"\b","None"));t=Ini(t,"InputBindings","open_APBLoginLevel",key+" | None");}text[Relative(f)]=t;}
  foreach(string f in Account("UserOptions.ini")){string t=File.ReadAllText(f);t=V(t,"ScreenPercentage","100.000000");t=R(t,@"(?im)^(MaxMultiSamples|MSAA_Amount)=.*$","$1="+aa);if(S.S("CreatedSongsMode")!="Keep")t=Ini(t,"Options","DisableCreatedSongs",Flag(S.S("CreatedSongsMode")=="Off"));t=UserOptions(t,false);text[Relative(f)]=t;}
  if(S.S("MusicPlayerVolume")!="Keep")foreach(string f in Account("usermusiclibrary.xml")){var options=new XmlReaderSettings{DtdProcessing=DtdProcessing.Prohibit,XmlResolver=null};var doc=new XmlDocument{PreserveWhitespace=true,XmlResolver=null};using(var rd=XmlReader.Create(f,options))doc.Load(rd);var n=doc.SelectSingleNode("/MusicPlayer/Config/CurrentPlaybackInformation") as XmlElement;if(n==null)throw new Exception("Missing music player settings: "+f);n.SetAttribute("StorePlaybackSettings","true");n.SetAttribute("Volume",(double.Parse(S.S("MusicPlayerVolume"),CultureInfo.InvariantCulture)/100).ToString("0.000000",CultureInfo.InvariantCulture));if(S.S("MusicPlayerVolume")=="0")foreach(string a in new[]{"AutoResume","PlaybackOnFoot","BroadcastFromVehicle"})n.SetAttribute(a,"false");text[Relative(f)]=doc.OuterXml;}
  if(S.S("MouseMode")!="Keep"||S.S("MouseSmoothingMode")!="Keep"||S.S("MouseAccelerationMode")!="Keep")foreach(string f in Account("UserConfig.ini")){string orig=File.ReadAllText(f),t=S.S("MouseSmoothingMode")=="Keep"?orig:MouseFlags(orig,S.S("MouseSmoothingMode")=="On");text[Relative(f)]=t;}
  if(text.ContainsKey(baseInp)&&S.S("MouseSmoothingMode")=="Keep")text[baseInp]=Preserve(text[baseInp],Read(baseInp),"Engine.PlayerInput","bEnableMouseSmoothing");
  string du=@"APBGame\Config\DefaultUserOptions.ini";if(Exists(du)&&new[]{"VoiceMode","MouseSmoothingMode","AutoReadyMode","SprintDotMode","DuckingMode"}.Any(k=>S.S(k)!="Keep"))text[du]=UserOptions(Read(du),true);
  string gc=@"APBGame\Config\APBGame.ini";if(Exists(gc))text[gc]=Ini(Ini(Read(gc),"APBGame.cVisualFX_Weapon","m_bEnableMuzzleFlash",Flag(S.B("MuzzleFlash"))),"APBGame.cVisualFX_Weapon","m_bEnableMagazineCasings",Flag(S.B("ShellCasings")));
  if(S.B("EigeneLocalization"))foreach(string lang in new[]{"English","Russian"}){string dir=Path.Combine(Root,"Optional","Localization",lang);foreach(string f in Directory.GetFiles(dir,"*",SearchOption.AllDirectories))if(!Path.GetFileNameWithoutExtension(f).Equals("EULA",StringComparison.OrdinalIgnoreCase))bytes[f.Substring(dir.Length+1)]=LocalizedNames(f);}
  var sizes=new[]{"640x480","800x600","960x540","1024x768","1152x864","1280x720","1280x800","1280x1024","1600x900","1024x1400","1200x1600","1280x1600","1600x2000","1200x1800","1800x1200","1920x1080"}.Concat(S.Sizes()).Concat(new[]{S.S("Resolution")}).Where(x=>x!="Keep").ToArray();
  foreach(string rel in text.Keys.ToArray()){
   string t=Graphics31.Render(text[rel],rel,S);if(rel.EndsWith("Input.ini",StringComparison.OrdinalIgnoreCase)){t=QuickExit(t,Read(rel),S.S("QuickExitKey"));}if(S.S("FrameQueueMode")!="Keep")t=V(t,"OneFrameThreadLag",Flag(S.S("FrameQueueMode")=="On"));else if(t.Contains("OneFrameThreadLag="))t=Preserve(t,Read(rel),"SystemSettings","OneFrameThreadLag");if(rel==@"APBGame\Config\DefaultInput.ini"||rel==@"APBGame\Config\APBInput.ini")t=HoldBindings(t,"Off","Off");if(Regex.IsMatch(rel,@"(?i)(Input|UserOptions|UserConfig|Engine)\.ini$")){if(S.S("MouseSmoothingMode")!="Keep")t=MouseFlags(t,S.S("MouseSmoothingMode")=="On");if(S.S("MouseAccelerationMode")!="Keep")t=R(t,@"(?im)^(?<prefix>\*?)bViewAccelerationEnabled\s*=.*$","${prefix}bViewAccelerationEnabled="+Flag(S.S("MouseAccelerationMode")=="On"));}
   if(new[]{@"Engine\Config\BaseEngine.ini",@"Engine\Config\BaseInput.ini",@"APBGame\Config\DefaultInput.ini",@"APBGame\Config\APBInput.ini"}.Contains(rel)){if(S.S("MouseSmoothingMode")!="Keep")t=Ini(t,"Engine.PlayerInput","bEnableMouseSmoothing",Flag(S.S("MouseSmoothingMode")=="On"));if(S.S("MouseAccelerationMode")!="Keep")t=Ini(t,"Engine.PlayerInput","bViewAccelerationEnabled",Flag(S.S("MouseAccelerationMode")=="On"));}
   if(new[]{@"Engine\Config\BaseEngine.ini",@"APBGame\Config\DefaultEngine.ini",relEngine}.Contains(rel))t=Ini(t,"Engine.Engine","TimeBetweenPurgingPendingKillObjects",S.S("Modus")=="NoSocial"?"0":"2700");
   if(rel==@"APBGame\Config\DefaultEngine.ini"||rel==relEngine)t=Menu(t,sizes.Concat(ExtraSizes(Read(rel))),rel.EndsWith("DefaultEngine.ini"));bytes[rel]=new UTF8Encoding(false).GetBytes(t);
  }
  return bytes;
 }
 string Preserve(string t,string old,string section,string key){var m=Regex.Match(old,"(?m)^"+Regex.Escape(key)+"=([^\\r\\n]*)");if(m.Success)return Regex.IsMatch(t,"(?m)^"+Regex.Escape(key)+"=")?V(t,key,m.Groups[1].Value):Ini(t,section,key,m.Groups[1].Value);return R(t,"(?m)^"+Regex.Escape(key)+"=.*\\r?\\n","");}
 string Read(string rel){string p=Under(Game,rel);return File.Exists(p)?File.ReadAllText(p):"";}bool Exists(string rel){return File.Exists(Under(Game,rel));}string Relative(string f){return f.Substring(Game.Length+1);}IEnumerable<string> Account(string filter){string p=Under(Game,@"APBGame\Config\Account");return Directory.Exists(p)?Directory.GetFiles(p,filter,SearchOption.AllDirectories):new string[0];}
 string UserOptions(string t,bool defaults){string p=defaults?"*":"";var changes=new Dictionary<string,string>();foreach(var pair in new[]{new[]{"AutoReadyMode","AutoReady"},new[]{"SprintDotMode","ShowSprintingDot"},new[]{"VoiceMode","VoipSystemDisable"},new[]{"DuckingMode","VoipDuckingEnabled"}})if(S.S(pair[0])!="Keep")changes[p+pair[1]]=Flag(S.S(pair[0])==(pair[0]=="VoiceMode"?"Off":"On"));if(S.S("VoiceMode")=="Off")foreach(string k in new[]{"VoipChannelAutoAssign","VoipChannelWorld","VoipChannelGroup","VoipChannelSide","VoipChannelClan"})changes[p+k]="False";foreach(var c in changes)t=Ini(t,"Options",c.Key,c.Value);if(S.S("MouseSmoothingMode")!="Keep")t=Ini(t,"Engine.PlayerInput",p+"bEnableMouseSmoothing",Flag(S.S("MouseSmoothingMode")=="On"));return t;}
 string Graphics(string t){
  t=V(t,"LevelParticles",Flag(!S.B("UmgebungspartikelAus")));bool low=S.B("ExtremeTextures")&&!S.B("CustomActive");
  if(low){int cap=16;t=Regex.Replace(t,@"(?m)^TEXCAT_(?!UI=|VFX=|RenderTarget=|LightAndShadowMap=)[^=\r\n]+=.*$",m=>{string line=Regex.Replace(m.Value,@"MaxLODSize=(\d+)",v=>"MaxLODSize="+Math.Min(cap,int.Parse(v.Groups[1].Value)));if(low){line=Regex.Replace(line,@"MinLODSize=(\d+)",v=>"MinLODSize="+Math.Min(1,int.Parse(v.Groups[1].Value)));line=Regex.Replace(line,@"LODBias=(-?\d+)",v=>"LODBias="+Math.Max(4,int.Parse(v.Groups[1].Value)));}return line;});t=R(t,@"(?m)^(nCharacter(?:Diffuse|NormalMap)(?:Width|Height)|nVehicle\w*TextureSize|nGraffitiTexture(?:Width|Height))=\d+","$1="+(low?32:cap));bool poly=low||S.B("CustomLowPoly");t=V(V(V(t,"EnableHighPolyChars",Flag(!poly)),"SkeletalMeshLODBias",poly?"1":"0"),"bUseSimplifiedVehicleMaterials",Flag(poly));t=V(t,"DetailMode",low?"0":S.S("CustomDetail"));if(!low)t=V(t,"DynamicShadows",Flag(S.B("CustomShadows")));}
  if(low){foreach(string k in new[]{"MaxAnisotropy","AnisotropyAmount"})t=V(t,k,"1");foreach(string k in new[]{"Trilinear","DynamicShadows","MotionBlur","DepthOfField","AmbientOcclusion","Bloom","QualityBloom","LensFlares","FogVolumes","SpeedTreeLeaves","SpeedTreeFronds"})t=V(t,k,"False");}if(S.S("GraphicsPreset")=="Balanced"){var before=S.Data;try{S.Data=new Dictionary<string,object>(before);foreach(string k in Graphics31.QualityKeys)S.Set(k,k=="EnvironmentQuality"?1:2);S.Set("CustomDetail","1");S.Set("CustomShadows",false);t=Graphics31.Custom(t,S);}finally{S.Data=before;}}else if(S.B("CustomActive"))t=Graphics31.Custom(t,S);return R(V(t,"ScreenPercentage","100.000000"),@"(?m)^Fullscreen=.*\r?\n","");
 }
 public string Apply(){
  Check();if(RecoveryPending())throw new Exception("RecoveryPending");var jobs=Build();CheckTargets(jobs.Keys);Arguments();ShortcutPath();string b=NewBackup("");var manifest=new List<Dictionary<string,object>>();
  foreach(var j in jobs){string target=Under(Game,j.Key);bool exists=File.Exists(target);if(exists){string dest=Under(b,j.Key);Directory.CreateDirectory(Path.GetDirectoryName(dest));File.Copy(target,dest);}manifest.Add(new Dictionary<string,object>{{"Relative",j.Key},{"Existed",exists},{"SHA256",exists?Hash(Under(b,j.Key)):""}});}
  BackupShortcut(b);File.WriteAllText(Path.Combine(b,"manifest.json"),Settings.Json.Serialize(new{Spielordner=Game,Files=manifest}));
  BeginTransaction(b);try{foreach(var j in jobs)Atomic(Under(Game,j.Key),j.Value);WriteShortcut();if(S.S("Resolution")!="Keep")S.Set("SavedResolutions",S.Sizes().Concat(new[]{S.S("Resolution")}).Distinct().Reverse().Take(30).Reverse().ToArray());SavePreferences();FinishTransaction();}catch(Exception e){try{RestoreManifest(b);FinishTransaction();}catch(Exception rollback){throw new Exception("Apply failed; rollback also failed. Backup: "+b+"\n"+e.Message+"\n"+rollback.Message);}throw new Exception("Apply failed; files restored from backup. "+e.Message);}LogEvent("apply-complete "+Path.GetFileName(b));return b;
 }
 void RestoreManifest(string b){var m=Settings.Json.Deserialize<Dictionary<string,object>>(File.ReadAllText(Path.Combine(b,"manifest.json")));if(!string.Equals(Path.GetFullPath((string)m["Spielordner"]).TrimEnd('\\'),Game,StringComparison.OrdinalIgnoreCase))throw new Exception("Backup belongs to a different game folder.");var files=((System.Collections.IEnumerable)m["Files"]).Cast<Dictionary<string,object>>().ToArray();CheckTargets(files.Select(f=>(string)f["Relative"]));foreach(var f in files){string r=(string)f["Relative"];Under(Game,r);if((bool)f["Existed"]&&!File.Exists(Under(b,r)))throw new Exception("Incomplete backup: "+r);if((bool)f["Existed"]&&f.ContainsKey("SHA256")&&Hash(Under(b,r))!=Convert.ToString(f["SHA256"]))throw new Exception("Backup integrity failed: "+r);}string shortcutMeta=Path.Combine(b,"shortcut.json");if(File.Exists(shortcutMeta)){var sc=Settings.Json.Deserialize<Dictionary<string,object>>(File.ReadAllText(shortcutMeta));if((bool)sc["Existed"]){string copy=Path.Combine(b,"shortcut-before.lnk");if(!File.Exists(copy)||(sc.ContainsKey("SHA256")&&Hash(copy)!=Convert.ToString(sc["SHA256"])))throw new Exception("Shortcut backup integrity failed");}}
  foreach(var f in files){string r=(string)f["Relative"],target=Under(Game,r);if((bool)f["Existed"])Atomic(target,File.ReadAllBytes(Under(b,r)));else if(File.Exists(target))File.Delete(target);}
  string sm=Path.Combine(b,"shortcut.json");if(File.Exists(sm)){var sc=Settings.Json.Deserialize<Dictionary<string,object>>(File.ReadAllText(sm));string p=(string)sc["Path"];if(!Path.GetExtension(p).Equals(".lnk",StringComparison.OrdinalIgnoreCase))throw new Exception("Invalid shortcut backup.");if((bool)sc["Existed"])Atomic(p,File.ReadAllBytes(Path.Combine(b,"shortcut-before.lnk")));else if(File.Exists(p))File.Delete(p);}
 }
 public void Restore(){Check();string root=Path.Combine(Root,"Backups");if(Directory.Exists(root))foreach(string m in Directory.GetFiles(root,"manifest.json",SearchOption.AllDirectories).OrderByDescending(x=>x)){var d=Settings.Json.Deserialize<Dictionary<string,object>>(File.ReadAllText(m));if(string.Equals((string)d["Spielordner"],Game,StringComparison.OrdinalIgnoreCase)){RestoreManifest(Path.GetDirectoryName(m));string sm=Path.Combine(Path.GetDirectoryName(m),"shortcut.json");if(File.Exists(sm)){var sc=Settings.Json.Deserialize<Dictionary<string,object>>(File.ReadAllText(sm));if((bool)sc["Existed"]){ImportShortcut((string)sc["Path"]);S.Set("GameTextLanguage",Regex.IsMatch(S.S("LaunchArguments"),"(?i)-language=1049")?"Russian":"English");SavePreferences();}}File.Move(m,Path.Combine(Path.GetDirectoryName(m),"restored.json"));return;}}throw new Exception("No matching backup found.");}
}
