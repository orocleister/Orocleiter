# Orocleister APB ConfigManager v4.4a — UI update

- Larger, resizable and maximizable window. Default size adapts to the display work area.
- Localization has four tabs: Language & Missions, Kill Notification, HUD & Colors, Keys & Sprint. No long localization scroll page.
- Quick-exit rebinding (F9 default), auto-ready and movement help are grouped under Keys & Sprint. Mouse settings remain under Input.
- Contact biographies contain only mission type + name, one row per mission. No source/date/level blocks or background story. Contacts without verified mission assignments have no generated mission list.
- Eight weapon-role descriptions now list rank-specific weapons, modifications, titles and skins in English and Russian. Rank labels come from the current APBDB milestone records; old generic slot summaries were replaced.
- Custom global UI opacity (0.95–1.0) updates DefaultUI.ini and an existing APBUI.ini. Text/icons can also fade. Inventory/scoreboard behavior needs live verification; this is not an independently adjustable background layer.
- Public-facing option descriptions explain behavior without personal config comparisons. Orocleister Config remains a named profile.

Validation: native build; EN/DE/RU UI previews; minimum/large window layout checks; keyboard-option placement; localization, opacity bounds, Apply/exact Restore checks. No live gameplay or antivirus-clearance claim. Full nearby radio/building-music muting remains unresolved.

UI refinement: dark, equal-width localization tabs with blue active indicators; native white tab borders removed. Verified at minimum and large window sizes in EN/DE/RU.
