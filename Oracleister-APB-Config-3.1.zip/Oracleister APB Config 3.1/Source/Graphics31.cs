using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
public static class Graphics31 {
 public static readonly string[] QualityKeys={"CharacterQuality","VehicleQuality","PedestrianQuality","TrafficQuality","EnvironmentQuality","SymbolQuality"};
 public static void Defaults(Settings s){int old;int.TryParse(s.S("CustomTextureSize"),out old);int level=old<=128?0:old<=512?1:2;foreach(string k in QualityKeys)if(!s.Data.ContainsKey(k))s.Set(k,level);foreach(string k in new[]{"FogMode","AnisotropyMode","VsyncMode"})if(!s.Data.ContainsKey(k))s.Set(k,"Keep");}
 public static void Validate(Settings s){foreach(string k in QualityKeys)if(!new[]{"0","1","2"}.Contains(s.S(k)))throw new Exception("Invalid quality: "+k);foreach(string k in new[]{"FogMode","VsyncMode"})if(!new[]{"Keep","Off","On"}.Contains(s.S(k)))throw new Exception("Invalid render setting: "+k);if(!new[]{"Keep","1","2","4","8","16"}.Contains(s.S("AnisotropyMode")))throw new Exception("Invalid anisotropy");}
 static string Category(string t,string[] names,int cap,int bias){return Regex.Replace(t,@"(?m)^TEXCAT_("+string.Join("|",names)+@")=[^\r\n]*\r?$",m=>{string v=Regex.Replace(m.Value,@"MaxLODSize=\d+","MaxLODSize="+cap);v=Regex.Replace(v,@"MinLODSize=\d+","MinLODSize=1");return Regex.Replace(v,@"LODBias=-?\d+","LODBias="+bias);});}
 public static string Custom(string t,Settings s){
  string[][] categories={new[]{"PlayerCharacter","CharacterSource","CharacterShared"},new[]{"PlayerVehicle","VehicleSource","VehicleShared"},new[]{"LCPedestrian","Contact"},new[]{"LCVehicle"},new[]{"Environment","Prop","Signage"},new[]{"PlayerGraffiti","PrimitiveSource"}};
  int[][] caps={new[]{64,512,4096},new[]{64,512,1024},new[]{16,128,512},new[]{32,256,1024},new[]{16,256,1024},new[]{64,256,1024}};
  for(int i=0;i<QualityKeys.Length;i++){int q=s.I(QualityKeys[i]);t=Category(t,categories[i],caps[i][q],q==0?3:0);}
  int character=new[]{64,512,1024}[s.I("CharacterQuality")],vehicle=new[]{64,512,1024}[s.I("VehicleQuality")],symbol=new[]{64,256,512}[s.I("SymbolQuality")];
  t=Regex.Replace(t,@"(?m)^(nCharacter(?:Diffuse|NormalMap)(?:Width|Height))=\d+","$1="+character);
  t=Regex.Replace(t,@"(?m)^(nVehicle\w*TextureSize)=\d+","$1="+vehicle);
  t=Regex.Replace(t,@"(?m)^(nGraffitiTexture(?:Width|Height))=\d+","$1="+symbol);
  t=Engine.V(t,"EnableHighPolyChars",s.I("CharacterQuality")==0?"False":"True");t=Engine.V(t,"SkeletalMeshLODBias",s.I("CharacterQuality")==0?"1":"0");t=Engine.V(t,"bUseSimplifiedVehicleMaterials",s.I("VehicleQuality")==0?"True":"False");t=Engine.V(t,"DynamicShadows",s.B("CustomShadows")?"True":"False");return Engine.V(t,"DetailMode",s.S("CustomDetail"));
 }
 public static string Render(string t,string rel,Settings s){
  bool compat=rel==@"APBGame\Config\APBCompat.ini";
  if(!compat&&!new[]{@"APBGame\Config\APBMachineOptions.ini",@"APBGame\Config\DefaultMachineOptions.ini",@"APBGame\Config\APBEngine.ini"}.Contains(rel))return t;
  var values=new Dictionary<string,string>();if(s.S("FogMode")!="Keep")values["AllowFog"]=s.S("FogMode")=="On"?"True":"False";if(s.S("VsyncMode")!="Keep")values["UseVsync"]=s.S("VsyncMode")=="On"?"True":"False";
  if(s.S("AnisotropyMode")!="Keep"){values["MaxAnisotropy"]=s.S("AnisotropyMode");values["AnisotropyAmount"]=s.S("AnisotropyMode");}
  foreach(var v in values){if(compat)t=Regex.Replace(t,@"(?ms)^\[AppCompatBucket\d+\][^\r\n]*\r?\n.*?(?=^\[|\z)",m=>{string section=Regex.Match(m.Value,@"^\[([^\]]+)\]").Groups[1].Value;return Engine.Ini(m.Value,section,v.Key,v.Value);});else t=Engine.Ini(t,"SystemSettings",v.Key,v.Value);}
  return t;
 }
}
