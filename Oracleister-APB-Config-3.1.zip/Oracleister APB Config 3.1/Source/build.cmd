@echo off
setlocal
cd /d "%~dp0"
set "compiler=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if not exist "%compiler%" set "compiler=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe"
"%compiler%" /nologo /target:winexe /platform:anycpu /optimize+ /reference:System.Windows.Forms.dll /reference:System.Drawing.dll /reference:System.Web.Extensions.dll /reference:Microsoft.CSharp.dll /win32manifest:app.manifest /win32icon:..\Assets\app.ico /out:..\APB-Config.exe Program.cs Backend.cs UI.cs ApbTheme.cs Diagnostics.cs DisplayModes.cs Population.cs Graphics31.cs UI31.cs
exit /b %errorlevel%
