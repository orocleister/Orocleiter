using System;
using System.IO;
using System.Windows.Forms;
using System.Reflection;
[assembly:AssemblyTitle("Oracleister APB Config")]
[assembly:AssemblyProduct("Oracleister APB Config")]
[assembly:AssemblyDescription("APB configuration editor and direct game launcher. Native .NET Windows application.")]
[assembly:AssemblyVersion("3.1.0.0")]
[assembly:AssemblyFileVersion("3.1.0.0")]
static class Program {
 [STAThread] static void Main(){Application.EnableVisualStyles();Application.SetCompatibleTextRenderingDefault(false);Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);Application.ThreadException+=(s,e)=>MessageBox.Show(e.Exception.Message,"Oracleister APB Config 3.1",MessageBoxButtons.OK,MessageBoxIcon.Error);try{using(var app=new ConfigWindow(AppDomain.CurrentDomain.BaseDirectory,false))Application.Run(app);}catch(Exception e){MessageBox.Show("Extract the complete folder before starting APB-Config.exe.\n\n"+e.Message,"Oracleister APB Config 3.1",MessageBoxButtons.OK,MessageBoxIcon.Error);}}
}
