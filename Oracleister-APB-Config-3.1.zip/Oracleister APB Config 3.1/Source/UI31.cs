using System;
using System.IO;
using System.Linq;
using System.Drawing;
using System.Windows.Forms;
using System.Collections.Generic;
public sealed partial class ConfigWindow {
 string previewDirectory;
 void SetCombo(string property,string value){var b=combos.First(x=>x.Property==property);for(int i=0;i<b.Control.Items.Count;i++)if(((Entry)b.Control.Items[i]).Value==value){b.Control.SelectedIndex=i;break;}s.Set(property,value);}
 Form Dialog(string key,int width,int height){return new Form{Text=T(key),ClientSize=new Size(width,height),StartPosition=FormStartPosition.CenterParent,BackColor=dark,ForeColor=ink,Font=Font,FormBorderStyle=FormBorderStyle.FixedDialog,MaximizeBox=false,MinimizeBox=false};}
 void DLabel(Form d,string key,int x,int y,int w,int h){var l=new Label{Text=T(key),ForeColor=muted};l.SetBounds(x,y,w,h);d.Controls.Add(l);}
 ComboBox DChoice(Form d,string key,string value,int y,string[] values,string[] labels){DLabel(d,key,20,y,280,28);var c=new ApbComboBox{DropDownStyle=ComboBoxStyle.DropDownList};c.SetBounds(310,y,310,30);for(int i=0;i<values.Length;i++)c.Items.Add(new Entry{Value=values[i],Text=T(labels[i])});c.SelectedIndex=Math.Max(0,Array.IndexOf(values,value));d.Controls.Add(c);return c;}
 DialogResult ShowSettings(Form d,string name){if(!testing)return d.ShowDialog(this);d.StartPosition=FormStartPosition.Manual;d.Location=new Point(-10000,-10000);d.Show();Application.DoEvents();using(var b=new Bitmap(d.Width,d.Height)){d.DrawToBitmap(b,new Rectangle(0,0,d.Width,d.Height));b.Save(Path.Combine(previewDirectory,name+"-"+language+".png"));}d.Hide();return DialogResult.OK;}
 void Custom(){using(var d=Dialog("GraphicsCustom",660,635)){
  DLabel(d,"QualityIntro",20,16,620,46);var sliders=new Dictionary<string,TrackBar>();string[] keys=Graphics31.QualityKeys.Concat(new[]{"CustomDetail"}).ToArray();
  for(int i=0;i<keys.Length;i++){string k=keys[i];int y=76+i*57;DLabel(d,k,20,y,225,28);var value=new Label{ForeColor=ink};value.SetBounds(534,y,105,28);d.Controls.Add(value);var track=new TrackBar{Minimum=0,Maximum=2,TickFrequency=1,SmallChange=1,LargeChange=1,Value=s.I(k),BackColor=dark,AccessibleName=T(k)};track.SetBounds(247,y-8,272,46);Action update=()=>value.Text=T(new[]{"QualityLow","QualityMedium","QualityHigh"}[track.Value]);track.ValueChanged+=(a,b)=>update();update();d.Controls.Add(track);sliders[k]=track;}
  var shadows=new ApbCheckBox{Text=T("CustomShadows"),ForeColor=ink,Checked=s.B("CustomShadows")};shadows.SetBounds(20,477,620,30);d.Controls.Add(shadows);DLabel(d,"QualityLimits",20,516,620,52);
  var ok=new ApbButton{Text=T("CustomUse"),DialogResult=DialogResult.OK,ForeColor=ink,BackColor=dark};ok.SetBounds(20,584,620,36);d.Controls.Add(ok);d.AcceptButton=ok;
  if(ShowSettings(d,"custom")==DialogResult.OK){foreach(var p in sliders)s.Set(p.Key,p.Value.Value);s.Set("CustomShadows",shadows.Checked);s.Set("CustomActive",true);s.Set("ExtremeTextures",false);UpdateGraphics();}
 }}
 void RenderingOptions(){using(var d=Dialog("RenderingOptions",640,472)){
  DLabel(d,"RenderingHelp",20,16,600,48);var original=combos.First(x=>x.Property=="AAMode").Control;var aa=DChoice(d,"AALabel",((Entry)original.SelectedItem).Value,80,new[]{"Keep","Off","2","4","8"},new[]{"KeepSetting","AAOff","2x MSAA","4x MSAA","8x MSAA"});
  var fog=DChoice(d,"FogLabel",s.S("FogMode"),131,new[]{"Keep","Off","On"},new[]{"KeepSetting","SettingOff","SettingOn"});var af=DChoice(d,"AnisotropyLabel",s.S("AnisotropyMode"),182,new[]{"Keep","1","2","4","8","16"},new[]{"KeepSetting","FilteringOff","2x","4x","8x","16x"});var vsync=DChoice(d,"VsyncLabel",s.S("VsyncMode"),233,new[]{"Keep","Off","On"},new[]{"KeepSetting","SettingOff","SettingOn"});
  DLabel(d,"ColorFilterHelp",20,286,600,64);var filter=new ApbButton{Text=T("ColorFilters"),ForeColor=ink,BackColor=dark};filter.SetBounds(20,352,600,36);filter.Click+=(a,b)=>Open("ms-settings:easeofaccess-colorfilter");d.Controls.Add(filter);
  var ok=new ApbButton{Text=T("UseRenderOptions"),DialogResult=DialogResult.OK,ForeColor=ink,BackColor=dark};ok.SetBounds(20,416,600,36);d.Controls.Add(ok);d.AcceptButton=ok;
  if(ShowSettings(d,"rendering")==DialogResult.OK){SetCombo("AAMode",((Entry)aa.SelectedItem).Value);s.Set("FogMode",((Entry)fog.SelectedItem).Value);s.Set("AnisotropyMode",((Entry)af.SelectedItem).Value);s.Set("VsyncMode",((Entry)vsync.SelectedItem).Value);}
 }}
}
