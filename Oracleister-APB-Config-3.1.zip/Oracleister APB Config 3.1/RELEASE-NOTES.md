﻿# Oracleister APB Config 3.1 — native Windows release

## 3.1 — 6 October 2026

Added English Pro (241 translated title entries, 183 unique titles), preserving all non-title MissionTemplates values and markup tokens. Only four English Pro tables differ from the English source: MissionTemplates, HudGroupStates, APBUserInterface and Organisations. Weapon/vehicle descriptions and mission stages remain unchanged. Japanese glyph display has not been verified inside APB; no fonts are replaced.

Added independent texture-quality sliders, a shared model-LOD choice through low character quality, advanced rendering options, and a Windows color-filter settings link. No direct overhead nameplate color setting was verified. Max Low is now 16-pixel ordinary texture caps and 32-pixel generated character/car/graffiti textures; protected UI/effect/render-target categories remain unchanged.

Tests passed: 7 GUI pages and both graphics dialogs in 3 languages; Normal defaults; independent character/car/NPC/environment outputs; render overrides across all five compatibility buckets and machine settings; low texture limits with protected categories unchanged; Pro/English switching output; unchanged mission-stage values and markup; settings persistence; invalid-setting rejection; apply/byte-exact restore on a dummy game folder; population parser regression tests. Fixed a CRLF line-matching bug found by the new texture-category tests. No installed game files were changed during testing.

In-game visibility, glyph rendering and FPS remain unverified. The EXE remains unsigned. See README for rule sources, color-filter limitations and settings usage.


## Live population fix (EXE 3.0.1.0)

Fixed parsing of the source timestamp now wrapped in a time element. Counts remain available when the timestamp is absent. Added localized connection/format errors and explicit stale labels for the last successful snapshot. Refresh remains once per minute. Verified against the current public HTML, legacy and absent timestamps, malformed pages, zero counts, and a successful live HTTPS request through the EXE HTTP client on 5 October 2026. No certificate checks were disabled. Graphics, game files and saved settings are unchanged by this update.


The app has been rewritten in C# / Windows Forms for .NET Framework 4.8. It does not launch PowerShell, embed its runtime or interpret scripts. APB-Config.exe is the application itself. No external runtime download, elevation, security exclusions or policy changes are performed. Normal play/apply/update behavior is preserved.

## Verification — 5 October 2026

- Compared 1,203 generated files across Normal, Max Low, Custom and alternate audio/mouse settings against the previous backend. All compared values and text matched after normalizing INI line order and line endings. Localization descriptions are unchanged.
- Applied to a dummy game folder, restored exact original file hashes, removed newly created files/shortcut, and rejected invalid settings without writes. Fixed a JSON array conversion issue found during this test.
- Rendered all seven pages in English, German and Russian and checked custom resolution / empty FPS mapping.
- The EXE compiled from the included source. It uses standard .NET/Windows libraries, without obfuscation or executable packing. The old launcher EXE is not included.

The tests did not start or change the installed game. In-game graphics, FPS, account restrictions, live population service availability and antivirus clearance are not certified. The file is unsigned; a legitimate publisher code-signing certificate would be needed for a signed release. SHA256SUMS.txt verifies content consistency only and is not a security verdict.

## Buttons

Apply changes game files with a backup. Update Game launches only APBLauncher.exe and does not call Apply or Play. The official updater may have its own preferences. Play APB uses the direct shortcut and closes the config; unsaved graphics/audio choices are not installed. Keep the entire folder together. Backups from a different extracted copy are not automatically imported.

## Sources and limitations

Graphics/reference inputs: https://github.com/flawsv/apb and https://github.com/lvzxr/apb-cfg-loader . The supplied Advanced Launcher 1.13.5.5 README was inspected without executing its binary. Historic approval of that launcher is not approval of this application. Custom exposes selected useful options, not the complete Advanced Launcher interface.

New palettes apply only to supported combat/scoreboard text, not overhead nameplates. There is no verified global mute for other players' car radios while retaining death themes. Smoke-removal and automatic district-join macros were not added. Normal's clear-character profile and the existing graphics visibility constraints remain.

## Build

Source/build.cmd uses the Windows .NET Framework C# compiler. It builds APB-Config.exe in the parent folder using the included source, manifest and icon. Normal use does not require building anything. The compiler embeds timestamps, so rebuilding may produce a different executable checksum.
