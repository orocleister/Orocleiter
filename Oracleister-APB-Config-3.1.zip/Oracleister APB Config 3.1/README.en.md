# Oracleister APB Config 3.1

## New in 3.1

**English Pro** is an optional English-based style under Launch → Game text / missions. It adds Japanese mission titles (183 distinct titles / 241 entries) and Japanese versions of selected ready, matchmaking, result, chat and faction labels. Mission objectives, stage text, timers, delivery/raid instructions, weapon and vehicle descriptions remain English. The Japanese titles are creative adaptations, not an official translation. Press Apply before switching between English and English Pro; both use the same GER slot. Russian keeps its separate slot.

Japanese glyph rendering has not been verified in APB. If you see boxes or missing characters, select English and Apply. No game fonts or binary resources are changed.

**Custom graphics** now has independent Low / Medium / High sliders for characters, player vehicles, pedestrians/contacts, traffic, roads/environment and symbols, plus world detail and dynamic shadows. NPC controls adjust textures. Low character quality also selects simplified character rendering; skeletal model LOD can affect other models. These sliders do not create separate per-NPC geometry controls that the engine does not expose. The slot is saved with Apply. Existing Normal remains unchanged.

**Basic → Advanced graphics** contains anti-aliasing, fog, anisotropic filtering and VSync. Options apply to the selected preset; Apply and restart APB. The AA choice is shared with Basic. Choosing Max Low also selects AA off, fog off, 1x filtering and VSync off; the advanced controls can override those choices afterwards.

**Max Low** lowers ordinary texture-category caps to 16 pixels and generated character/vehicle/graffiti textures to 32. UI, effect textures, render targets and visibility distances are retained. This may look extremely rough and does not guarantee an FPS gain or fence clarity. Normal restores the base profile. No skybox, smoke, audio bank or game resource is removed by the new options.

**Color vision:** Advanced graphics links to Windows color filters. These are system-wide filters, not a separate APB nameplate recoloring feature; full-screen behavior can vary. No verified supported INI for overhead friend/enemy nickname colors was found. The existing team/enemy pairs continue to affect supported text and scoreboard messages only.

Sources checked: [GamersFirst SARD FAQ](https://www.gamersfirst.com/apb/news/2024/8/14/sard-faq), [Flaws](https://github.com/flawsv/apb), [Windows color filters](https://support.microsoft.com/en-au/accessibility/windows/use-color-filters-in-windows). The FAQ permits supported INI and localization edits but excludes skybox/VFX removal. This package is not officially approved or certified ban-free.


## Version 3.0 — Windows app

Extract the complete folder, then double-click **APB-Config.exe**. Keep Assets, Profile, Optional, Languages.json and Einstellungen.json beside it. This is a native C# / .NET Framework Windows application. It does not launch or host PowerShell and does not need PowerShell 7. It uses .NET Framework 4.8, included in current Windows 10/11 systems. No installer or administrator request is added.

**Apply** installs the selected configuration and creates a backup. **Update Game** only opens the official updater; it does not apply settings or request a game launch. The updater controls its own behavior. **Play APB** updates and opens the direct shortcut without applying pending graphics/audio changes, then closes the config. After an official update, reapply your settings if the game replaced them.

**Graphics:** Normal retains clear characters, cars and symbols. Max Low uses the existing low model/texture limits and explicitly turns off shadows and postprocessing in the supplied quality blocks. Custom provides one saved slot with separate texture-quality sliders, dynamic shadows and world detail. Switching presets preserves the custom values. Click Apply and restart APB. Rendering buffers, interface textures and render scale are retained to avoid reintroducing the broken extreme-boost approach.

**Colors:** Standard, Blue/Red, Green/Red, Black/Pink, Blue/Orange and Yellow/Purple. First is team, second is enemy. Blue/Orange is an alternative to red/green, not a universal colorblind mode. Colors affect supported combat and scoreboard messages, not overhead nicknames. The latest English HUD, faction and contact aliases are included. Mission and item descriptions remain intact.

**Security and transparency:** this is a new executable, not the previous PowerShell wrapper. Source and a build.cmd for developers are in Source. Normal users only run APB-Config.exe. There is no obfuscation, executable packer, security-policy change or antivirus exclusion. The executable is unsigned and has not received independent malware clearance. Windows or antivirus may still warn. Do not treat the rewrite or the included SHA-256 hashes as a safety certificate. See RELEASE-NOTES.md for tests and limitations.

The Community panel requests public population data from gamersfirst.com while open. Browser links open only when clicked. No telemetry was added.


Both 1200×1800 (portrait) and 1800×1200 (landscape) are explicit presets and native-menu entries. Apply with APB closed, then restart once. If fullscreen rejects a size, try Windowed; driver support still matters.

Wide preset: 1800×1200 (1200×1800 is portrait). Social uses a 2700-second / 45-minute pending-object purge interval; NoSocial keeps it disabled. Memory-pressure collection may happen earlier. This is engine memory cleanup, not disk/shader-cache deletion. Longer intervals may increase memory use and the duration of a later pause. Base values remain labelled in item descriptions; modifications can change them.

**Vehicle and new weapon stats.** Added APBDB base statistics to 565 vehicle variants and 15 weapons that previously lacked a stats block, including Joker M9S Pulse Check and Joker C9S Prototype. Existing descriptions remain below the new block. Values are before modifications: installed mods, cargo and damage can alter performance. Vehicle health is not a universal bullet count. Acceleration times are not supplied by the source and are not invented. Ideal weapon TTK assumes a 1000-HP target, full damage and no misses; pellet and burst weapons are not given a simplified TTK. Source snapshot: 27 September 2026. Item links and exact added blocks: ITEM-STATS-SOURCES.json. Sources: [APBDB](https://apbdb.com), [Legends update](https://www.gamersfirst.com/apb/news/2026/3/27/apb-legends), [June balance update](https://forums.gamersfirst.com/topic/33440-0618-heatwave-patch-announcement/). This fills missing blocks; it is not a complete rebalance audit of every older weapon.

## Settings update — 26 September
Grenade smoke / trails: no independent on/off switch is available here. The previous checkbox only changed shared VFX texture quality. Full smoke removal is prohibited by Little Orbit; this app does not remove effect files.


**Resolution.** Apply saves the chosen size and adds 640×480, 800×600, 960×540, 1024×768, 1152×864, HD, Full HD and saved custom sizes to APB's native Video menu through ExtraResolution. The old 1024×720 minimum filter is lowered in DefaultEngine and the existing APBEngine cache. Restart APB once after applying; then use O → Video → Resolution → Apply as often as needed during play. Existing extra sizes are retained. Unsupported fullscreen modes may be rejected; use Windowed for those sizes. Borderless follows the desktop. Keep current preserves the current resolution while updating the menu. A game repair/update may replace these files; apply again afterwards.

**Colors.** Single-color presets are replaced by team/opponent pairs: blue/red, green/red and black/pink. Killer, victim and assist colors follow their side in supported HUD messages. Only role-color tags change; text, icons, mission descriptions and character colors stay intact. Standard restores the source bytes. Black is harder to read on dark backgrounds.

**Mouse Fix.** On disables smoothing across BaseInput, APBInput, DefaultInput, Default-FRA-Input, DefaultUserOptions, account UserOptions and existing character UserConfig overrides. Existing view-acceleration flags are disabled. Off enables smoothing. Legacy remains smoothing off with axis speed 2.0; normal modes use speed 1.0. Sensitivity, aiming sensitivity, DPI and Windows settings are not rewritten. Restore backup returns the exact previous files.

**Why texture streaming.** On loads textures gradually to reduce memory demand, but loading can cause brief pauses. Off can reduce some loading pauses while using more memory. Compare both on the same route and restart APB between tests; 32 GB RAM does not guarantee that one mode is always faster.

**Music.** Other players' car radios may remain audible even with created songs disabled and local playlist volume at zero. Playback state is now explicitly saved; existing overrides and machine defaults are handled too. A reliable global mute for other players’ radios while keeping kill themes has not been established. No audio banks or instruments are removed, and master volume is untouched. The diagnostic button shows installed values without editing them.

**Commands.** Tools → Commands and keybinds opens `/fps`, `/pop`, `/a`, `/q`, chat and other player commands from the existing English localization. [Open reference](COMMANDS.en.md). The reference does not rewrite in-game labels or mission descriptions.


## New in 2.8

- Basic → Resolution includes 640×480, 640×640, 800×600, 800×800, 960×540, 1024×768, 1024×1024 and 1152×864. Custom width × height opens two fields. Input limits are 320–7680 wide and 240–4320 high; these are validation limits, not a guarantee that APB or your display supports every size. Keep current remains the default.
- Language names are English / Russian. The English localization from before 2.6 is restored. Russian retains the same stage order, timers, numbers and weapon-stat lines. Item sizes S/M/H mean small/medium/heavy. Statistics and timers are preserved from the previous edition; their accuracy after game patches has not been revalidated.
- The music-prank button is removed. In-game localization jokes remain.


## English / Russian game text

Open **Launch → Game text / missions**. Keep **Install English and Russian game text** enabled, select a language and click **Apply**. Then use **Play APB**. Restart the game after changing its language. The language selector in the top-right corner only changes this program.

Both packs are installed together. After the first Apply, changing the game language and pressing Play APB updates the direct shortcut. Ordinary graphics and audio changes still need Apply. Launching the game from a different shortcut uses that shortcut's language argument.

Russian mission-stage summaries and weapon statistics now follow the restored English layout. Other translations use the Russian game tables and supplementary translations. Proper weapon model names stay unchanged. Some newer messages outside those categories may fall back to English. This is a community translation, not a new official language pack.


**Max Low** also lowers generated character, vehicle and symbol textures to 32 pixels and caps ordinary texture categories at 16 pixels or their existing lower limit. It selects simpler character and vehicle rendering where supported. UI, render targets, resolution and visibility distances are retained. Thin fences may lose detail. Normal + Apply restores the usual quality preset. FPS and visual results still need an in-game check.

Restore backup now also restores the shortcut saved with that application. Keep the Backups folder. Older package backups are not automatically imported into this release.


APB configuration, direct launch and reversible settings. The interface starts in English; German and Russian are available from the language menu.

## Getting started

1. Extract the complete folder and keep the EXE, data files and Assets together.
2. Close APB and its launcher, then open **APB-Config.exe**.
3. Select an APB shortcut or `Binaries/APB.exe` in Basic.
4. Set the options and click **Apply**.
5. Use **Play APB** for direct launch.

Red crossed blades mean enabled; grey blades mean disabled. Keep current leaves the selected option unchanged. Changes require Apply and a game restart.

## Launch buttons


## 01  BASIC

**Game resolution** — Default: keeps installed resolution. Render scale stays at 100%.

**FPS limit** — Default: 144. Empty or 0 removes the FPS cap. MSAA can lower performance.

**NORMAL · clear players** — Low environment detail; higher-quality players, outfits, symbols and vehicles. Normal fence textures and 100% render scale.

**MAX LOW · all graphics** — Lowers textures for players, clothing, vehicles and symbols as well. Fences may become opaque. FPS gains are not guaranteed. Normal + Apply restores the regular preset.

**Enable clothing and vehicle editors** — Enabled: Social designers work. Disabled: may reduce periodic stutters, but can break designers and increase respawn pauses.

## 02  ADVANCED

**Vehicle fire / shared hit particles** — Blood is linked to Vehicle fire / shared hit particles above. Disable that switch to reduce the shared effects. It is not an independent blood filter; complete removal of every blood effect is unverified.


**Disable ambient particle effects** — Disables level ambient particles. Grenade and vehicle effects use separate controls.

**Show muzzle flashes** — Shows or hides weapon muzzle flashes. No change to damage or accuracy.

**Show ejected shell casings** — Shows or hides visual shell casings ejected by weapons.

## 03  AUDIO

**Vivox voice chat** — Disables the voice system, auto-join and voice channels in local account settings. Restart required. Voice-library unloading and FPS gains are unverified. Re-enable channels in APB after turning voice back on.

**Game audio ducking** — Disabled: voice chat no longer lowers other game sounds.

**Player death themes** — Short tunes after a kill. Audible enables themes from friends, ignored players and other players.

**Player-created songs** — Uses APB’s Disable Created Songs option. Does not mute the licensed song library. Kill themes are controlled separately.

**Local playlist volume** — 0% mutes saved local players and disables auto-resume and car broadcast. Other players’ radio may remain audible. Playlists are kept.

## 04  CONTROLS


**In-game sprint dot** — Controls APB’s built-in sprint dot for existing local accounts. It does not provide a permanent crosshair.

**Auto-ready for missions** — Enables APB’s automatic mission-ready setting.

**Reset HUD scale to game default** — Resets HUD scale to the game default on Apply. Does not guarantee a fix for aim offset. Restore backup undoes the reset.

## 05  LAUNCH

**Skip loading movies** — Adds -nomovies to direct launch. Skips intro videos; map loading remains.

**Skip startup splash** — Adds -nosplash to direct launch. The anti-cheat window remains visible.

**Disable Steam integration** — Adds -nosteam. Disables Steam auto-login; a separate game login is required.

**Simple login background** — Uses the district-selection background at login. Disable for character creation.

**Game language** — Select English or Russian, then Apply.

**Extra community jokes** — Adds Cheater Located and Sosality loading… with custom game text. Humorous labels only; no cheat detection.

## 06  TOOLS

**Texture streaming** — Loads textures as needed. On/off can affect stutters differently across systems. Restart required.

**Disk cache** — Uses a disk cache for reusable data. Disabled by default; usefulness depends on available RAM and storage.

**Gamma** — Changes brightness across the whole image. Does not darken only the sky or set a fixed time of day.

## Crosshair · Risk

**Experimental shader crosshair** — Draws a contrasting point in the centre of the rendered scene. Adds only the supplied crosshair fragment to a compatible installed shader. Apply creates a backup before the change. Disabled by default.

**Accept the shader modification risk** — Use at own risk. No official approval is confirmed for this shader edit. Game-file modifications may lead to account sanctions.

**Remove this app’s dot** — Experimental: visibility depends on the active post-processing and shader cache. No guarantee for the current game version. Does not move the weapon reticle or fix an aim offset. The point scales with resolution. Removal deletes only this app’s marked fragment; Restore backup returns the previous file.

## Music scope

The preset button enables kill themes, disables created songs and sets local playlist volume to zero. Zero also disables local auto-resume, playback on foot and vehicle broadcasting. Raising volume later does not automatically restore those playback choices; configure them in APB or restore the backup. Other players’ licensed radio music may remain audible. No verified setting was found that silences every remote song while preserving kill themes. Audio banks and instrument folders are left intact. Existing local libraries are required; open the music player in APB once if none has been saved.

## Backups

Restore backup reverses the most recent game-file application for the selected game folder. Earlier changes require earlier backups. Shortcut backups are separate: shortcut-before.lnk and shortcut.json record the original shortcut. Keep the Backups folder. After an update, let the launcher finish before applying settings again.

## Population and links

Population is read from the official GamersFirst district page every 60 seconds while the app is open. Total, EU and NA counts and faction splits reflect website snapshots, not a direct game-server connection. Unavailable data is shown as unavailable rather than zero. News, forum and Discord links open when clicked.

## Crosshair alignment

A shader dot marks the centre of the rendered scene; it does not correct the weapon’s aim. Visibility depends on post-processing and compiled shader caches. Shader caches are not deleted. A monitor overlay normally does not appear in screenshots; a phone photo is needed to compare it with the in-game reticle. No aim offset has been measured or fixed.

## Validation and credits

Configuration writes, restoration and interface controls are tested on copies. Shader compilation, music playback, FPS gains and Vivox library unloading require in-game verification. This is a community tool, not an official release. Background approval artwork is decorative, not evidence of permission.

[Flaws](https://github.com/flawsv/apb) · [Lazer](https://github.com/lvzxr/apb-cfg-loader) · [SARD FAQ](https://www.gamersfirst.com/apb/news/2024/8/14/sard-faq) · [Crosshair source](https://zhyk.org/forum/showthread.php?t=466225)
