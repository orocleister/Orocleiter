# Orocleister APB ConfigManager v4.3

- Three music shortcuts: keep existing settings, enable songs at 50%, or mute songs/player while retaining death themes. Apply settings afterwards. These do not guarantee muting environment or passing-car radio.
- Moderately darker weapon/category colors, preserving names and descriptions.
- Optional original/funny contact and item names; original proper names use English in both localizations.
- Hidden own-name label: Tiggs. Other generated streamer aliases are unchanged.
- Corrected excess Russian name/stage placeholders; live message rendering still needs verification.
- Added Pioneer vehicle-setup alias. Player-created custom car names are unaffected.
- Removed VIP-labelled entries from English contact mission lists. Current contact mission probabilities are not verified.
- Profile label: Orocleister Config.

Not included: fixed evening/black sky, native crosshair recoloring, full ambient/car-radio suppression, new mission equipment pictures, separate HUD/chat transparency controls or a chat-color editor. No protected game resources were modified to implement these features. Existing gamma/Bloom settings affect general rendering, not only sky.

Build and fixture tests are listed in VALIDATION-4.3.md. No claim of a live-game test, guaranteed FPS improvement, ban-free certification or antivirus clearance. This unsigned community application includes source and file hashes.

## Revision 2026-11-13
- Graphics > Additional rendering: independent dynamic shadows, motion blur, depth of field and lens flares. Overrides apply after profile selection; Keep retains the selected profile output.
- Input > Other controls: Quick exit can be preserved, disabled or assigned a keyboard key (letters, digits, function/navigation keys and numpad). The chosen key is reassigned from its previous action. Existing binding is no longer forcibly reset to F9 on every Apply.
- Classic mouse fix writes smoothing/acceleration flags to BaseEngine, BaseInput, DefaultInput and APBInput; existing account flags are also updated. Axis sensitivity is retained.
- Refreshed 213 APBDB mission records on 2026-11-13. Rebuilt 50 contact mission descriptions in each language from explicit enabled associations and level ranges. Original Russian biographies retained. No server probability claims. CREME DE LA CRIME is not assigned to Shift in this data.
- Audio/display diagnostic now reports per-account song flags as well as muted local music libraries. Complete environment/car-radio mute remains unverified and is not promised.
- No new speculative latency, registry or scheduler tweaks. Existing smoothing, acceleration, VSync and frame-queue controls remain independently configurable.

Keyboard binding revision: select a key or use Press key for letters/digits/function keys. Single keys only; combinations and mouse buttons are not supported. Keyboard mapping, apply/restore and UI rendering tests passed.

Quick exit defaults to F9 for fresh settings. Existing explicitly saved key selections are preserved. Key changes take effect after Apply and APB restart.

Persistent preferences revision: save on close/Apply/Play; version-independent per-Windows-user storage with previous-file backup. Previously chosen keys and profile values persist. Game settings still require Apply.
