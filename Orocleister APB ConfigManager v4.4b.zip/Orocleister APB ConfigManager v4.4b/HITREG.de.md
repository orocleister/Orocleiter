# Input und Trefferregistrierung
Gleiche durchschnittliche FPS und gleicher Ping bedeuten nicht automatisch gleiche Frame-Zeiten oder eine gleich stabile Verbindung. Ein verifizierter Config-Schalter für garantiert bessere serverseitige Trefferregistrierung ist nicht bekannt.

Vergleicht im selben Distrikt mit gleicher Waffe, Mods, Entfernung und Schussfolge. Zeichnet /fps beim Problem auf: Client-Framezeit, Serverzeit, Latenz und Paketverlust. Vergleicht per LAN-Kabel und pausiert Hintergrund-Downloads. Immer nur eine Einstellung ändern.



Offizielle Quellen:
https://support.gamersfirst.com/help/a/my-latency-is-really-high
https://forums.gamersfirst.com/topic/32833-apb-network-update/
