# Audio test — v4.4

This compares existing music options; it is not a confirmed new radio fix. Only themes selects muted music player, disabled created songs and audible kill themes. Apply saves the selection.

1. Test A: Have a friend play a song in a vehicle using your current settings. Record position and distance. Listen to a kill theme too.
2. Close APB. Select Only themes, then Apply. The manager creates its normal backup. Restart APB.
3. Test B: Use the same car, song, volume and distance. Check other players' radio, your radio, kill themes, footsteps and engine sounds separately.
4. Record whether the radio is audible, quieter or silent and whether kill themes still play. Do not change other audio settings during the comparison.
5. To revert, close APB and restore the matching backup under Tools. This restores all settings in that backup, not only audio.

