# v4.4b — 24 November 2026

- Editable own streamer nickname under Text / HUD > Kills / Streamer. Default Tiggs; saved with local preferences. Changes CharacterNameRemoved in both EN/RU when localization is applied. Enable Hide Your Name inside APB. Other player names and account identity are unchanged. Validates length and rejects localization markup/control characters.
- Version display and assembly updated to 4.4b / 4.4.2.0.
- Streamer nickname EN/RU output and validation tests passed; UI checked at minimum size.

Audio status: full nearby-radio/building-music muting remains unresolved and was reported not working. Installed DisableCreatedSongs=True was confirmed on 24 November; reapplying it is not a new fix. Audio help now explicitly describes this limitation.

- EU/NA whisper helper under Text / HUD > Language and missions: copies `/w Name@EU ` or `/w Name@NA `. Paste and send manually in APB. No input automation or game integration.
- Ernst “Mule” Templeton (Waterfront_E11) renamed Proga when Funny Names is on.
- Russian stage counters use CurrentStage/MaxStages, without stray colons.
- Equipment icons precede mission titles in both languages to reduce clipping with long titles. Existing mapping coverage is unchanged; not every mission needs equipment or has a verified mapping.
- Quick-exit binding cleanup now handles Unreal .Bindings entries as well as +Bindings and plain Bindings, avoiding duplicates and stale keys. Default F9 and remapping retained. The existing open APBLoginLevel command remains; live functionality after the server update is not verified.

Checks: native build; fixture tests for EN/RU, aliases, equipment toggles, stage placeholders, binding conflicts and idempotence, EU/NA command validation. UI rendered in EN/DE/RU. No live game files modified during preparation. Requires Apply and restart APB. In-game icon rendering and district exit still need a gameplay check.

Official cross-world information: https://www.gamersfirst.com/apb/news/2026/11/23/cross-world-matchmaking

# Orocleister APB ConfigManager v4.4a — UI update

- Larger, resizable and maximizable window. Default size adapts to the display work area.
- Localization has four tabs: Language & Missions, Kill Notification, HUD & Colors, Keys & Sprint. No long localization scroll page.
- Quick-exit rebinding (F9 default), auto-ready and movement help are grouped under Keys & Sprint. Mouse settings remain under Input.
- Contact biographies contain only mission type + name, one row per mission. No source/date/level blocks or background story. Contacts without verified mission assignments have no generated mission list.
- Eight weapon-role descriptions now list rank-specific weapons, modifications, titles and skins in English and Russian. Rank labels come from the current APBDB milestone records; old generic slot summaries were replaced.
- Custom global UI opacity (0.95–1.0) updates DefaultUI.ini and an existing APBUI.ini. Text/icons can also fade. Inventory/scoreboard behavior needs live verification; this is not an independently adjustable background layer.
- Public-facing option descriptions explain behavior without personal config comparisons. Orocleister Config remains a named profile.

Validation: native build; EN/DE/RU UI previews; minimum/large window layout checks; keyboard-option placement; localization, opacity bounds, Apply/exact Restore checks. No live gameplay or antivirus-clearance claim. Full nearby radio/building-music muting remains unresolved.

UI refinement: dark, equal-width localization tabs with blue active indicators; native white tab borders removed. Verified at minimum and large window sizes in EN/DE/RU.
