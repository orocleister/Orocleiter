# Orocleister APB ConfigManager v4.4b

Extract the entire ZIP and run APB-Config.exe. The window can be resized and maximized.

Graphics groups display, FPS, Orocleister Config, Low, Balanced and Custom, with rendering/effects underneath. Input contains mouse settings. Text / HUD has Language & Missions, Kill Notification, HUD & Colors, and Keys & Sprint tabs. Quick exit (F9 default), auto-ready and movement help are in Keys & Sprint. Actual movement bindings are assigned in APB Options > Controls. Launch contains the game path. Tools contains backups, profiles and diagnostics.

Close APB and its launcher before Apply, then restart. Play APB uses already installed settings; it does not apply pending changes. Update Game opens the official updater. Preferences are saved on close; file changes are backed up before Apply.

Custom HUD opacity is under Text / HUD > HUD & Colors. A lower value is more transparent; start at 0.98 and revert to Config style if readability suffers. This is global and may fade text/icons too. Inventory/Tab behavior requires live testing.

Nearby radio/building music muting remains unresolved. No guaranteed FPS or hit-registration gain. See RELEASE-NOTES.md and CONFIG-COMPARISON-4.4.md.
