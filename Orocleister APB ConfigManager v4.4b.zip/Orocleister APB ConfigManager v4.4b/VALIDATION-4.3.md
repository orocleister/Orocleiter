# Validation — 4.3

Passed: C# build; current-source regression checks for ordinary/funny names, Tiggs, Russian stage/name placeholders; independent mouse smoothing/acceleration/frame queue with sensitivity preserved; fixture apply and byte-exact restore; invalid-setting no-write; shortcut rollback. Eight UI pages rendered in English, German and Russian. Russian audio screen visually inspected: three music actions and guide are visible without overlap. The harness log still says seven pages; it exports all eight.

These tests use a dummy installation, not live gameplay. No installed-game files were changed. Sky-only dimming, fixed time, native crosshair recoloring and complete radio/ambient mute are not implemented. No current antivirus vendor clearance or FPS improvement is claimed.

Revision 2026-11-13: build, quick-exit Keep/rebind/disable/invalid-key, four-file mouse flags, graphics overrides, apply/exact restore and multilingual UI rendering passed. New Russian control/graphics dialogs visually inspected. Contact mappings validated against the downloaded records; these are database associations, not a live server audit.

Preferences checks passed: restart, loading from a different version folder, custom resolution list, previous-file backup and corrupt-file non-overwrite. Tests used isolated workspace paths, not real user preferences.

Version 4.3: branding/version change only; rebuilt successfully. Functional validation above belongs to the unchanged implementation.
