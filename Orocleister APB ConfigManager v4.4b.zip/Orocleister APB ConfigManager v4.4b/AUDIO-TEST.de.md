# Audiotest — v4.4

Dies ist ein Vergleich der vorhandenen Musikoptionen, kein bestätigter neuer Radio-Fix. Der Button „Nur Themes“ wählt Musikplayer stumm, erstellte Songs aus und Kill-Themes hörbar. Erst Anwenden speichert die Auswahl.

1. Test A: Mit den bisherigen Einstellungen einen Freund im Auto denselben Song abspielen lassen. Abstand und Position merken; auch eine Kill-Theme anhören.
2. APB schließen. Im Manager „Nur Themes“ wählen und Anwenden drücken. Die Anwendung erstellt ihre normale Sicherung. APB neu starten.
3. Test B: Gleiches Auto, gleicher Song, gleiche Lautstärke und gleicher Abstand. Fremdes Autoradio, eigenes Radio, Kill-Theme, Schritte und Motorgeräusche getrennt prüfen.
4. Notieren: fremdes Radio hörbar/aus/leiser; Kill-Theme hörbar/aus; betroffener Song und Abstand. Für den Vergleich keine anderen Audiooptionen ändern.
5. Rückkehr: APB schließen und unter Tools die passende Sicherung wiederherstellen. Das stellt alle in dieser Sicherung enthaltenen Einstellungen zurück, nicht nur Audio.

