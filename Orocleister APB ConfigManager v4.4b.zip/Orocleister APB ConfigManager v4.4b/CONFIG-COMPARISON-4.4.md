# Supported behavior and limitations

Mission equipment icons use existing game artwork references. Mission assignments and role rewards are derived from public APBDB data; source records are included separately for maintenance. Game updates can change availability.

UI opacity uses OverlaySceneAlphaModulation. It affects the interface globally; text and icons may fade too. No independent left/right HUD or menu-background opacity is promised.

Music-player volume and created-song controls do not guarantee complete muting of nearby vehicle radio or building music. Protected sound banks are not deleted or modified.

No guaranteed FPS or hit-registration gain is claimed. Compare frame timing and input settings one at a time. No additional network-rate tweak is applied.

References: https://github.com/flawsv/apb/blob/main/README.md and https://www.gamersfirst.com/apb/news/2024/8/14/sard-faq
