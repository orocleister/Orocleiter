# Input and hit registration
Equal average FPS and ping do not establish equal frame pacing or network stability. There is no verified client-config switch that guarantees better server hit registration.

Compare in the same district, with the same weapon/mods, range and firing pattern. Record /fps during the issue (client frame time, server time, latency and packet loss). Use wired Ethernet for a comparison and pause background transfers. Test one change at a time.



Official sources:
https://support.gamersfirst.com/help/a/my-latency-is-really-high
https://forums.gamersfirst.com/topic/32833-apb-network-update/
