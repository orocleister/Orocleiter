﻿using System;using System.IO;using System.Linq;using System.Text;using System.Text.RegularExpressions;
class Checks44{
 static void A(bool b,string message){if(!b)throw new Exception(message);}
 static string T(byte[] bytes){using(var r=new StreamReader(new MemoryStream(bytes),true))return r.ReadToEnd();}
 static void Main(string[] args){
  var e=new Engine(Path.GetFullPath(args[0]));e.S.Set("Spielordner",Path.GetFullPath(args[1]));e.S.Set("EigeneLocalization",true);e.S.Set("KillMessageMode","Names");e.S.Set("MissionEquipmentIcons",true);e.S.Set("MissionColorMode","Colored");var on=e.Build();
  foreach(string ext in new[]{"GER","RUS"}){
   string prefix=@"APBGame\Localization\"+ext+"\\";
   string kills=T(on[prefix+"HUDCombatMessages."+ext]);
   var name=Regex.Match(kills,@"(?m)^HUDCombatMessages_Score_Combat_KillEnemy_Line0=([^\r\n]*)");A(Regex.Matches(name.Value,"<CharacterNameA>").Count==1,"kill name duplicated "+ext);
   A(T(on[prefix+"MissionTemplates."+ext]).Contains("<Images:APBMenus_Art_EquipmentIcons."),"equipment missing "+ext);
   string contacts=T(on[prefix+"Contacts."+ext]);A(contacts.Contains("[ITEM HOLD]")&&contacts.Contains("[DM]")&&contacts.Contains("[POINT HOLD]"),"mission kinds "+ext);
   string stages=T(on[prefix+"TaskObjectives."+ext]);A(stages.Contains(ext=="GER"?"<col:Red>TDM":"<col:Red>Командный бой"),"TDM color "+ext);A(stages.Contains(ext=="GER"?"<col:Purple>Item Hold":"<col:Purple>Удержание предмета"),"item color "+ext);
  }
  e.S.Set("MissionEquipmentIcons",false);e.S.Set("MissionColorMode","Plain");e.S.Set("KillMessageMode","Custom");e.S.Set("KillMessageText","sosal");var off=e.Build();
  foreach(string ext in new[]{"GER","RUS"}){
   string prefix=@"APBGame\Localization\"+ext+"\\";string kills=T(off[prefix+"HUDCombatMessages."+ext]);A(kills.Contains("HUDCombatMessages_Score_Combat_KillEnemy_Line0=sosal"),"custom phrase "+ext);
   A(!T(off[prefix+"MissionTemplates."+ext]).Contains("<Images:APBMenus_Art_EquipmentIcons."),"equipment off "+ext);
   A(!Regex.IsMatch(T(off[prefix+"TaskObjectives."+ext]),@"(?i)<col:"),"plain stages "+ext);
  }
  string fixture="HUDCombatMessages_Score_Combat_KillEnemy_Line0=<CharacterNameA>\r\nHUDCombatMessages_Score_Combat_KillEnemy_Line2=Kill\r\nScore=<Score>\r\nOther=<CharacterNameA>\r\n";
  string minimal=Engine.KillText(fixture,"Minimal","sosal");A(minimal.Contains("Score=<Score>")&&minimal.Contains("Other=<CharacterNameA>")&&!minimal.Contains("Line0=<CharacterNameA>"),"minimal changed unrelated tokens");
  e.S.Set("HudTransparencyMode","Custom");e.S.Set("HudOpacity","0.975");var hud=e.Build();A(T(hud[@"APBGame\Config\DefaultUI.ini"]).Contains("OverlaySceneAlphaModulation=0.975"),"custom HUD opacity");e.S.Set("HudOpacity","0.1");bool invalidAlpha=false;try{e.Build();}catch{invalidAlpha=true;}A(invalidAlpha,"unsafe opacity accepted");e.S.Set("HudOpacity","0.98");e.S.Set("KillMessageText","<CharacterNameA>");bool blocked=false;try{e.Build();}catch{blocked=true;}A(blocked,"custom markup injection accepted");
  Console.WriteLine("PASS 4.4 EN/RU icons on/off, mission types/colors, plain mode, single kill placeholder, custom/minimal score preservation and markup rejection.");
 }
}
