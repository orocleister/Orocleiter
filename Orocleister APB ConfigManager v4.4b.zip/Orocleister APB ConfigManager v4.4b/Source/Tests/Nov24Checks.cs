using System;using System.IO;using System.Text;using System.Text.RegularExpressions;
class Nov24Checks {
 static void A(bool ok,string message){if(!ok)throw new Exception(message);}
 static string T(byte[] b){using(var r=new StreamReader(new MemoryStream(b),true))return r.ReadToEnd();}
 static void Main(string[] args){
 string original="[Engine.PlayerInput]\r\n+Bindings=(Name=\"F9\",Command=\"open APBLoginLevel\")\r\n.Bindings=(Name=\"F9\",Command=\"open APBLoginLevel\")\r\n.Bindings=(Name=\"F8\",Command=\"Other\")\r\n-Bindings=(Name=\"F9\",Command=\"shot\")\r\n";
 string result=Engine.QuickExit(original,original,"F8");
 A(Regex.Matches(result,"open APBLoginLevel").Count==1,"duplicate quick exit");
 A(result.Contains("Name=\"\",Command=\"Other\"")&&result.Contains("-Bindings=(Name=\"F9\",Command=\"shot\")"),"binding conflict/removal entry");
 A(Engine.QuickExit(result,original,"F8")==result,"not idempotent");
 A(!Engine.QuickExit(original,original,"None").Contains("Name=\"F9\",Command=\"open"),"disabled key still present");
 A(ConfigWindow.WhisperCommand("Player-1","EU")=="/w Player-1@EU ","EU");
 A(ConfigWindow.WhisperCommand("Player_2","NA")=="/w Player_2@NA ","NA");
 bool rejected=false;try{ConfigWindow.WhisperCommand("Name\n/quit","EU");}catch(ArgumentException){rejected=true;}A(rejected,"chat injection");
 var e=new Engine(Path.GetFullPath(args[0]));e.S.Set("Spielordner",Path.GetFullPath(args[1]));e.S.Set("EigeneLocalization",true);e.S.Set("FunnyNames",true);e.S.Set("MissionEquipmentIcons",true);var files=e.Build();
 foreach(string ext in new[]{"GER","RUS"}){
 string prefix=@"APBGame\Localization\"+ext+"\\";
 A(T(files[prefix+"Contacts."+ext]).Contains("Contacts_Waterfront_E11_Title=Proga"),"Proga "+ext);
 string missions=T(files[prefix+"MissionTemplates."+ext]);var line=Regex.Match(missions,@"(?m)^MissionTemplates_AE_BEL0_Inv3_MissionTitle=(.*)$").Groups[1].Value;
 A(line.StartsWith("<ImageColour:")&&line.Contains("Icon_Equipment_BatteringRamLV0"),"leading equipment "+ext);
 }
 string ui=T(files[@"APBGame\Localization\RUS\APBUserInterface.RUS"]);A(!ui.Contains("<CurrentStage>/:<MaxStages>")&&ui.Contains("StageDescriptionPrefixHUD=<CurrentStage>/<MaxStages>"),"RU stage");
 e.S.Set("FunnyNames",false);A(!T(e.Build()[@"APBGame\Localization\GER\Contacts.GER"]).Contains("=Proga"),"original name toggle");
 e.S.Set("StreamerNickname","My-Name_42");var custom=e.Build();foreach(string ext in new[]{"GER","RUS"})A(T(custom[@"APBGame\Localization\"+ext+"\\APBUserInterface."+ext]).Contains("CharacterNameRemoved=My-Name_42"),"custom streamer "+ext);
 foreach(string invalid in new[]{"","   ","Name\nOther=value","<Color:Red>",new string('a',33)}){bool blocked=false;try{Engine.ValidateStreamerNickname(invalid);}catch{blocked=true;}A(blocked,"invalid streamer name accepted");}
 Console.WriteLine("PASS custom streamer EN/RU and validation. PASS Nov24: dotted bindings, idempotence, EU/NA commands, invalid names, Proga toggle, leading equipment EN/RU, RU counters.");
 }
}
