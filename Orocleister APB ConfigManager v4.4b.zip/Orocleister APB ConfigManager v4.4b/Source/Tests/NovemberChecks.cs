using System;using System.IO;using System.Text;using System.Linq;using System.Text.RegularExpressions;
class NovemberChecks {
 static void A(bool ok,string message){if(!ok)throw new Exception(message);}
 static string Text(byte[] data){using(var r=new StreamReader(new MemoryStream(data),true))return r.ReadToEnd();}
 static void Main(string[] args){
  var e=new Engine(Path.GetFullPath(args[0]));e.S.Set("Spielordner",Path.GetFullPath(args[1]));e.S.Set("EigeneLocalization",true);e.S.Set("GameTextLanguage","English");e.S.Set("TextColorPreset","Standard");
  e.S.Set("FunnyNames",true);var funny=e.Build();
  e.S.Set("FunnyNames",false);var normal=e.Build();
  string contacts=@"APBGame\Localization\GER\Contacts.GER";
  A(Text(funny[contacts]).Contains("Contacts_Financial_E11_Title=hypersport"),"funny contact missing");
  A(Text(normal[contacts]).Contains("Contacts_Financial_E11_Title=Devil Dog"),"normal contact missing");
  string items=@"APBGame\Localization\GER\InventoryItemTypes.GER";
  A(Text(funny[items]).Contains("MatthewScoutina"),"funny weapon missing");A(!Text(normal[items]).Contains("MatthewScoutina"),"normal weapon alias survived");
  foreach(string ext in new[]{"GER","RUS"}){
   string ui=@"APBGame\Localization\"+ext+@"\APBUserInterface."+ext;
   A(Text(funny[ui]).Contains("CharacterNameRemoved=Tiggs"),"Tiggs missing");
  }
  string hud=Text(funny[@"APBGame\Localization\RUS\HUDMessages.RUS"]);
  A(!hud.Contains("<MissionStage><MissionStage>"),"duplicate phase");A(!hud.Contains("<CharacterNameA><CharacterNameA>"),"duplicate character");
  A(hud.Contains("Этап завершён! Теперь этап <Stage_Cur>."),"stage text missing");
  Console.WriteLine("PASS: names switch, alias preservation, Tiggs in both languages, Russian stage/name regression.");
 }
}
