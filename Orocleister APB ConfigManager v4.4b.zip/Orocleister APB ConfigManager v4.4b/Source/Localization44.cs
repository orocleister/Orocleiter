﻿using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Collections.Generic;

public sealed partial class Engine {
 public static void ValidateStreamerNickname(string name){if(name==null||name.Length>32||!Regex.IsMatch(name,@"^[\p{L}\p{N}_. -]+$")||name.Trim().Length==0)throw new Exception("StreamerNicknameInvalid");}

 public static string KillText(string text,string mode,string phrase){
  if(!new[]{"Names","Minimal","Custom"}.Contains(mode))throw new Exception("Invalid kill message mode");
  if(phrase.Length>60||phrase.Any(c=>char.IsControl(c)||c=='<'||c=='>'||c=='='))throw new Exception("Kill phrase: maximum 60 characters; no markup or line breaks.");
  string key="HUDCombatMessages_Score_Combat_KillEnemy_";
  text=V(text,key+"Line0",mode=="Minimal"?" ":mode=="Custom"?phrase:"<CharacterNameA>");
  // The game supplies the numeric score separately. Never hard-code 100 points.
  return V(text,key+"Line2"," ");
 }
 byte[] LocalizationOptions(string path,byte[] bytes){
  string text;using(var reader=new StreamReader(new MemoryStream(bytes),true))text=reader.ReadToEnd();
  string name=Path.GetFileNameWithoutExtension(path);
  if(name=="APBUserInterface")text=V(text,"CharacterNameRemoved",S.S("StreamerNickname").Trim());
  if(name=="HUDCombatMessages")text=KillText(text,S.S("KillMessageMode"),S.S("KillMessageText"));
  if(name=="MissionTemplates"){
   var icons=Settings.Json.Deserialize<Dictionary<string,string>>(File.ReadAllText(Path.Combine(Root,"EquipmentIcons.json")));
   text=Regex.Replace(text,@"(?m)^(?<key>[^=\r\n]+)=(?<value>[^\r\n]*)",m=>{
    string key=m.Groups["key"].Value,val=m.Groups["value"].Value,icon;
    if(key.EndsWith("_MissionTitle")&&S.B("MissionEquipmentIcons")&&icons.TryGetValue(key,out icon))val="<ImageColour:R=0.8 G=0.8 B=0.8 A=1>"+icon+" "+val;
    if(S.S("MissionColorMode")=="Plain")val=Regex.Replace(val,@"(?i)<(?:Color:[^>]*|col:[^>]*|/col)>","");
    return key+"="+val;
   });
  }
  if(name=="TaskObjectives"){
   if(S.S("MissionColorMode")=="Plain")text=Regex.Replace(text,@"(?i)<(?:Color:[^>]*|col:[^>]*|/col)>","");
   else text=Regex.Replace(text,@"(?i)<col:[^>]*>(?<body>[^<]*?(?:Item Hold|Удержание предмета|\bDM\b|\bTDM\b|Командный бой|\bБой\b)[^<]*)</col>",m=>"<col:"+(Regex.IsMatch(m.Groups["body"].Value,"Item Hold|Удержание предмета",RegexOptions.IgnoreCase)?"Purple":"Red")+">"+m.Groups["body"].Value+"</col>");
  }
  if(name=="Contacts"&&S.S("MissionColorMode")=="Plain")text=Regex.Replace(text,@"<Color:R=[^>]+>(\[[A-Z ]+\])<Color:/>","$1");
  return Encoding.Unicode.GetPreamble().Concat(Encoding.Unicode.GetBytes(text)).ToArray();
 }
}
