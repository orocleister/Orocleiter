# Orocleister APB ConfigManager v4.4b

ZIP vollständig entpacken und APB-Config.exe starten. Das Fenster lässt sich vergrößern und maximieren.

## Bereiche
- Grafik: Bildschirm, FPS-Limit, Orocleister Config, Low, Balanced und Custom. Darstellung und Effekte sind links gruppiert.
- Input: Mausglättung, Beschleunigung und klassischer Mousefix.
- Texte / HUD: Sprache & Missionen, Kill-Meldung, HUD & Farben, Tasten & Sprint.
- Tasten & Sprint: Schnell-Aussteigen (Standard F9), Auto-Ready sowie Hinweise zu Ducken/Lehnen. Die tatsächlichen Bewegungsbindungen werden in APB unter Optionen > Steuerung zugewiesen.
- Start: Spielpfad und Startoptionen.
- Tools: Sicherungen, Reparaturhinweise, Profile und Diagnose.

## Anwenden
APB und Launcher schließen. Optionen wählen, Anwenden drücken, APB neu starten. Play APB startet mit den bereits installierten Einstellungen; es wendet ausstehende Änderungen nicht automatisch an. Update Game öffnet den offiziellen Updater.

Einstellungen werden beim Schließen gespeichert. Vor Änderungen an Spieldateien wird eine Sicherung erstellt. Wiederherstellen setzt die Dateien aus der Sicherung zurück.

## HUD-Transparenz
Texte / HUD > HUD & Farben > Eigene Transparenz. Kleinere Deckkraft ist transparenter. Mit 0.98 beginnen; bei schlechter Lesbarkeit auf den bisherigen Config-Stil zurückstellen. Der Wert wirkt global, auch auf Text/Symbole. Inventar und Tab müssen im Spiel geprüft werden.

## Grenzen
Fremdes Autoradio und Gebäudemusik werden noch nicht zuverlässig vollständig stummgeschaltet. Kein garantierter FPS-/Hitreg-Gewinn. Weitere Details stehen in RELEASE-NOTES.md und CONFIG-COMPARISON-4.4.md.
