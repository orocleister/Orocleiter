# Streamer alias experiment — separate from the normal v4.1b release

Only one additional localization value per language is changed: [Generic] UnknownOtherCharacter=Noary in APBUserInterface. CharacterNameRemoved=Dizamorphin remains. No generated name list or friend/team distinction was found. This may affect only a fallback label, may affect multiple player categories, or may have no effect on the generated names shown in screenshots. It is not a confirmed streamer-name fix.

## Проверка
1. Закройте APB. Распакуйте этот вариант отдельно от обычной v4.1b.
2. Выберите свой путь к игре и те же настройки, которыми уже пользуетесь. «Применить» применяет весь выбранный профиль, не только этот тест; проверьте предварительный просмотр изменений. Сохраняется обычная резервная копия.
3. Запустите APB. В настройках игры включите скрытие имён других игроков, друзей и группы.
4. Сравните имена в списке друзей, группе, над игроками и в таблице миссии. Проверьте также после выключения скрытия. Нужны скриншоты обоих состояний.
5. Если остаются Lyra Thorne и подобные имена, этот ключ не управляет ими. Если Noary появляется также у друзей, ключ общий и не различает стороны.
6. Для отката закройте игру и восстановите соответствующую резервную копию через Tools в этом экземпляре программы. Откат восстанавливает все файлы этой операции.

Это только проверка общего placeholder. Нельзя считать, что все враги уже Noary, а друзья и команда Dizamorphin. Установленные файлы игры при создании архива не менялись.
