﻿# v4.1b — 17 October 2026

- Devil Dog is now hypersport in both text packs.
- Updated application title and version metadata.
- Audio unchanged: complete suppression of other players' car radios remains unresolved. AppleSlice protected audio-file replacements are not included.

# Orocleister APB ConfigManager v4.0

- Eight clearly separated pages with navigation icons.
- Advanced contains rendering, clothing/vehicle editors, streaming and cache.
- Tools provides direct profile import/export, restore, APB Repair, hardware, client checks and guides.
- APB Repair opens the official launcher; select Repair there.
- Short explanations, hover details, restored Matt Scott header.
- Your config, Low, Balanced and Custom remain available.
- Independent input controls and in-game Hold/Toggle action definitions retained.

Validation: compiled successfully; eight pages rendered in EN/DE/RU; dummy-installation Apply/restore, shortcut rollback, profile validation, corrupt-backup rejection, interrupted recovery, client-change detection and independent input checks passed. Live gameplay, FPS improvements, complete car-radio suppression and equipment image tags are not verified. Read README for limitations.

## Client 1.33.0.859751 compatibility update — 15 October 2026
Preserves installed voice gain/device defaults and voice-talker display settings. Missing localization entries are supplemented from the repaired official client; existing custom descriptions and contact names remain. EULA files are no longer overwritten. Launcher binaries are not part of the output plan. Verified on generated output and a dummy installation, not a live gameplay/FPS test.
