# Weapon colors

Assault rifles: blue. SMG: red. Marksman / semi-automatic rifles: yellow. Shotguns: light blue. Sniper rifles: green. LMG: white. Explosives and grenades: violet. Names and matching category labels use the same color. Classification follows the cached APBDB categories. Existing item aliases and statistics are preserved. Other categories are unchanged.
