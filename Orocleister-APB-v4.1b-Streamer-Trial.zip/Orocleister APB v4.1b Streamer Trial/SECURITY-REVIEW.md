# Security review — 17 October 2026

The supplied VirusTotal screenshot reports 5/67 detections for archive SHA-256 4b8280cc9b729d56cbfc6d7fdf56916c42411f64d3952947d7f4f28d5dc68d4e. This matches our previous release checksum. Detections shown: Bkav Pro, Elastic, Malwarebytes, MaxSecure and TrendMicro-HouseCall. They have not been cleared by those vendors.

The current executable was rebuilt for the classic mouse-fix button and Basic-page Double Buffering control. SHA-256: c374e58dd1465c088ab7bea0719b282175d7b13094075a10650ca40a3a7bae1a. The previously documented Defender scan and VirusTotal report apply to earlier artifacts, not this rebuilt executable. No current multi-vendor clearance is claimed.

Source review of process launches, network calls and native calls: the program creates/reads Windows shortcuts with WScript.Shell, starts APB/the official launcher, opens guides/links and fetches the public GamersFirst population page. Native APIs support window styling, display-mode enumeration and hardware reporting. The shipped build script compiles C# directly with Microsoft's .NET compiler; it does not pack or obfuscate the executable. The EXE is unsigned. No reason for each vendor's detection has been established by this review, and no full independent binary audit was performed.

No antivirus exclusion, protection bypass or renaming/repacking scheme to evade detection is included. Report persistent suspected false positives to the detecting vendors with the exact file hash and scan URL: https://docs.virustotal.com/docs/false-positive-contacts . Nothing has been submitted on your behalf.
