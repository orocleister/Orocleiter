using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
public static class ApbDisplayModes {
 [DllImport("user32.dll", CharSet=CharSet.Unicode, EntryPoint="EnumDisplaySettingsW")]
 static extern bool EnumDisplaySettings(string device, int mode, IntPtr data);
 public static string[] Read() {
  var modes=new HashSet<string>();
  IntPtr data=Marshal.AllocHGlobal(220);
  try {
   for(int i=0;i<4096;i++) {
    Marshal.Copy(new byte[220],0,data,220);Marshal.WriteInt16(data,68,220);
    if(!EnumDisplaySettings(null,i,data))break;
    int w=Marshal.ReadInt32(data,172),h=Marshal.ReadInt32(data,176);
    if(w>=320 && h>=240)modes.Add(w+"x"+h);
   }
  } finally {Marshal.FreeHGlobal(data);}
  var result=new List<string>(modes);result.Sort();return result.ToArray();
 }
}
