using System; using System.Drawing; using System.Drawing.Drawing2D; using System.Windows.Forms;
public class EffectBadge:Control {
 public string Kind {get;set;}
 public EffectBadge(){SetStyle(ControlStyles.SupportsTransparentBackColor|ControlStyles.UserPaint|ControlStyles.OptimizedDoubleBuffer,true);BackColor=Color.Transparent;Size=new Size(30,30);}
 protected override void OnPaint(PaintEventArgs e){
  var g=e.Graphics;g.SmoothingMode=SmoothingMode.AntiAlias;
  using(var pen=new Pen(ForeColor,2))using(var brush=new SolidBrush(ForeColor)){
   if(Kind=="fire" || Kind=="blood"){
    using(var p=new GraphicsPath()){p.AddBezier(15,2,16,10,27,12,25,21);p.AddBezier(25,21,21,32,5,29,5,19);p.AddBezier(5,19,4,13,13,7,15,2);g.DrawPath(pen,p);if(Kind=="fire")g.DrawBezier(pen,15,13,8,23,17,29,20,20);}
   }else if(Kind=="smoke") {g.DrawArc(pen,2,15,15,10,60,230);g.DrawArc(pen,12,11,15,13,200,230);g.DrawBezier(pen,9,14,18,7,3,9,14,2);g.DrawBezier(pen,21,11,27,5,17,5,23,1);}
   else if(Kind=="trail"){g.DrawBezier(pen,2,27,7,9,18,4,26,7);g.DrawLine(pen,19,2,27,7);g.DrawLine(pen,27,7,22,14);g.FillEllipse(brush,1,23,5,5);}
   else if(Kind=="speed"){g.DrawArc(pen,3,4,24,24,180,180);g.DrawLine(pen,15,18,24,8);g.FillEllipse(brush,12,15,6,6);}
   else {g.DrawPolygon(pen,new Point[]{new Point(15,3),new Point(28,26),new Point(2,26)});g.DrawLine(pen,15,10,15,18);g.FillEllipse(brush,14,21,2,2);}
  }
 }
}
