# Команды и клавиши

Открой чат, введи команду со слешем и нажми Enter. Ниже команды именно нашей английской локализации; справка не добавляет новые команды. Доступность определяет APB. Служебные GM-команды исключены.

- `/fps` — показать/скрыть данные производительности. Лимит FPS не меняет.
- `/pop` — запросить онлайн мира/района у игры; это не счётчик сайта в программе.
- `/a` — запрос выхода из миссии. Игра может отклонить его; принудительный выход не включается.
- `/q` — полностью закрыть игру. F9 в нашем конфиге возвращает на экран входа.
- **O** — настройки, затем Video: выбрать доступное игре разрешение и нажать Apply. При своей раскладке клавиша может отличаться.
- **P** — свой музыкальный проигрыватель. Его громкость не гарантирует отключения чужого радио.

Английские названия и описания команд ниже сохранены из нашей локализации. В нижней таблице — начальные клавиши пакета; раскладка аккаунта может их переопределять. Свободные действия назначаются в настройках управления APB. MM — Marksmanship Mode, режим прицеливания. Эта справка не меняет игровые надписи.

| Command | Example | Purpose |
| --- | --- | --- |
| /a | /a | Requests abandoning the mission. The current game/server can reject this; it does not force an exit. |
| /afk | /afk or /afk message | Changes your chat status to be "Away from Keyboard."  You may provide an optional argument to this command to provide a message as to why you're away from the keyboard. |
| /available | /available | "Changes your chat status to be "Available."" |
| /cancelunstick | /cancelunstick | Allows you to cancel an unstick request before you are respawned. |
| /clanaccept | /clanaccept | Allows you to accept a pending clan invite. |
| /clandecline | /clandecline | Allows you to decline a pending clan invite. |
| /claninvite | /claninvite playername | Allows you to invite another player to your clan. |
| /clanleave | /clanleave | Allows you to leave your clan |
| /clanremove | /clanremove playername | Allows you to remove a player from your clan. |
| /dnd | /dnd or /dnd message | Changes your chat status to be "Do Not Disturb."  You may provide an optional argument to this command to provide a message as to why you don't wish to be disturbed. |
| /fps | /fps | Toggle framerate display. |
| /friendaccept | /friendaccept or /friendaccept playername | Allows you to accept a pending friend request. |
| /friendadd | /friendadd playername | Allows you to add a player as a friend. |
| /frienddecline | /frienddecline or /frienddecline playername | Allows you to decline a pending friend request. |
| /friendremove | /friendremove playername | Allows you to remove a player from your friends list. |
| /gimd | /gimd, /gimd true or /gimd false | This command allows you to set the default group invitation mode when you create a new group to be either only group leader can invite players (false) or all players can invite players to the group (true).; If you enter the command without 'true' or 'false', the system will display the current value for you. |
| /groupaccept | /groupaccept | Allows you to accept a pending group invite. |
| /groupdecline | /groupdecline | Allows you to decline a pending group invite. |
| /groupinfo | /groupinfo playername | Provides information about another player's public group. |
| /groupinvite | /groupinvite playername | If you are the current group leader, this allows you to invite another player to your group. |
| /groupinvitemode | /groupinvitemode, /groupinvitemode true or /groupinvitemode false | This command allows you to set the group invitation mode of your current group to be either only group leader can invite players (false) or all players can invite players to the group (true).; If you enter the command without 'true' or 'false', the system will display the current value for you. |
| /groupjoin | /groupjoin groupname | Join a specified public group. |
| /groupleave | /groupleave | Leaves your current group. |
| /grouplist | /grouplist | Lists all public groups in this district instance. |
| /grouppublicmode | /grouppublicmode, /grouppublicmode true or /grouppublicmode false | This command allows you to change the membership mode of your current group between being public (true) and private (false).; If you enter the command without 'true' or 'false', the system will display the current value for you. |
| /grouppublicmodedefault | /grouppublicmodedefault, /grouppublicmodedefault true or /grouppublicmodedefault false | This command allows you to set the default membership mode when you create a new group to be either public (true) or private (false).; If you enter the command without 'true' or 'false', the system will display the current value for you. |
| /groupremove | /groupremove playername | If you are the group leader, this allows you to remove a player from your group. |
| /help | /help | Displays a list of the available console commands. |
| /ignore | /ignore playername | Lets you ignore a particular player. |
| /lfg | /lfg, /lfg true or /lfg false | Sets you to 'looking for group'. |
| /logout | /logout | Logs out of the game. |
| /played | /played | Displays the total accumulated play time for your current character. |
| /pop | /pop | Displays how many people are in the game world and in the local district. |
| /q | /q | Lets you exit the game completely. |
| /report | /report playername | Reports a player for inappropriate behavior. |
| /savechatlog | /savechatlog | Saves a log of all the chat that has occurred since starting APB. |
| /shownames | /shownames | Toggles whether or not player's names are displayed above characters in the game. |
| /statsmark |  |  |
| /time | /time | Displays the current in-game and server times. |
| /toggleprofanity | /toggleprofanity | Toggles the ability to see profanity in the chat log or not. |
| /toggletimestamp | /toggletimestamp | Toggles the ability to see timestamps in the chat log or not. |
| /tradeaccept | /tradeaccept | Allows you to accept a pending trade request. |
| /tradedecline | /tradedecline | Allows you to decline a pending trade request. |
| /transfer | /transfer playername | If you are the group leader this allows you to relinquish the group's command to a named group member. |
| /unignore | /unignore playername | Removes a particular player from your ignore list. |
| /unstick | /unstick | If you get stuck somewhere, you can use this command to be respawned. |
| /who | /who | Displays a list of characters that are in the current district instance. |

## Default keybinds

| Key / input alias | Action |
| --- | --- |
| F4 + Alt | quit |
| W | MoveForward |
| S | MoveBackward |
| A | StrafeLeft |
| D | StrafeRight |
| SpaceBar | Jump |
| LeanLeft | LeanLeftKeyDown |
| HoldLeanLeft | LeanLeftKeyDown  /  OnRelease LeanRightKeyDown |
| LeanRight | LeanRightKeyDown |
| HoldLeanRight | LeanRightKeyDown  /  OnRelease LeanLeftKeyDown |
| V | SwitchCameraSide |
| SwitchCameraSide | ToggleSwitchCameraSide |
| G | ThrowGrenade  /  OnRelease StopFire |
| RightMouseButton | HoldMarksmanShip |
| LeftMouseButton | Fire |
| R | ReloadWeapon |
| Four | ToggleConsumable |
| Five | ToggleAmmoCarrierMod |
| LeftAlt | Witness |
| Equals | CameraZoomIn |
| Underscore | CameraZoomOut |
| Zero | ToggleCameraPositions |
| VehicleForward | Axis aVehicleThrottle Speed=1.0 |
| W | VehicleForward |
| VehicleBackward | Axis aVehicleThrottle Speed=-1.0 |
| S | VehicleBackward |
| VehicleLeft | Axis aVehicleTurn Speed=-1.0 |
| A | VehicleLeft |
| VehicleRight | Axis aVehicleTurn Speed=+1.0 |
| D | VehicleRight |
| Handbrake | Axis aVehicleUp Speed=+1.0 AbsoluteAxis=100 |
| SpaceBar | Handbrake |
| LeftMouseButton | StartVehicleHorn  /  OnRelease StopVehicleHorn |
| RightMouseButton | ToggleSiren |
| ToggleSiren | ToggleSpecialLights |
| HoldSiren | ToggleSpecialLights  /  OnRelease ToggleSpecialLights |
| Q | IndicatorLeft |
| E | IndicatorRight |
| LeftShift | ToggleNitroMod |
| DoCSAKeyPressed | CSAKeyPressed Primary /  OnRelease CSAKeyReleased Primary |
| F | DoCSAKeyPressed |
| DoTertiaryCSAKeyPressed | CSAKeyPressed Tertiary /  OnRelease CSAKeyReleased Tertiary |
| period | DoTertiaryCSAKeyPressed |
| DoInventoryCSAKeyPressed | CSAKeyPressed Inventory /  OnRelease CSAKeyReleased Inventory |
| I | DoInventoryCSAKeyPressed |
| DoLockerCSAKeyPressed | CSAKeyPressed Locker /  OnRelease CSAKeyReleased Locker |
| L | DoLockerCSAKeyPressed |
| X | CSAKeyPressed DropTaskItem /  OnRelease CSAKeyReleased DropTaskItem |
| K | ToggleReadyForMissions |
| U | ToggleSocialUI |
| Up | SelectUp |
| Down | SelectDown |
| Enter | OpenQuickChat |
| Backspace | OpenQuickReply |
| Home | OpenFullChat |
| Slash | OpenSlashQuickChat |
| Escape | CloseEditorViewport  /  onrelease ShowMenu |
| Escape | OpenMainMenu  /  SkipGameflowStateSwitch |
| comma | ToggleTeamMgmtUI |
| F6 | ToggleProvingGroundsChallengesUI |
| F7 | ProvingGroundsSkipActivity |
| F10 | OpenConsoleCommands |
| F11 | OpenEmoteCommands |
| J | TogglePlayerInfoUI |
| P | ToggleMusicPlaybackUI |
| Y | InGameQuestionAccepted |
| N | InGameQuestionDeclined |
| M | ToggleDistrictMap |
| Tab | ToggleScoreboardUI |
| F12 | ToggleHUD |
| B | ToggleBackupRequest |
| PageUp | ExecChatLogAction MAINCHATLOG_SCROLLUP |
| PageDown | ExecChatLogAction MAINCHATLOG_SCROLLDOWN |
| O | ToggleOptionsUI |
| T | ToggleTutorialUI |
| F9 | open APBLoginLevel |
| NumPadOne | Button m_bNumPadOne |
| NumPadTwo | Button m_bNumPadTwo |
| NumPadThree | Button m_bNumPadThree |
| NumPadFour | Button m_bNumPadFour |
| NumPadFive | Button m_bNumPadFive |
| NumPadSix | Button m_bNumPadSix |
| NumPadSeven | Button m_bNumPadSeven |
| NumPadEight | Button m_bNumPadEight |
| NumPadNine | Button m_bNumPadNine |
| Add | Button m_bAdd |
| Subtract | Button m_bSubtract |
| Delete | Unspectate |
| Up | MoveForward |
| Down | MoveBackward |
| XboxTypeS_DPad_Up | MoveForward |
| XboxTypeS_DPad_Down | MoveBackward |
| BackSpace | Jump |
| XboxTypeS_B | Jump |
| W | MoveForward |
| S | MoveBackward |
| A | StrafeLeft |
| D | StrafeRight |
| SpaceBar | Jump |
| LeftControl | Jump |
| LeftControl | DoDuck |
| LeftControl | Jump |
| C | DoDuck |
| LeftShift | Walking |
| LeftMouseButton | Fire |
| U | Suicide |
| F7 | set D3DRenderDevice bUsePostProcessEffects False |
| F8 | set D3DRenderDevice bUsePostProcessEffects True |
| F9 | shot |
| F6 | ToggleMarketplaceUI |
| F7 | OpenMusicEditor |
| F10 | dumpdynamicshadowstats |
| F12 | FreezeRendering |
| F5 | quicksave |
| F6 | quickload |
| Delete | Camera Default |
| End | Camera FirstPerson |
| PageDown | Camera ThirdPerson |
| PageUp | Camera Fixed |
| Home | Camera FixedTracking |
| Insert | Camera FreeCam |
| Delete | Camera Default |
| Insert | Camera FreeCam |
| H | Shout |
| F8 | OpenOldCharacterCustomisationStudio |
| F9 | OpenOldCharacterCustomisationStudio |
| F11 | OpenOldVehicleCustomisationStudio |
| Up | DebugMapCentreDecrementX |
| Down | DebugMapCentreIncrementX |
| Left | DebugMapCentreIncrementY |
| Right | DebugMapCentreDecrementY |
| Add | DebugMapSizeIncrement |
| Subtract | DebugMapSizeDecrement |
| F9 | DebugOpenCharacterCustomisation |
| F11 | DebugOpenVehicleCustomisation |
| F10 | DebugOpenSymbolEditor |
| F8 | DebugOpenClothingCustomisation |
| , | animationtick logical |
| . | animationtick on |
| F5 | set D3DRenderDevice bUsePostProcessEffects False |
| F5 + Alt | set D3DRenderDevice bUsePostProcessEffects True |
| Six | TestHitReaction |
| XboxTypeS_Back | togglephysicsmode |
| AltFire | StartAltFire  /  OnRelease StopAltFire |
| AltFire | CycleFireMode |
| XboxTypeS_RightY | Axis aLookup Speed=1.0 DeadZone=0.2 |
| XboxTypeS_A | Jump |
| XboxTypeS_X | Duck |
| XboxTypeS_Y | DoCSAKeyPressed |
| XboxTypeS_B | Fire |
| XboxTypeS_LeftShoulder | Sprint |
| XboxTypeS_RightShoulder | DoToggleMarksmanship |
| XboxTypeS_LeftTrigger | Button m_bNumPadOne |
| XboxTypeS_RightTrigger | Button m_bNumPadThree |
| XboxTypeS_RightThumbstick | ReloadWeapon |
| XboxTypeS_LeftTrigger_Axis | Axis m_fLeftTrigger |
| XboxTypeS_RightTrigger_Axis | Axis m_fRightTrigger |
| Up | PreviousGroupItem |
| Down | NextGroupItem |
| Enter | ToggleQuickChat |
| PageUp | PreviousGroup |
| PageDown | NextGroup |
| Backspace | ToggleUI |
| C | NextCameraView |
| Add | NextMenu |
| Subtract | PreviousMenu |
| Zero | SetPreset 0 |
| One | SetPreset 1 |
| Two | SetPreset 2 |
| Three | SetPreset 3 |
| Four | SetPreset 4 |
| Five | SetPreset 5 |
| Six | SetPreset 6 |
| Seven | SetPreset 7 |
| Eight | SetPreset 8 |
| Nine | SetPreset 9 |
