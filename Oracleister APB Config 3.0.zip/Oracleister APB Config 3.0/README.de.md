﻿# Oracleister APB Config 3.0

## Version 3.0 — Windows-App

Den vollständigen Ordner entpacken und **APB-Config.exe** doppelklicken. Assets, Profile, Optional, Languages.json und Einstellungen.json müssen daneben bleiben. Die App ist jetzt direkt in C# / .NET Framework umgesetzt. Sie startet und lädt kein PowerShell und benötigt kein PowerShell 7. Verwendet wird .NET Framework 4.8, das in aktuellen Windows-10/11-Systemen enthalten ist. Kein Installer und keine Administratoranforderung.

**Übernehmen** installiert die gewählten Einstellungen und erstellt ein Backup. **Update Game** öffnet nur den offiziellen Updater, ohne Einstellungen anzuwenden oder einen Spielstart anzufordern. Das Eigenverhalten des Updaters kontrolliert die App nicht. **Play APB** aktualisiert und öffnet die direkte Verknüpfung, ohne ausstehende Grafik-/Audioänderungen anzuwenden; danach schließt die Config. Nach Spielupdates gegebenenfalls die Einstellungen erneut anwenden.

**Grafik:** Normal behält klare Charaktere, Fahrzeuge und Symbole. Max Low verwendet die bisherigen niedrigen Modell-/Texturgrenzen und deaktiviert Schatten und Nachbearbeitung ausdrücklich in den mitgelieferten Qualitätsblöcken. Eigene Grafik bietet einen gespeicherten Slot für Texturgrenze, einfache Modelle, dynamische Schatten und Weltdetails. Ein Profilwechsel behält die eigenen Werte. Übernehmen und APB neu starten. Bildpuffer, UI-Texturen und Rendermaßstab bleiben erhalten, damit der fehlerhafte Extrem-Boost nicht wieder eingeführt wird.

**Farben:** Standard, Blau/Rot, Grün/Rot, Schwarz/Pink, Blau/Orange und Gelb/Violett. Erste Farbe Team, zweite Gegner. Blau/Orange ist eine Rot-Grün-Alternative, kein universeller Farbblindmodus. Unterstützte Kampf-/Scoreboard-Texte ändern sich, Namen über Spielern nicht. Die letzten englischen HUD-, Fraktions- und Kontaktnamen sind enthalten. Missions- und Gegenstandsbeschreibungen bleiben vollständig erhalten.

**Sicherheit und Transparenz:** Das ist eine neue EXE, nicht der bisherige PowerShell-Starter. Quellcode und build.cmd für Entwickler liegen in Source. Zum Benutzen genügt APB-Config.exe. Keine Verschleierung, kein EXE-Packer, keine Änderung von Sicherheitsrichtlinien und keine Virenschutz-Ausnahme. Die EXE ist unsigniert und nicht unabhängig als schadsoftwarefrei bestätigt. Windows oder Virenscanner können weiterhin warnen. Umbau und SHA-256-Prüfsummen sind kein Sicherheitszertifikat. Tests und Grenzen stehen in RELEASE-NOTES.md.

Der Community-Bereich ruft bei geöffnetem Fenster öffentliche Spielerzahlen von gamersfirst.com ab. Browserlinks öffnen erst beim Anklicken. Keine neue Telemetrie.


1200×1800 (Hochformat) und 1800×1200 (Querformat) sind feste Presets und Einträge für das Spielmenü. Bei geschlossenem APB anwenden und einmal neu starten. Wird eine Größe im Vollbild abgelehnt, Fenster testen; die Treiberunterstützung bleibt entscheidend.

Breites Preset: 1800×1200 (1200×1800 ist Hochformat). Social nutzt 2700 Sekunden / 45 Minuten für die regelmäßige Objektbereinigung; NoSocial lässt sie deaktiviert. Speicherbedingte Bereinigung kann früher erfolgen. Es werden keine Shader- oder Festplatten-Caches gelöscht. Längere Intervalle können Speicherverbrauch und spätere Pausen erhöhen. Gegenstandswerte sind weiterhin als Basiswerte gekennzeichnet; Mods können sie verändern.

**Fahrzeug- und neue Waffenwerte.** APBDB-Basiswerte für 565 Fahrzeugvarianten und 15 Waffen ohne Werteblock ergänzt, darunter Joker M9S Pulse Check und Joker C9S Prototype. Bisherige Beschreibungen bleiben darunter erhalten. Werte gelten vor Modifikationen; Mods, Ladung und Schäden beeinflussen das Ergebnis. Fahrzeug-HP entsprechen keiner festen Kugelanzahl. Beschleunigungszeiten fehlen in der Quelle. Ideale TTK gilt gegen 1000 HP bei vollem Schaden ohne Fehlschüsse; keine vereinfachte TTK für Schrot oder Salven. Datenstand: 27. September 2026. Quellen je Gegenstand: ITEM-STATS-SOURCES.json. Fehlende Werteblöcke wurden ergänzt; ältere Waffen wurden nicht vollständig auf Balanceänderungen geprüft.

## Einstellungsupdate — 26. September
Granatenrauch / Flugspuren: kein eigener Ein-/Aus-Schalter. Das frühere Häkchen änderte nur gemeinsame VFX-Texturen. Little Orbit untersagt vollständige Rauchentfernung; Effektdateien werden nicht entfernt.


**Auflösung.** Anwenden speichert die gewählte Größe und ergänzt 640×480, 800×600, 960×540, 1024×768, 1152×864, HD, Full HD und gespeicherte eigene Größen über ExtraResolution im APB-Videomenü. Der alte Mindestfilter 1024×720 wird in DefaultEngine und im vorhandenen APBEngine-Cache gesenkt. APB danach einmal neu starten; anschließend im Spiel beliebig oft über O → Video → Auflösung → Anwenden wechseln. Vorhandene Zusatzgrößen bleiben erhalten. Nicht unterstützte Vollbildgrößen können abgelehnt werden; dafür den Fenstermodus verwenden. Rahmenlos folgt dem Desktop. Aktuelle beibehalten aktualisiert die Liste, ohne die aktuelle Größe zu ändern. Nach Spielreparatur oder Update gegebenenfalls erneut anwenden.

**Farben.** Statt einfarbig: Team/Gegner blau/rot, grün/rot oder schwarz/pink. Killer, Opfer und Helfer erhalten ihre jeweilige Seitenfarbe in unterstützten HUD-Meldungen. Text, Symbole und Missionen bleiben unverändert. Standard stellt die Originaldateien wieder her. Schwarz ist auf dunklem Grund schlechter lesbar.

**Mouse Fix.** Ein deaktiviert Glättung in Engine-, Standard-, Konto- und vorhandenen Charakterdateien einschließlich UserConfig.ini. Bestehende Beschleunigungsflags werden deaktiviert. Aus aktiviert Glättung. Legacy bleibt mit Achsentempo 2.0; normale Modi verwenden 1.0. Empfindlichkeit, Ziel-Empfindlichkeit, DPI und Windows-Einstellungen bleiben unverändert. Ein Backup stellt die vorherigen Werte exakt wieder her.

**Texture streaming.** Ein lädt Texturen schrittweise und spart Speicher; Nachladen kann kurze Pausen erzeugen. Aus kann solche Pausen reduzieren, verbraucht aber mehr Speicher. Auf derselben Strecke vergleichen und APB zwischen Tests neu starten. Auch mit 32 GB RAM gibt es keinen universell besten Modus.

**Musik.** Fremde Autoradios können auch bei deaktivierten erstellten Songs und eigener Playlist-Lautstärke 0 hörbar bleiben. Nun werden auch der Wiedergabestatus gespeichert, vorhandene Überschreibungen geprüft und Maschinenstandards gesetzt. Eine verlässliche globale Stummschaltung fremder Radios bei erhaltenen Kill-Themes ist nicht bestätigt. Instrumente, Audiobanken und Gesamtlautstärke bleiben unberührt.

**Hilfe.** Werkzeuge → Befehle und Tasten öffnet die Referenz aus der vorhandenen englischen Lokalisierung: [Befehle](COMMANDS.de.md). Spieltexte und Missionsbeschreibungen werden dafür nicht umgeschrieben.


## Neu in 2.8

- Grundeinstellungen → Auflösung: zusätzlich 640×480, 640×640, 800×600, 800×800, 960×540, 1024×768, 1024×1024 und 1152×864. Eigene Breite × Höhe öffnet zwei Eingabefelder. Eingabegrenzen: Breite 320–7680, Höhe 240–4320. Spiel und Bildschirm müssen den gewählten Modus unterstützen. Standardmäßig bleibt die aktuelle Auflösung erhalten.
- Die Sprachen heißen English / Russian. Die englische Lokalisierung vor 2.6 wurde wiederhergestellt. Russisch übernimmt Reihenfolge, Zeiten, Zahlen und Waffenwerte. S/M/H bedeutet kleine/mittlere/schwere Gegenstände. Werte stammen aus der vorherigen Ausgabe und wurden nicht gegen neue Spielpatches geprüft.
- Der Musik-Scherzknopf wurde entfernt. Die Witze in den Spieltexten bleiben erhalten.


## Englische / russische Spieltexte

Unter **Start → Spieltext / Missionen** die Sprache auswählen. **Englische und russische Spieltexte installieren** eingeschaltet lassen, **Anwenden** und danach **Play APB** drücken. APB nach einem Sprachwechsel neu starten. Die Auswahl oben rechts ändert nur die Sprache dieses Programms.

Beide Sprachpakete werden gemeinsam installiert. Nach dem ersten Anwenden kann die Spielsprache über die Auswahl und Play APB gewechselt werden. Grafik und Audio müssen weiterhin angewendet werden. Andere Verknüpfungen verwenden ihr eigenes Sprachargument.

Russische Missionen, Aufgaben, Waffen und Beschreibungen basieren auf den russischen Spieltabellen. Fehlende Einträge wurden anhand der aktuellen englischen Tabellen ergänzt und bei Bedarf übersetzt. Modellnamen bleiben erhalten. Einige neuere Meldungen außerhalb dieser Kategorien können englisch bleiben. Dies ist eine Community-Übersetzung.


**Max Low** reduziert zusätzlich erzeugte Charakter-, Fahrzeug- und Symboltexturen auf 64 Pixel und normale Texturkategorien auf höchstens 32 Pixel. Einfachere Modelle und Materialien werden verwendet, soweit unterstützt. UI, Auflösung, Bildpuffer und Sichtweiten bleiben erhalten. Dünne Zäune können Details verlieren. Normal + Anwenden stellt das normale Profil wieder her. Darstellung und FPS müssen noch im Spiel geprüft werden.

Backup wiederherstellen stellt auch die zugehörige Verknüpfung wieder her. Backups aufbewahren. Sicherungen älterer Pakete werden nicht automatisch übernommen.


APB-Einstellungen, Direktstart und wiederherstellbare Änderungen. Die Oberfläche startet auf Englisch; Deutsch und Russisch stehen im Sprachmenü bereit.

## Erste Schritte

1. Den vollständigen Ordner entpacken. EXE, Datendateien und Assets zusammenlassen.
2. APB und Launcher schließen, dann **APB-Config.exe** öffnen.
3. Unter Grundeinstellungen eine APB-Verknüpfung oder `Binaries/APB.exe` auswählen.
4. Einstellungen wählen und **Anwenden** anklicken.
5. **Play APB** startet das Spiel direkt.

Rote gekreuzte Klingen bedeuten eingeschaltet, graue ausgeschaltet. Vorhandene Einstellung behalten lässt die jeweilige Option unverändert. Änderungen benötigen Anwenden und einen Spielneustart.

## Starttasten


## 01  GRUNDLAGEN

**Spielauflösung** — Standard: behält die Spielauflösung. Renderauflösung bleibt bei 100 %.

**FPS-Limit** — Standard: 144. Leer oder 0 hebt das FPS-Limit auf. MSAA kann Leistung kosten.

**NORMAL · klare Spieler** — Wenige Umgebungsdetails; höhere Qualität für Spieler, Kleidung, Symbole und Fahrzeuge. Normale Zauntexturen und 100 % Renderauflösung.

**NIEDRIG · alle Texturen** — Senkt auch Texturen von Spielern, Kleidung, Fahrzeugen und Symbolen. Zäune können undurchsichtig wirken. Kein garantierter FPS-Gewinn. Normal + Anwenden stellt das normale Profil wieder her.

**Kleidungs- und Fahrzeugeditoren aktivieren** — An: Social-Editoren funktionieren. Aus: kann regelmäßige Ruckler mindern, aber Editoren blockieren und Respawn-Pausen verlängern.

## 02  EFFEKTE

**Fahrzeugfeuer / gemeinsame Trefferpartikel** — Blut ist mit Fahrzeugfeuer / gemeinsame Trefferpartikel oben gekoppelt. Ausschalten reduziert diese gemeinsamen Effekte. Kein separater Blutfilter; vollständige Entfernung aller Bluteffekte ist nicht bestätigt.


**Partikeleffekte der Umgebung ausschalten** — Deaktiviert Umgebungspartikel. Granaten- und Fahrzeugeffekte haben eigene Einstellungen.

**Mündungsfeuer anzeigen** — Zeigt oder versteckt Mündungsfeuer. Schaden und Genauigkeit bleiben gleich.

**Ausgeworfene Hülsen anzeigen** — Zeigt oder versteckt ausgeworfene Patronenhülsen.

## 03  AUDIO

**Vivox-Sprachchat** — Deaktiviert Sprachsystem, automatischen Beitritt und Sprachkanäle in lokalen Kontoeinstellungen. Neustart nötig. Entladen der Voice-Bibliothek und FPS-Gewinn nicht bestätigt. Nach erneutem Einschalten Kanäle in APB aktivieren.

**Spielton bei Sprachchat absenken** — Aus: Sprachchat senkt die übrigen Spielgeräusche nicht mehr ab.

**Spieler-Todesthemen** — Kurze Melodien nach einem Kill. Hörbar aktiviert Themes von Freunden, ignorierten und anderen Spielern.

**Von Spielern erstellte Songs** — Nutzt APBs Option für selbst erstellte Songs. Schaltet die lizenzierte Musikbibliothek nicht stumm. Kill-Themes werden separat gesteuert.

**Lautstärke der eigenen Playlist** — 0 % schaltet eigene Player stumm, Autostart und Übertragung aus dem Auto ab. Fremdes Autoradio kann hörbar bleiben. Playlists bleiben erhalten.

## 04  STEUERUNG


**Spielinterner Sprint-Punkt** — Steuert APBs eingebauten Sprint-Punkt für vorhandene lokale Konten. Kein dauerhaftes Fadenkreuz.

**Automatisch bereit für Missionen** — Aktiviert APBs automatische Missionsbereitschaft.

**HUD-Skalierung auf Spielstandard** — Setzt beim Anwenden die HUD-Skalierung auf den Spielstandard. Keine garantierte Korrektur eines Zielversatzes. Backup stellt den vorherigen Wert wieder her.

## 05  START

**Ladevideos überspringen** — Fügt -nomovies zum Direktstart hinzu. Überspringt Intro-Videos; Karten müssen weiterhin laden.

**Startbild überspringen** — Fügt -nosplash zum Direktstart hinzu. Das Anti-Cheat-Fenster bleibt sichtbar.

**Steam-Integration ausschalten** — Fügt -nosteam hinzu. Deaktiviert Steam-Autologin; separate Spielanmeldung erforderlich.

**Einfacher Login-Hintergrund** — Nutzt beim Login den Hintergrund der Distriktauswahl. Zur Charaktererstellung ausschalten.

**Spielsprache** — English oder Russian wählen und anwenden.

**Zusätzliche Community-Witze** — Ergänzt Cheater Located und Sosality loading… mit den eigenen Spieltexten. Nur humorvolle Texte, keine Cheat-Erkennung.

## 06  WERKZEUGE

**Texturstreaming** — Lädt Texturen nach Bedarf. An/Aus kann je nach System unterschiedlich auf Ruckler wirken. Neustart nötig.

**Festplatten-Cache** — Nutzt einen Laufwerkscache für wiederverwendbare Daten. Standardmäßig aus; Nutzen hängt von RAM und Laufwerk ab.

**Gamma** — Ändert die Helligkeit des gesamten Bildes. Keine getrennte Himmelshelligkeit oder feste Tageszeit.

## Fadenkreuz · Risiko

**Experimentelles Shader-Fadenkreuz** — Zeichnet einen kontrastreichen Punkt in die Mitte der Spielszene. Ergänzt nur den Code des Fadenkreuzes im kompatiblen installierten Shader. Anwenden erstellt vorher ein Backup. Standardmäßig deaktiviert.

**Risiko der Shader-Änderung akzeptieren** — Nutzung auf eigenes Risiko. Für diese Shader-Änderung ist keine offizielle Freigabe bestätigt. Änderungen an Spieldateien können Kontosanktionen auslösen.

**Punkt dieser App entfernen** — Experimentell: Sichtbarkeit hängt von Nachbearbeitung und Shader-Cache ab. Keine Funktionsgarantie für die aktuelle Spielversion. Verschiebt nicht das Waffenvisier und behebt keinen Zielversatz. Punktgröße hängt von der Auflösung ab. Entfernen löscht nur den markierten Zusatz; das Backup stellt die vorherige Datei wieder her.

## Umfang der Musikoptionen

Die Preset-Taste aktiviert Kill-Themes, deaktiviert erstellte Songs und setzt die eigene Playlist auf null. Null deaktiviert außerdem automatische Fortsetzung, Wiedergabe zu Fuß und Übertragung aus dem Auto. Eine spätere Lautstärkeerhöhung stellt diese Wiedergabeoptionen nicht automatisch wieder her; dafür APB-Einstellungen oder Backup nutzen. Lizenzierte Musik fremder Autoradios kann hörbar bleiben. Kein bestätigter Schalter gefunden, der sämtliche fremden Songs abschaltet und Kill-Themes erhält. Audiobanken und Instrumentenordner bleiben erhalten. Die Option benötigt eine vorhandene lokale Musikbibliothek; nötigenfalls den Musikplayer einmal in APB öffnen.

## Backups

Backup wiederherstellen macht die letzte Anwendung von Spieldateien für den gewählten Spielordner rückgängig. Frühere Änderungen benötigen frühere Backups. Verknüpfungen werden separat in shortcut-before.lnk und shortcut.json gesichert. Den Backups-Ordner aufbewahren. Nach Updates zuerst den Launcher abschließen lassen und danach Einstellungen anwenden.

## Spielerzahlen und Links

Spielerzahlen werden alle 60 Sekunden von der offiziellen GamersFirst-Distriktseite geladen, solange die App geöffnet ist. Gesamtzahl, EU, NA und Fraktionen sind Website-Momentaufnahmen, keine direkte Serververbindung. Fehlende Daten erscheinen als nicht verfügbar statt null. Links zu Nachrichten, Forum und Discord öffnen erst beim Anklicken.

## Ausrichtung des Fadenkreuzes

Der Shader-Punkt markiert die Mitte der Spielszene und korrigiert nicht die Zielrichtung der Waffe. Sichtbarkeit hängt von Nachbearbeitung und kompiliertem Shader-Cache ab. Shader-Caches werden nicht gelöscht. Ein Monitor-Punkt erscheint normalerweise nicht auf Screenshots; zum Vergleich mit dem Spielvisier ist ein Handyfoto nötig. Ein Zielversatz wurde nicht vermessen oder korrigiert.

## Prüfungen und Quellen

Schreibvorgänge, Wiederherstellung und Bedienelemente sind an Kopien getestet. Shader-Kompilierung, Musikwiedergabe, FPS-Gewinne und Entladen von Vivox benötigen einen Spieltest. Dies ist ein Community-Tool, keine offizielle Veröffentlichung. Freigabe-Motive im Hintergrund sind Dekoration und kein Genehmigungsnachweis.

[Flaws](https://github.com/flawsv/apb) · [Lazer](https://github.com/lvzxr/apb-cfg-loader) · [SARD FAQ](https://www.gamersfirst.com/apb/news/2024/8/14/sard-faq) · [Crosshair source](https://zhyk.org/forum/showthread.php?t=466225)
