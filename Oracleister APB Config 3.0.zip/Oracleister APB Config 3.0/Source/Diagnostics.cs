using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Xml;
using System.Globalization;
public static class Diagnostics {
 public static string Report(string game){string p=Path.Combine(game,@"APBGame\Config\APBMachineOptions.ini");if(!File.Exists(p))throw new Exception("Select a game folder with APBMachineOptions.ini first.");string t=File.ReadAllText(p);var lines=new List<string>();foreach(string k in new[]{"ResX","ResY","Fullscreen","DisableCreatedSongs","MuteAllDeathThemes"}){var m=Regex.Match(t,"(?m)^"+k+"=([^\\r\\n]+)");lines.Add(k+": "+(m.Success?m.Groups[1].Value:"not set"));}int total=0,zero=0,invalid=0;string account=Path.Combine(game,@"APBGame\Config\Account");if(Directory.Exists(account))foreach(string f in Directory.GetFiles(account,"usermusiclibrary.xml",SearchOption.AllDirectories)){total++;try{var doc=new XmlDocument{XmlResolver=null};using(var rd=XmlReader.Create(f,new XmlReaderSettings{DtdProcessing=DtdProcessing.Prohibit,XmlResolver=null}))doc.Load(rd);var n=doc.SelectSingleNode("/MusicPlayer/Config/CurrentPlaybackInformation") as XmlElement;if(n==null){invalid++;continue;}if(double.Parse(n.GetAttribute("Volume"),CultureInfo.InvariantCulture)==0)zero++;}catch{invalid++;}}lines.Add("Local music libraries: "+total+"; volume zero: "+zero+"; unreadable: "+invalid);try{lines.Add("Primary display modes (read only): "+string.Join(", ",ApbDisplayModes.Read()));}catch{lines.Add("Primary display modes: unavailable");}return string.Join("\r\n",lines);}
}
