using System;
using System.Globalization;
using System.Net;
using System.Text.RegularExpressions;

public sealed class PopulationSnapshot {
 public int Total,EuTotal,EuEnforcers,EuCriminals,NaTotal,NaEnforcers,NaCriminals;
 public string SourceTime;
 public DateTime CheckedAt;
}
public static class Population {
 static string Capture(string html,string pattern){var m=Regex.Match(html,pattern,RegexOptions.IgnoreCase|RegexOptions.Singleline);if(!m.Success)throw new FormatException("Population markup changed");return m.Groups[1].Value;}
 static int Count(string html,string pattern){string value=WebUtility.HtmlDecode(Capture(html,pattern));value=Regex.Replace(value,@"[,\s\u00a0]","");int n;if(!int.TryParse(value,NumberStyles.None,CultureInfo.InvariantCulture,out n))throw new FormatException("Invalid population count");return n;}
 static int[] Region(string html,string id){string panel=Capture(html,"id\\s*=\\s*[\"']panel-"+id+"[\"'].*?<div\\b[^>]*class\\s*=\\s*[\"']status-summary[\"'][^>]*>(.*?)</div>");return new[]{Count(panel,"class=[\"']sum-total[\"'][^>]*>\\s*<strong[^>]*>([0-9, &;a-z]+)</strong>"),Count(panel,"class=[\"']enf[\"'][^>]*>\\s*ENF\\s+([0-9, &;a-z]+)</span>"),Count(panel,"class=[\"']crim[\"'][^>]*>\\s*CRIM\\s+([0-9, &;a-z]+)</span>")};}
 public static PopulationSnapshot Parse(string html){
  var eu=Region(html,"EU");var na=Region(html,"NA");
  var s=new PopulationSnapshot{Total=Count(html,"class=[\"']total-ccu-stats[\"'][^>]*>\\s*<strong[^>]*>([0-9, &;a-z]+)</strong>\\s*online now"),EuTotal=eu[0],EuEnforcers=eu[1],EuCriminals=eu[2],NaTotal=na[0],NaEnforcers=na[1],NaCriminals=na[2],SourceTime="—",CheckedAt=DateTime.Now};
  // A source timestamp is optional: its presentation must not invalidate counts.
  var stamp=Regex.Match(html,"class\\s*=\\s*[\"']status-updated[\"'][^>]*>(.*?)</span>",RegexOptions.IgnoreCase|RegexOptions.Singleline);
  if(stamp.Success){
   var datetime=Regex.Match(stamp.Groups[1].Value,"datetime\\s*=\\s*[\"']([^\"']+)[\"']",RegexOptions.IgnoreCase);DateTimeOffset dt;
   if(datetime.Success&&DateTimeOffset.TryParse(WebUtility.HtmlDecode(datetime.Groups[1].Value),CultureInfo.InvariantCulture,DateTimeStyles.None,out dt))s.SourceTime=dt.UtcDateTime.ToString("HH:mm 'UTC'",CultureInfo.InvariantCulture);
   else {string plain=WebUtility.HtmlDecode(Regex.Replace(stamp.Groups[1].Value,"<[^>]+>"," "));var legacy=Regex.Match(plain,@"\b([0-2]\d:[0-5]\d(?:\s*UTC)?)\b");if(legacy.Success)s.SourceTime=legacy.Groups[1].Value;}
  }
  return s;
 }
}
