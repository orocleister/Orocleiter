# Config review — 2.8

Reviewed the release archives Richard V3.2.3 Easter Fix, Writch v1.0.6 and Flaws v3.1, alongside our configuration.

| Feature | Decision |
| --- | --- |
| FPS limit, streaming, Social garbage collection | Already configurable. Keep defaults and Social/NoSocial profiles. |
| Muzzle flash / casings | Already configurable. |
| NPC ragdolls off, player ragdolls on | Already present. Keep player death-camera behavior. |
| Transparent UI | Existing profile uses OverlaySceneAlphaModulation=0.999. No duplicate control. |
| Colored localization | Added one preset selector using APB color tags; keep text placeholders and icons. |
| Mission stages and weapon statistics | Restore our pre-2.6 tables; translate their structure into Russian. Do not silently replace them with other authors' versions. |
| Custom keybinds | Keep existing bindings; do not replace the user's controls with an entire foreign input file. |
| Outline graphics bug | Not adopted: depends on lighting artifacts. |
| New per-weapon data and stage timers | No claim of current balance accuracy; existing numbers preserved. |

Sources: [Richard](https://github.com/cuvx/APB-Reloaded), [Writch](https://github.com/writchcraft/apb), [Flaws](https://github.com/flawsv/apb), [Flaws color tags](https://github.com/flawsv/apb/blob/main/localization%20resources/color%20tags.md). These sources describe their own configurations; they do not certify this combined app.
