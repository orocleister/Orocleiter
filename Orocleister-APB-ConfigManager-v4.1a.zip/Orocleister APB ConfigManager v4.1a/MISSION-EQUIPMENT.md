# Mission stage colors

Equipment suffixes (EQ, RAM, E/C equipment lists and DROP) have been removed. Existing stage descriptions, numbers and timers remain. Stage colors repeat: blue, orange, green, purple, yellow, pink. Color follows the stage number, including the remaining-stage roadmap. Live rendering still needs checking in APB.
