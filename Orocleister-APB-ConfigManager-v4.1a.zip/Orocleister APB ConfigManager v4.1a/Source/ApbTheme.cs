﻿using System; using System.Drawing; using System.Drawing.Drawing2D; using System.Windows.Forms; using System.Runtime.InteropServices;
public class ApbCheckBox:CheckBox {
 bool hover;
 public ApbCheckBox(){SetStyle(ControlStyles.UserPaint|ControlStyles.AllPaintingInWmPaint|ControlStyles.OptimizedDoubleBuffer,true);Cursor=Cursors.Hand;}
 protected override void OnMouseEnter(EventArgs e){hover=true;Invalidate();base.OnMouseEnter(e);}
 protected override void OnMouseLeave(EventArgs e){hover=false;Invalidate();base.OnMouseLeave(e);}
 protected override void OnCheckedChanged(EventArgs e){base.OnCheckedChanged(e);Invalidate();}
 protected override void OnPaint(PaintEventArgs e){
  var g=e.Graphics;g.Clear(BackColor);g.SmoothingMode=SmoothingMode.AntiAlias;
  // Crossed blades: red when enabled, grey outline when disabled.
  var state=g.Save();g.TranslateTransform(14,Height/2f);
  Color blade=Checked?Color.FromArgb(244,45,57):Color.FromArgb(91,105,119);
  using(var pen=new Pen(hover?Color.FromArgb(255,113,113):blade,1.3f)){
   g.DrawEllipse(pen,-11,-11,22,22);
   for(int i=0;i<2;i++){
    var sword=g.Save();g.RotateTransform(i==0?45:-45);
    PointF[] shape={new PointF(0,-13),new PointF(3,-8),new PointF(2,5),new PointF(6,5),new PointF(6,7),new PointF(1.5f,7),new PointF(1.5f,12),new PointF(-1.5f,12),new PointF(-1.5f,7),new PointF(-6,7),new PointF(-6,5),new PointF(-2,5),new PointF(-3,-8)};
    using(var fill=new SolidBrush(Checked?blade:BackColor))g.FillPolygon(fill,shape);
    g.DrawPolygon(pen,shape);g.Restore(sword);
   }
  }
  g.Restore(state);
  TextRenderer.DrawText(g,Text,Font,new Rectangle(34,0,Width-34,Height),Enabled?ForeColor:Color.Gray,TextFormatFlags.Left|TextFormatFlags.VerticalCenter|TextFormatFlags.EndEllipsis);
  if(Focused&&ShowFocusCues)ControlPaint.DrawFocusRectangle(g,new Rectangle(30,1,Width-32,Height-2));
 }
 public void ToggleForTest(){OnClick(EventArgs.Empty);}
}
public class ApbButton:Button {
 public int Glyph=-1;
 bool hover,down;
 public ApbButton(){SetStyle(ControlStyles.UserPaint|ControlStyles.AllPaintingInWmPaint|ControlStyles.OptimizedDoubleBuffer,true);Cursor=Cursors.Hand;}
 protected override void OnMouseEnter(EventArgs e){hover=true;Invalidate();base.OnMouseEnter(e);}
 protected override void OnMouseLeave(EventArgs e){hover=false;down=false;Invalidate();base.OnMouseLeave(e);}
 protected override void OnMouseDown(MouseEventArgs e){down=true;Invalidate();base.OnMouseDown(e);}
 protected override void OnMouseUp(MouseEventArgs e){down=false;Invalidate();base.OnMouseUp(e);}
 protected override void OnPaint(PaintEventArgs e){
  var g=e.Graphics;g.SmoothingMode=SmoothingMode.AntiAlias;
  bool active=BackColor.B>70;Color top=active?Color.FromArgb(0,139,213):Color.FromArgb(17,38,53);Color bottom=active?Color.FromArgb(0,53,93):Color.FromArgb(4,15,24);
  if(hover)top=Color.FromArgb(0,126,184);if(down)top=bottom;
  using(var b=new LinearGradientBrush(ClientRectangle,top,bottom,90))g.FillRectangle(b,ClientRectangle);
  Color edge=active||hover?Color.FromArgb(0,184,250):Color.FromArgb(39,79,101);
  using(var pen=new Pen(edge))g.DrawRectangle(pen,0,0,Width-1,Height-1);
  using(var pen=new Pen(Color.FromArgb(60,170,218))){if(active||hover)g.DrawLine(pen,3,2,Width-4,2);}
  Rectangle text=ClientRectangle;if(Glyph>=0){using(var pen=new Pen(active?Color.White:Color.FromArgb(71,192,235),1.7f)){float y=Height/2f;switch(Glyph){case 0:g.DrawRectangle(pen,13,y-8,18,13);g.DrawLine(pen,22,y+5,22,y+10);g.DrawLine(pen,17,y+10,27,y+10);break;case 1:for(int i=0;i<3;i++){float yy=y-7+i*7;g.DrawLine(pen,12,yy,32,yy);g.DrawRectangle(pen,17+i%2*7,yy-2,4,4);}break;case 2:g.DrawPolygon(pen,new[]{new PointF(12,y-4),new PointF(18,y-4),new PointF(24,y-10),new PointF(24,y+10),new PointF(18,y+4),new PointF(12,y+4)});g.DrawArc(pen,21,y-8,12,16,-65,130);break;case 3:g.DrawEllipse(pen,13,y-9,18,18);g.DrawLine(pen,22,y-13,22,y+13);g.DrawLine(pen,9,y,35,y);break;case 4:g.DrawRectangle(pen,13,y-10,18,20);for(int i=0;i<3;i++)g.DrawLine(pen,17,y-5+i*5,27,y-5+i*5);break;case 5:g.DrawPolygon(pen,new[]{new PointF(15,y-11),new PointF(33,y),new PointF(15,y+11)});break;case 6:g.DrawArc(pen,12,y-11,12,12,0,270);g.DrawLine(pen,22,y-1,32,y+10);g.DrawLine(pen,18,y+2,28,y+13);break;default:g.DrawLine(pen,12,y-10,32,y+10);g.DrawLine(pen,12,y+10,32,y-10);g.DrawEllipse(pen,12,y-10,20,20);break;}}text=new Rectangle(43,0,Width-49,Height);}
  TextRenderer.DrawText(g,Text,Font,text,ForeColor,(Glyph>=0?TextFormatFlags.Left:TextFormatFlags.HorizontalCenter)|TextFormatFlags.VerticalCenter|TextFormatFlags.EndEllipsis);
  if(Focused&&ShowFocusCues)ControlPaint.DrawFocusRectangle(g,new Rectangle(4,4,Width-8,Height-8));
 }
}
public class ApbComboBox:ComboBox {
 public ApbComboBox(){DrawMode=DrawMode.OwnerDrawFixed;ItemHeight=22;FlatStyle=FlatStyle.Flat;BackColor=Color.FromArgb(10,27,40);ForeColor=Color.FromArgb(235,244,249);}
 protected override void OnDrawItem(DrawItemEventArgs e){
  var selected=(e.State&DrawItemState.Selected)!=0 && (e.State&DrawItemState.ComboBoxEdit)==0;
  using(var brush=new SolidBrush(selected?Color.FromArgb(0,81,124):Color.FromArgb(10,27,40)))e.Graphics.FillRectangle(brush,e.Bounds);
  string text=e.Index>=0?GetItemText(Items[e.Index]):Text;
  TextRenderer.DrawText(e.Graphics,text,Font,new Rectangle(e.Bounds.X+7,e.Bounds.Y,e.Bounds.Width-10,e.Bounds.Height),ForeColor,TextFormatFlags.Left|TextFormatFlags.VerticalCenter|TextFormatFlags.EndEllipsis);
 }
 protected override void WndProc(ref Message m){base.WndProc(ref m);if(m.Msg==0xF){using(var g=CreateGraphics())using(var b=new SolidBrush(Color.FromArgb(10,27,40)))using(var pen=new Pen(Color.FromArgb(60,106,132))){g.FillRectangle(b,Width-21,1,20,Height-2);g.DrawRectangle(pen,0,0,Width-1,Height-1);g.DrawLines(pen,new Point[]{new Point(Width-15,Height/2-2),new Point(Width-10,Height/2+3),new Point(Width-5,Height/2-2)});}}}
}
public class ApbSurface:Panel {
 public ApbSurface(){DoubleBuffered=true;Padding=new Padding(1);}
 protected override void OnPaint(PaintEventArgs e){base.OnPaint(e);using(var pen=new Pen(Color.FromArgb(37,75,96)))e.Graphics.DrawRectangle(pen,0,0,Width-1,Height-1);using(var pen=new Pen(Color.FromArgb(0,166,227),2)){e.Graphics.DrawLine(pen,0,0,34,0);e.Graphics.DrawLine(pen,0,0,0,20);e.Graphics.DrawLine(pen,Width-35,Height-1,Width-1,Height-1);}}
}
public static class ApbWindowTheme {
 [DllImport("dwmapi.dll")] static extern int DwmSetWindowAttribute(IntPtr hwnd,int attr,ref int value,int size);
 public static void DarkTitle(Form f){try{int yes=1;DwmSetWindowAttribute(f.Handle,20,ref yes,4);}catch{}}
}
