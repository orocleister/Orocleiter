using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Windows.Forms;
class Test {
 static string Hash(string p){using(var h=SHA256.Create())return Convert.ToBase64String(h.ComputeHash(File.ReadAllBytes(p)));}
 [STAThread] static int Main(string[] args){try{
  string mode=args[0],root=Path.GetFullPath(args[1]);
  if(mode=="ui"){Application.EnableVisualStyles();using(var w=new ConfigWindow(root,true))w.UiTest(Path.GetFullPath(args[2]));Console.WriteLine("PASS UI: 8 pages x 3 languages, custom resolution and FPS mapping");return 0;}
  var e=new Engine(root);e.S.Set("Spielordner",Path.GetFullPath(args[2]));
  if(mode=="build"){foreach(var p in e.Build()){string dest=Engine.Under(Path.GetFullPath(args[3]),p.Key);Directory.CreateDirectory(Path.GetDirectoryName(dest));File.WriteAllBytes(dest,p.Value);}Console.WriteLine("PASS build");return 0;}
  var before=Directory.GetFiles(e.Game,"*",SearchOption.AllDirectories).ToDictionary(x=>x,x=>Hash(x));
  e.Apply();if(!File.Exists(Path.Combine(root,"APB-Direct.lnk")))throw new Exception("Shortcut not created");
  e.Restore();var after=Directory.GetFiles(e.Game,"*",SearchOption.AllDirectories).ToDictionary(x=>x,x=>Hash(x));if(before.Count!=after.Count||before.Any(x=>!after.ContainsKey(x.Key)||after[x.Key]!=x.Value))throw new Exception("Restore mismatch");
  var old=Directory.GetFiles(e.Game,"*",SearchOption.AllDirectories).ToDictionary(x=>x,x=>Hash(x));e.S.Set("GameTextLanguage","Bad");try{e.Apply();throw new Exception("Invalid language accepted");}catch(Exception ex){if(ex.Message=="Invalid language accepted")throw;}
  if(old.Any(x=>Hash(x.Key)!=x.Value))throw new Exception("Validation wrote files");
  Console.WriteLine("PASS apply, exact restore, shortcut rollback and invalid-setting no-write");return 0;
 }catch(Exception e){Console.Error.WriteLine(e.ToString());return 1;}}
}
