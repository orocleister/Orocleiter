﻿using System;
using System.IO;
using System.Linq;
using System.Drawing;
using System.Windows.Forms;
using System.Threading.Tasks;
public sealed partial class ConfigWindow {
 void OtherControls(){using(var d=Dialog("OtherControls",650,430)){var modes=new[]{"Keep","Off","On"};var keys=new[]{"KeepSetting","SettingOff","SettingOn"};var dot=DChoice(d,"SprintDot",s.S("SprintDotMode"),20,modes,keys);var ready=DChoice(d,"AutoReadyLabel",s.S("AutoReadyMode"),75,modes,keys);var mouse=DChoice(d,"MouseLabel",s.S("MouseMode"),130,new[]{"Keep","Default","Legacy"},new[]{"KeepSetting","MouseDefault","MouseLegacy"});var hud=new ApbCheckBox{Text=T("ResetHUDScale"),Checked=s.B("ResetHUDScale"),ForeColor=ink};hud.SetBounds(20,190,610,35);d.Controls.Add(hud);DLabel(d,"HUDHelpShort",20,235,610,70);var ok=new ApbButton{Text=T("HoldDone"),ForeColor=ink,DialogResult=DialogResult.OK};ok.SetBounds(20,365,610,40);d.Controls.Add(ok);if(ShowSettings(d,"other-controls")==DialogResult.OK){s.Set("MouseMode",((Entry)mouse.SelectedItem).Value);s.Set("SprintDotMode",((Entry)dot.SelectedItem).Value);s.Set("AutoReadyMode",((Entry)ready.SelectedItem).Value);s.Set("ResetHUDScale",hud.Checked);}}}
 void ChoosePreset(string value){s.Set("GraphicsPreset",value);s.Set("CustomActive",value=="Custom");s.Set("ExtremeTextures",value=="Low");UpdateGraphics();}
 bool ConfirmCompatibility(){engine.Check();if(engine.RecoveryPending())throw new Exception("RecoveryPending");string result=engine.CompatibilityReport();return result=="CompatibilitySame"||MessageBox.Show(this,T(result)+"\n\n"+T("CompatibilityConfirm"),Text,MessageBoxButtons.OKCancel,MessageBoxIcon.Warning)==DialogResult.OK;}
 void ReportWindow(string title,string report){using(var d=Dialog(title,800,570)){var box=new TextBox{Multiline=true,ReadOnly=true,ScrollBars=ScrollBars.Both,WordWrap=true,BackColor=dark,ForeColor=ink,Text=report};box.SetBounds(20,20,760,530);d.Controls.Add(box);if(!testing)d.ShowDialog(this);}}
 void ManagerTools(){using(var d=Dialog("ManagerTools",680,435)){
 DLabel(d,"ManagerToolsHelp",20,16,640,76);
 Button(d,"HardwareReport",20,108,640,async()=>{try{string r=await Task.Run(()=>HardwareInfo.Report());if(!IsDisposed)ReportWindow("HardwareReport",r);}catch(Exception ex){MessageBox.Show(this,ex.Message,Text);}});
 Button(d,"CompatibilityCheck",20,165,640,()=>Do(()=>{Read();engine.Check();ReportWindow("CompatibilityCheck",T(engine.CompatibilityReport())+"\r\n\r\n"+engine.ClientIdentity());}));
 Button(d,"ExportProfile",20,222,310,()=>Do(()=>{Read();using(var f=new SaveFileDialog{Filter="Orocleister profile|*.apbprofile",FileName="My-APB-Profile.apbprofile"})if(f.ShowDialog(d)==DialogResult.OK)File.WriteAllText(f.FileName,ProfileExchange.Export(s));}));
 Button(d,"ImportProfile",350,222,310,()=>Do(()=>{using(var f=new OpenFileDialog{Filter="Orocleister profile|*.apbprofile"})if(f.ShowDialog(d)==DialogResult.OK){if(new FileInfo(f.FileName).Length>32768)throw new Exception("ProfileTooLarge");var values=ProfileExchange.Import(File.ReadAllText(f.FileName),s);string summary=string.Join("\r\n",values.Select(p=>p.Key+": "+s.S(p.Key)+" → "+Convert.ToString(p.Value)).ToArray());if(MessageBox.Show(d,summary+"\r\n\r\n"+T("ImportConfirm"),T("ImportProfile"),MessageBoxButtons.OKCancel,MessageBoxIcon.Question)!=DialogResult.OK)return;foreach(var v in values)s.Set(v.Key,v.Value);SyncProfileUI();}}));
 Button(d,"RecoverTransaction",20,280,640,()=>Do(()=>{s.Set("Spielordner",path.Text.Trim().Trim('"'));if(!engine.RecoveryPending())throw new Exception("NoRecoveryPending");engine.Recover();status.Text=T("RestoreDone");}));
 DLabel(d,"BackupMeaning",20,340,640,75);if(!testing)d.ShowDialog(this);
 }}
 void SyncProfileUI(){fps.Text=s.S("FPSLimit");foreach(var binding in combos.Where(b=>ProfileExchange.Keys.Contains(b.Property)&&b.Property!="Resolution"))SetCombo(binding.Property,s.S(binding.Property));bool found=false;for(int i=0;i<resolution.Items.Count;i++)if(((Entry)resolution.Items[i]).Value==s.S("Resolution")){resolution.SelectedIndex=i;found=true;break;}if(!found){string[] r=s.S("Resolution").Split('x');width.Value=int.Parse(r[0]);height.Value=int.Parse(r[1]);resolution.SelectedIndex=1;}UpdateGraphics();}
}
