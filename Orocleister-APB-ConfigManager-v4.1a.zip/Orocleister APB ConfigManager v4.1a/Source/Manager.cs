﻿using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Diagnostics;
using System.Management;
public static class ProfileExchange {
 public static readonly string[] Keys={"GraphicsPreset","Resolution","FPSLimit","AAMode","DisplayMode","CharacterQuality","VehicleQuality","PedestrianQuality","TrafficQuality","EnvironmentQuality","SymbolQuality","CustomDetail","CustomShadows","CustomActive","ExtremeTextures","FogMode","AnisotropyMode","VsyncMode","BloomMode","OcclusionMode","MouseSmoothingMode","MouseAccelerationMode","FrameQueueMode","MouseMode","VoiceMode","DuckingMode","DeathThemesMode","CreatedSongsMode","MusicPlayerVolume","SprintDotMode","AutoReadyMode"};
 public static string Export(Settings s){return Settings.Json.Serialize(new {format="OrocleisterProfile",version=1,settings=Keys.ToDictionary(k=>k,k=>s.Data[k])});}
 public static Dictionary<string,object> Import(string json,Settings current){
  if(json.Length>32768)throw new Exception("ProfileTooLarge");
  var root=Settings.Json.Deserialize<Dictionary<string,object>>(json);
  if(root==null||root.Count!=3||!root.ContainsKey("format")||!root.ContainsKey("version")||!root.ContainsKey("settings")||Convert.ToString(root["format"])!="OrocleisterProfile"||!(root["version"] is int)||(int)root["version"]!=1)throw new Exception("ProfileInvalid");
  foreach(string key in Keys.Concat(new[]{"format","version","settings"}))if(System.Text.RegularExpressions.Regex.Matches(json,"\""+key+"\"\\s*:").Count!=1)throw new Exception("ProfileInvalid");
  var data=root["settings"] as Dictionary<string,object>;if(data==null||data.Count!=Keys.Length||data.Keys.Any(k=>!Keys.Contains(k)))throw new Exception("ProfileInvalid");
  foreach(var p in data){object original=current.Data[p.Key];if(original is bool ? !(p.Value is bool) : original is string ? !(p.Value is string) : !(p.Value is int))throw new Exception("ProfileInvalid");}
  var before=current.Data;try{current.Data=new Dictionary<string,object>(before);foreach(var p in data)current.Set(p.Key,p.Value);if(!new[]{"Personal","Low","Balanced","Custom"}.Contains(current.S("GraphicsPreset")))throw new Exception("ProfileInvalid");Engine.Resolution(current.S("Resolution"));Graphics31.Validate(current);foreach(string key in new[]{"MouseSmoothingMode","MouseAccelerationMode","FrameQueueMode","VoiceMode","DuckingMode","DeathThemesMode","CreatedSongsMode","SprintDotMode","AutoReadyMode"})if(!new[]{"Keep","Off","On"}.Contains(current.S(key)))throw new Exception("ProfileInvalid");if(!new[]{"Keep","0","25","50","75","100"}.Contains(current.S("MusicPlayerVolume"))||!new[]{"Keep","Standard","Default","Legacy"}.Contains(current.S("MouseMode")))throw new Exception("ProfileInvalid");foreach(var k in new[]{"CustomDetail"})if(!new[]{"0","1","2"}.Contains(current.S(k)))throw new Exception("ProfileInvalid");
   if(!new[]{"Keep","Off","2","4","8"}.Contains(current.S("AAMode"))||!new[]{"Keep","Windowed","Fullscreen","Borderless"}.Contains(current.S("DisplayMode"))||current.I("FPSLimit")<0||current.I("FPSLimit")>1000)throw new Exception("ProfileInvalid");
  }finally{current.Data=before;}return data;
 }
}
public static class HardwareInfo {
 static string Query(string cls,string key){try{using(var search=new ManagementObjectSearcher("SELECT "+key+" FROM "+cls)){using(var rows=search.Get()){return string.Join(", ",rows.Cast<ManagementObject>().Select(r=>Convert.ToString(r[key])).ToArray());}}}catch{return "Unavailable";}}
 [System.Runtime.InteropServices.StructLayout(System.Runtime.InteropServices.LayoutKind.Sequential)] class MemoryStatus {public uint length=(uint)System.Runtime.InteropServices.Marshal.SizeOf(typeof(MemoryStatus));public uint load;public ulong total,available,pageTotal,pageAvailable,virtualTotal,virtualAvailable,extended;}
 [System.Runtime.InteropServices.DllImport("kernel32.dll",SetLastError=true)] static extern bool GlobalMemoryStatusEx([System.Runtime.InteropServices.In, System.Runtime.InteropServices.Out] MemoryStatus status);
 static string Cpu(){string value=Query("Win32_Processor","Name");if(value!="Unavailable"&&value!="")return value;try{using(var k=Microsoft.Win32.Registry.LocalMachine.OpenSubKey(@"HARDWARE\DESCRIPTION\System\CentralProcessor\0"))return Convert.ToString(k.GetValue("ProcessorNameString","Unavailable"));}catch{return "Unavailable";}}
 static string Gpu(){string value=Query("Win32_VideoController","Name");if(value!="Unavailable"&&value!="")return value;try{var names=new List<string>();using(var k=Microsoft.Win32.Registry.LocalMachine.OpenSubKey(@"SYSTEM\CurrentControlSet\Control\Class\{4d36e968-e325-11ce-bfc1-08002be10318}")){foreach(string name in k.GetSubKeyNames().Where(n=>System.Text.RegularExpressions.Regex.IsMatch(n,@"^\d{4}$")))using(var sub=k.OpenSubKey(name)){string description=Convert.ToString(sub.GetValue("DriverDesc",""));if(description!="")names.Add(description);}}return names.Count>0?string.Join(", ",names.Distinct()):"Unavailable";}catch{return "Unavailable";}}
 public static string Report(){string ram=Query("Win32_ComputerSystem","TotalPhysicalMemory");if(ram=="Unavailable"||ram==""){var status=new MemoryStatus();if(GlobalMemoryStatusEx(status))ram=status.total.ToString();}double n;bool ok=double.TryParse(ram,out n);double gb=ok?n/1073741824:0;return "CPU: "+Cpu()+"\r\nGPU: "+Gpu()+"\r\nRAM: "+(ok?gb.ToString("0.0")+" GB":ram)+"\r\n\r\n"+(ok?(gb<16?"Recommendation: Low; keep texture streaming available.":"Recommendation: Balanced as a starting point."):"No recommendation: hardware query unavailable.")+"\r\nHeuristic only, not an FPS measurement. No settings changed.";}
}
public sealed partial class Engine {
 public void LogEvent(string message){try{File.AppendAllText(Path.Combine(Root,"manager-events.log"),DateTime.UtcNow.ToString("o")+" "+message+Environment.NewLine);}catch{}}
 public static string Hash(string path){using(var h=SHA256.Create())using(var f=File.OpenRead(path))return BitConverter.ToString(h.ComputeHash(f)).Replace("-","").ToLowerInvariant();}
 public string ClientIdentity(){string p=Under(Game,@"Binaries\APB.exe");return FileVersionInfo.GetVersionInfo(p).ProductVersion+" | "+Hash(p);}
 string JournalPath(){return Path.Combine(Root,"pending-transaction.json");}
 void BeginTransaction(string backup){if(File.Exists(JournalPath()))throw new Exception("RecoveryPending");Atomic(JournalPath(),System.Text.Encoding.UTF8.GetBytes(Settings.Json.Serialize(new {backup=backup,game=Game})));}
 void FinishTransaction(){if(File.Exists(JournalPath()))File.Delete(JournalPath());}
 public bool RecoveryPending(){return File.Exists(JournalPath());}
 public void Recover(){Check();var j=Settings.Json.Deserialize<Dictionary<string,object>>(File.ReadAllText(JournalPath()));if(Convert.ToString(j["game"])!=Game)throw new Exception("RecoveryWrongGame");string backup=Path.GetFullPath(Convert.ToString(j["backup"]));if(!backup.StartsWith(Path.Combine(Root,"Backups")+"\\",StringComparison.OrdinalIgnoreCase))throw new Exception("Invalid backup path");RestoreManifest(backup);FinishTransaction();LogEvent("interrupted-transaction-recovered");}
 public string CompatibilityReport(){string path=Path.Combine(Root,"client-baseline.json"),now=ClientIdentity();if(!File.Exists(path))return "CompatibilityFirst";var d=Settings.Json.Deserialize<Dictionary<string,string>>(File.ReadAllText(path));return d["game"]==Game&&d["identity"]==now?"CompatibilitySame":"CompatibilityChanged";}
 public void AcceptClientBaseline(){Atomic(Path.Combine(Root,"client-baseline.json"),System.Text.Encoding.UTF8.GetBytes(Settings.Json.Serialize(new {game=Game,identity=ClientIdentity()})));}
 public static void CheckTargets(IEnumerable<string> names){foreach(string n in names){string ext=Path.GetExtension(n).ToLowerInvariant();if(!new[]{".ini",".ger",".rus",".int",".xml"}.Contains(ext)||n.IndexOf("Content",StringComparison.OrdinalIgnoreCase)>=0||n.IndexOf("Shaders",StringComparison.OrdinalIgnoreCase)>=0||n.IndexOf("..",StringComparison.Ordinal)>=0||Path.IsPathRooted(n))throw new Exception("Unsupported output file: "+n);if(ext==".xml"&&!n.EndsWith("usermusiclibrary.xml",StringComparison.OrdinalIgnoreCase))throw new Exception("Unsupported XML output: "+n);}}
}
