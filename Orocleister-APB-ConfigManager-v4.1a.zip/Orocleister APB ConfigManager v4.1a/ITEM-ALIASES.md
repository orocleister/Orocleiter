# Custom item names

Applied to the English and Russian text packs: EOL The Hammer/Kickback/Deep Impact → EOL 'iLoveDicks'; N-HVR 243 Scout → N-HVR 243 'MatthewScoutina'; N-ISSR-B Dog-Ear → Dog-Eggs; Nulander Pioneer → Kalina Lada. Variant suffixes and category colors are retained. Other named HVR variants are unchanged. Statistics and mission descriptions are unchanged.

Streamer privacy: CharacterNameRemoved is Dizamorphin instead of You. Separate confirmed hidden-friend, hidden-teammate and hidden-enemy replacement keys were not found in the installed localization files. Those requested aliases are not implemented; general Friend/Enemy labels are unchanged. In-game rendering still needs verification.
