# Text colors

Sniper rifles: red. Assault rifles and rifles: yellow. SMG: cyan. Shotguns: orange. LMG: green. Grenades and launchers: purple. Less-lethal primaries: turquoise. Secondary weapons: pink. Weapon names and matching inventory categories share a color. Classification uses the cached APBDB weapon categories; unmatched items remain unchanged. Descriptions and stats are not recolored or shortened. Existing game color markup is used; live rendering is not yet verified.
