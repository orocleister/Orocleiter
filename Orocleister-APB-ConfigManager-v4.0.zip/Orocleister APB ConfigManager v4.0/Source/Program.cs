﻿using System;
using System.IO;
using System.Windows.Forms;
using System.Reflection;
[assembly:AssemblyTitle("Orocleister APB ConfigManager")]
[assembly:AssemblyProduct("Orocleister APB ConfigManager")]
[assembly:AssemblyDescription("APB configuration editor and direct game launcher. Native .NET Windows application.")]
[assembly:AssemblyVersion("4.0.0.0")]
[assembly:AssemblyFileVersion("4.0.0.0")]
static class Program {
 [STAThread] static void Main(){Application.EnableVisualStyles();Application.SetCompatibleTextRenderingDefault(false);Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);Application.ThreadException+=(s,e)=>MessageBox.Show(e.Exception.Message,"Orocleister APB ConfigManager v4.0",MessageBoxButtons.OK,MessageBoxIcon.Error);try{using(var app=new ConfigWindow(AppDomain.CurrentDomain.BaseDirectory,false))Application.Run(app);}catch(Exception e){MessageBox.Show("Extract the complete folder before starting APB-Config.exe.\n\n"+e.Message,"Orocleister APB ConfigManager v4.0",MessageBoxButtons.OK,MessageBoxIcon.Error);}}
}
