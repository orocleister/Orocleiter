# Orocleister APB ConfigManager v4.0

Das gesamte ZIP in einen beschreibbaren Ordner entpacken und **APB-Config.exe** starten. Windows 10/11 mit .NET Framework 4.8, ohne PowerShell oder Administratorstart.

## Starten
APB und Launcher schließen, APB.exe oder direkte Verknüpfung auswählen. Zunächst „Deine Config“ nutzen. Auflösung bleibt erhalten; FPS 144, leer/0 = unbegrenzt. Änderungen prüfen und Anwenden. Play APB startet direkt, Update Game öffnet nur den offiziellen Updater.

## Profile und Einstellungen
- **Deine Config:** bisherige niedrige Umgebungsgrafik, detaillierte Spieler/Autos/Symbole.
- **Low:** bisherige minimale Qualität; Zäune und Modelle können schlechter aussehen. Kein garantierter FPS-Gewinn.
- **Balanced:** mehr Umgebungsdetails bei reduzierten Schatten; gespeicherte Custom-Regler bleiben erhalten.
- **Custom:** einzelne Texturregler. Explizite Grafikoptionen überschreiben das gewählte Profil.
- **Grafik:** Anti-Aliasing nur einmal unter Erweiterte Grafik. Bloom und Umgebungsverdeckung separat. Bloom startet auf Aus. Kein bestätigter Bloom-Stärkeregler oder nur den Himmel abdunkelnder Regler.
- **Input:** Mausglättung, Spiel-Mausbeschleunigung, VSync und Renderthread-Vorlauf einzeln Beibehalten/Aus/Ein. Anfangs Beibehalten. VSync aus kann Tearing verursachen; Vorlauf aus kann FPS oder Frametimes verschlechtern. Kein Double-Buffering-Schalter. Empfindlichkeit und Windows-Mausoptionen bleiben durch diese Schalter erhalten.
- **Weitere Steuerung:** Sprintpunkt, Auto-Ready, HUD-Reset und optional Achsenmultiplikator 1.0/Legacy 2.0. Der Multiplikator ändert absichtlich das Mausverhalten; sonst Beibehalten nutzen.
- **Halten im Spiel:** nach Anwenden und Neustart unter Bewegung Ducken (Hold/Toggle), unter Kampf Lehnen links/rechts (Hold/Toggle) wählen. Strg bzw. Q/E zuweisen und bei der anderen Aktion lösen. Keine automatische Tasten-Neubelegung. Klassisches Hold-Crouch kann nach Unterbrechungen hängen bleiben; im Spiel testen.

## Audio
Benutzerlieder werden standardmäßig stumm angefordert, der lokale Musikplayer auf null gesetzt. Kill-Themes einschließlich Freund-/Ignoriert-/Nichtfreund-Themes werden aktiviert. Gesamt- und Effektlautstärke bleiben erhalten. **Musik fremder Autos kann weiter hörbar sein; vollständige Stummschaltung ist nicht bestätigt.** Keine Änderung/Löschung von Soundbanks, Instrumenten, Fahrzeugverstärker-Ressourcen oder Umgebungsgeräuschen. Live-Test der Themes steht aus.

## Austausch, Diagnose und Wiederherstellung
Tools exportiert geprüfte Grafik-, Input- und Audioauswahl als .apbprofile. Keine Kontodaten, Pfade, Tokens, Programme oder beliebige INI-Dateien. Import prüft Größe, Schema, Schlüssel, Typen und Werte und zeigt vor dem Laden die Änderungen. Anwenden bleibt separat. Spielpfad, Startargumente und Sprachpakete werden nicht geteilt.
CPU, installierte Grafikadapter und nutzbarer RAM werden über Windows ermittelt. Empfehlungen sind einfache Startpunkte, kein Benchmark. Update-Prüfung vergleicht APB.exe-Version und SHA-256 mit dem letzten bestätigten Anwenden. Das beweist keine Kompatibilität aller Dateien; bei geändertem Client erfolgt kein stilles Übernehmen.
Vor Anwenden: Backup, SHA-256-Prüfsummen und Transaktionsjournal. Bei Abbruch blockiert die App weiteres Anwenden/Spielen bis zur Wiederherstellung unter Tools → Backup wiederherstellen. Beschädigte Backups werden vor dem Zurückschreiben abgewiesen. App- und Backups-Ordner behalten. Neue entpackte Kopien übernehmen alte Backups nicht automatisch. Backup ist der vorherige, eventuell modifizierte Zustand; Originaldateien liefert die offizielle Reparatur. Nicht mehrere Manager gleichzeitig nutzen. Erfolgreiches Anwenden/Wiederherstellen wird lokal protokolliert.

## Geprüft und offen
Build, Oberfläche in drei Sprachen, Profilprüfungen, getrennte Input-Schalter, Bindings, Theme-Werte, Erhalt von Custom, Anwenden/bytegenaues Wiederherstellen im Testordner, beschädigte Backups, simulierte Unterbrechung und Client-Änderung geprüft. Kein Nachweis für FPS-Gewinn oder vollständige Musikabschaltung im Spiel.
Die Community-Anwendung ist nicht offiziell freigegeben oder banfrei zertifiziert. Der bisherige Profilkern schreibt noch komplette Config-Dateien; eine offizielle Freigabeliste pro Parameter und ein ausschließlich gezielter Editor sind noch offen. Dateityp-/Pfadschutz ersetzt keinen vollständigen Regelprüfer. EXE unsigniert, keine Antivirus-Freigabe; Prüfsummen bestätigen nur Integrität.
2FA bleibt bei APB/GamersFirst. Keine Zugangsdaten-/Token-Speicherung oder -Änderung; kein bestätigter Remember-Me-Fix. Keine Cache-Löschschleife, Makros, Hooks, Injektion oder Prozessspeicherzugriffe.
Quellen und technische Details: README.en.md, ITEM-STATS-SOURCES.json, COMMANDS.de.md. Regeln: https://www.gamersfirst.com/apb/news/2024/8/14/sard-faq

## Neu in v4.0
Navigation mit Symbolen, kurze Hinweise mit Details beim Darüberfahren und direkt sichtbare Tools-Kacheln. Grafikregler, Kleidung-/Fahrzeugeditoren, Streaming und Cache stehen unter Advanced. Matt Scott ist oben wieder sichtbar.
APB Repair öffnet den offiziellen Launcher. Dort Repair/Reparieren auswählen; die Reparatur startet nicht automatisch. Anschließend gewünschte Config erneut anwenden.
Equipment-Hinweise in Missionen bleiben Textkürzel. Echte Bildsymbole in Missionstiteln sind nicht bestätigt und wurden nicht eingebaut.
