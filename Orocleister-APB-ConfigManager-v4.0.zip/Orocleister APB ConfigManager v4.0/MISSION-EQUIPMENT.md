# Mission equipment cues — working draft

Mission titles retain their names and gain a short equipment summary. `E:` means the Enforcer mission owner; `C:` means the Criminal mission owner. This is not a loadout recommendation for the opposing team. Equipment can speed up interactions; these labels do not mean that a particular upgrade is mandatory.

The current owning-side stage also gains `[EQ:...]` before its existing stage roadmap. Opposing/dispatch instructions are not assigned the attacker's equipment. Existing text, timers, colors, stage order and amounts are preserved.

| Cue | Equipment / action |
|---|---|
| RAM | The Ram Man — forced entry |
| BAR | Blistor QE crowbar — burglary |
| SPRAY | Spray paint — criminal graffiti actions |
| SPRAYMATE | Ferrite Spraymate — enforcer graffiti actions |
| FUEL | GA5 petrol can — arson |
| WIRE | Wirepal — sabotage / bomb disposal |
| HACK | Netbook — hacking |
| CAM | The Shutterbug — investigation |
| XAG | Somatic XAG — planting explosives |
| SLIM | F-Series SJ — locked vehicle theft |
| DROP | Delivery objective, not an equipment item |

Unknown or ambiguous mappings are omitted, including vehicle cargo/looting and the contested bombing finale. No invented delivery tool. No equipment is suggested for defending an opponent's burglary.

Example: `2,4,6-TRINITROTOLUENE [C:BAR/XAG]`. The burglary stages receive BAR, delivery receives DROP, and the planting stage receives XAG. The contested finale remains unchanged because the action depends on the player's situation.

Data: [APBDB mission](https://apbdb.com/missions/JG_BCS4_Bom1), [equipment](https://apbdb.com/items?cat=Equipment&page=1), fetched 2026-10-14. Compared 213 mission detail records and equipment descriptions/action associations. Updated 164 titles and 623 owning-side stage rows per language. Entries absent from the current dataset retain their original text.

These are plain text cues, not image icons. Existing APB localization supports some image tags, but equipment-image tags inside mission-title widgets have not been verified. No new font glyphs or game resources installed. Long title fit and actual HUD rendering need an in-game check before release; this draft is not packaged.

Deutsch: Ausrüstungshinweise zeigen passende Verbesserungen für die Aktion. Sie sind keine Pflichtausrüstung. E/C bezeichnet die Fraktion des Missionsbesitzers, nicht automatisch deine Seite. DROP ist nur eine Lieferung.

Русский: Подсказки обозначают улучшения для действия, а не обязательное снаряжение. E/C — сторона владельца миссии, не обязательно твоя команда. DROP — доставка без отдельного инструмента. Значки-картинки ещё не проверены; используются текстовые сокращения.
