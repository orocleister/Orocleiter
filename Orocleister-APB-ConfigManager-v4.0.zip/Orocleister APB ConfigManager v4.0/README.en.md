# Orocleister APB ConfigManager v4.0

Extract the entire ZIP to a writable folder. Start **APB-Config.exe**. Windows 10/11 with .NET Framework 4.8; no PowerShell, installer or administrator launch required.

## Getting started
1. Close APB and its launcher. Select your APB.exe or direct APB shortcut.
2. Start with **Your config**. Resolution defaults to Keep; FPS defaults to 144 (0/empty = unlimited).
3. Review individual options and the file preview under Tools, then Apply. A first/changed-client notice requires acknowledgement.
4. Play APB uses the direct shortcut. Update Game opens the official updater only.
5. For comparison, change one option at a time. Restore returns the previous files, not a guaranteed factory installation.

## Profiles and navigation
- **Your config:** existing low environment preset with detailed players, vehicles and symbols.
- **Low:** existing lowest-quality preset. Can make fences and models look worse; no guaranteed performance gain.
- **Balanced:** higher environment detail with reduced shadows. Does not overwrite saved Custom sliders.
- **Custom:** independent texture-quality sliders. Explicit rendering overrides apply on top of the selected profile.
- **Graphics:** anti-aliasing has one control under Advanced graphics. Bloom and ambient occlusion can be set individually. Bloom defaults off. No verified bloom-strength or sky-only brightness control was found.
- **Input:** independent Keep/Off/On choices for mouse smoothing, game acceleration, VSync and one-frame render-thread lag. Defaults preserve installed input values. VSync off can tear; queue off can reduce FPS or worsen pacing. These are not a double-buffering control. Windows mouse settings and sensitivity are not edited by these switches.
- **Other controls:** sprint dot, auto-ready, HUD reset and optional mouse-axis multiplier (1.0/legacy 2.0). A multiplier intentionally changes mouse response; leave Keep unless wanted.
- **In-game bindings:** after Apply and restart, select Crouch (Hold) or Crouch (Toggle) under Movement and Lean Left/Right (Hold/Toggle) under Combat. Assign Ctrl and Q/E yourself and clear the same key on the alternative action. No automatic reassignment. Classic hold-crouch may get out of sync after interruptions. In-game display/behavior still needs testing.

## Audio
Created songs are requested off and local music-player volume is zero by default. Kill themes are explicitly enabled, including friend/ignored/non-friend theme options. Master/effect volumes are preserved. **Other players' car broadcasts may still be audible. A complete supported fix is not confirmed.** No sound bank, instrument, vehicle-amplifier resource or ambient audio resource is removed or changed. The theme behavior still needs live verification.

## Profiles & diagnostics
Exports a versioned .apbprofile containing supported graphics, input and audio choices. No account data, paths, login tokens, executable code or arbitrary INI payloads are exported. Imports enforce size, schema, key, type and range checks and show changes before loading. Apply is still separate. Local UI language, game path, localization packs and startup arguments are not shared.
Hardware detection reports CPU, installed graphics adapters and available physical memory through Windows APIs, with a registry fallback. Recommendations are simple starting points, not benchmarks.
Client checking compares APB.exe version and SHA-256 against the last acknowledged Apply. It does not certify all game resources or predict patch compatibility. A changed client is never silently reapplied.

## Backup and recovery
Apply backs up target files and the shortcut, records SHA-256 digests and writes a pending-transaction journal before modifying game files. Incomplete transactions block another Apply/Play; choose Tools → Restore backup. Backup data is checked before restoration. An integrity failure stops restoration instead of copying damaged data.
Keep the app folder and Backups. Moving to a fresh extracted copy does not automatically import old backups. Backup means previous state, possibly already modified; use the official repair for original game files. Do not run two manager copies simultaneously. manager-events.log records successful Apply/recovery events locally.

## Test scope and limitations
Passed: build; 8-page rendering in EN/DE/RU; profile roundtrip and hostile input rejection; input switches and unchanged mouse multipliers; in-game action definitions; theme settings; Balanced preserves Custom; Apply and byte-exact restore on a dummy game; corrupt backup rejection; interrupted-transaction recovery; client-change detection. Tests do not establish actual FPS, live key behavior or audio suppression.

This community tool is not officially approved or certified ban-free. The existing legacy preset backend still writes complete config files; a per-parameter official-policy allowlist and incremental-only editor remain unfinished. The output-path/type guard blocks game resource and shader writes but is NOT a complete rules-compliance scanner. Unknown new tweaks were not introduced as working fixes. The EXE is unsigned; no antivirus clearance is claimed. SHA-256 files check integrity only.

2FA/device trust remains controlled by APB/GamersFirst. No credentials or authentication tokens are stored or modified by this manager; no confirmed config fix for Remember Me is included. No cache cleaning loop, gameplay macro, injection, hook, process-memory reader or recoil modification is added.

## References
- Official modification rules: https://www.gamersfirst.com/apb/news/2024/8/14/sard-faq
- APBDB item-stat provenance: ITEM-STATS-SOURCES.json (14 October snapshot; unmatched entries remain unverified).
- Flaws: https://github.com/flawsv/apb
- Lazer: https://github.com/lvzxr/apb-cfg-loader
- Game commands: COMMANDS.en.md; mission hints: MISSION-EQUIPMENT.md.

## New in v4.0
Icon navigation, short hints with hover details and directly accessible tool tiles. Rendering controls, clothing/vehicle editors, streaming and cache are under Advanced. The Matt Scott header image is visible again.
APB Repair opens the official launcher. Select Repair there; repair is not started automatically. Reapply your preferred config afterwards.
Mission equipment hints remain text abbreviations. Actual image icons in mission titles have not been confirmed supported and are not included.
